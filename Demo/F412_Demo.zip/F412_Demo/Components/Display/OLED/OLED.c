/* 0.96寸OLED I2C版本驱动分页版 基于KL库 */
/* ===========支持双地址多设备========== */
/* ========单屏可实现帧率最高44fps====== */
/** 
  * 无缓冲帧架构，此设计避免了从缓冲中移入输出序列时阻塞或额外使用DMA的窘境
  * 对显存内容修改时注意不要高频修改(如对ADC数据的显示等)，以免出现画面错误
  */

#include "OLED.h"
#include "UI.h"
#include <string.h>

/* ========屏幕句柄配置======== */
OLED_HandleTypeDef OLED1_Handle;

/* ============================ */
void OLED_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess)
{
	OLED_HandleTypeDef* OLED_Handle = (OLED_HandleTypeDef*)Handle;
	switch(MSG.bits.Callback_Num)
	{
		case 0x00:{	// 命令发送回调
			//无需操作
			break;
		}
		case 0x01:{	// 帧刷新回调
			OLED_Handle->Refresh_Counter++;
			if(OLED_Handle->Refresh_Counter < 8)
				OLED_Page_Refresh(OLED_Handle, 1);
			else
				OLED_Handle->Refresh_Counter = 0;
			break;
		}
		// 设置指令回调
		case 0x02:
		case 0x03:
		case 0x04: break;
		// 反初始化回调
		case 0x7F: break;
		// 错误返回值
		default: break;
	}
}

/* OLED页刷新 */
void OLED_Page_Refresh(OLED_HandleTypeDef* OLED_Handle, uint8_t Continuous)
{
	if(OLED_Handle->Refresh_Counter >= 8) return;
	if(Continuous > 1) Continuous = 1;
	OLED_Handle->Page_CMD[1] = 0xB0 | OLED_Handle->Refresh_Counter;
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x00;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle, MSG, OLED_Handle->ADDR,
						OLED_Handle->Page_CMD, sizeof(OLED_Handle->Page_CMD), OLED_I2C_Callback, OLED_Handle);
	MSG.bits.Callback_Num = Continuous;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle, MSG, OLED_Handle->ADDR,
						OLED_Handle->Video_Memory_Out[OLED_Handle->Refresh_Counter],
						OLED_WIDTH + 1, OLED_I2C_Callback, OLED_Handle);
}

/* OLED帧刷新 */
void OLED_Frame_Refresh(OLED_HandleTypeDef* OLED_Handle)
{
	OLED_Page_Refresh(OLED_Handle, 1);
}

/* OLED显示模式设置(阳码/阴码) */
uint8_t OLED_Set_Display_Mode(OLED_HandleTypeDef* OLED_Handle, uint8_t Mode)
{
	//判断输入值是否合法
	if((Mode != OLED_DISPLAY_MODE_NORMAL) && (Mode != OLED_DISPLAY_MODE_INVERSE)) return 1;
	/* OLED显示模式设置序列 */
	OLED_Handle->Mode_Instruction[1] = 0xA6 + Mode;
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x02;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle , MSG, OLED_Handle->ADDR,
						OLED_Handle->Mode_Instruction, sizeof(OLED_Handle->Mode_Instruction),
						OLED_I2C_Callback, OLED_Handle);
	return 0;
}

/* OLED显示方向设置(正向/反向) */
uint8_t OLED_Set_Display_Orientation(OLED_HandleTypeDef* OLED_Handle, uint8_t Orientation)
{
	//判断输入值是否合法
	if((Orientation != OLED_ORIENTATION_UP) && (Orientation != OLED_ORIENTATION_DOWN)) return 1;
	/* OLED显示方向设置序列 */
	OLED_Handle->Orientation_Instruction[1] = 0xA1 - Orientation;
	OLED_Handle->Orientation_Instruction[2] = 0xC8 - 8 * Orientation;
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x03;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle , MSG, OLED_Handle->ADDR,
						OLED_Handle->Orientation_Instruction, sizeof(OLED_Handle->Orientation_Instruction),
						OLED_I2C_Callback, OLED_Handle);
	return 0;
}

/* OLED显示亮度设置0~100 */
void OLED_Set_Brightness(OLED_HandleTypeDef* OLED_Handle, uint8_t Brightness)
{
	/* OLED亮度控制序列 */
	static uint8_t OLED_SetBrightness_Instruction[] = {0x00, 0x81, 0xFF};
	if(Brightness > 100) Brightness = 100;
	uint16_t brightness = (uint16_t)Brightness;
	brightness = (brightness * brightness * 254) / 10000 + 1;
	OLED_SetBrightness_Instruction[2] = (uint8_t)brightness;
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x04;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle , MSG, OLED_Handle->ADDR,
						OLED_SetBrightness_Instruction, sizeof(OLED_SetBrightness_Instruction),
						OLED_I2C_Callback, OLED_Handle);
}

/* OLED初始化 */
void OLED_Init(OLED_HandleTypeDef* OLED_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr, uint8_t Display_Mode, uint8_t Orientation, uint8_t Brightness)
{
	OLED_Handle->KL_I2C_Handle = I2C_Bus;
	OLED_Handle->ADDR = Addr;
	OLED_Handle->Orientation_Instruction[0] = 0x00;
	OLED_Handle->Mode_Instruction[0] = 0x00;
	OLED_Handle->Page_CMD[0] = 0x00;
	OLED_Handle->Page_CMD[1] = 0xB0;
	OLED_Handle->Page_CMD[2] = 0x10;
	OLED_Handle->Page_CMD[3] = 0x00;
	OLED_Handle->Refresh_Counter = 0;
	OLED_Handle->Frame_Rate_Control_Parameters = 0;
	for (uint8_t i = 0; i < OLED_PAGES; i++)
	{
		OLED_Handle->Video_Memory_Out[i][0] = 0x40;
		OLED_Handle->Video_Memory[i] = &(OLED_Handle->Video_Memory_Out[i][1]);
		memset(OLED_Handle->Video_Memory[i], 0x00, OLED_WIDTH);
	}
	
	/* OLED初始化发送序列 */
	static uint8_t OLED_Init_Instruction[] = {
		0x00,  // 控制字节，表示后面是命令
		0xAE,  // 关闭显示
		0xD5, 0xF0,  // 设置显示时钟分频比/振荡器频率
		0xA8, OLED_HEIGHT - 1,  // 设置多路复用率
		0xD3, 0x00,  // 设置显示偏移
		0x40,        // 设置显示起始行
		0xDA, 0x12,  // 设置COM引脚硬件配置
		0xD9, 0x20,  // 设置预充电周期
		0xD8, 0x30,  // 设置VCOMH调节
		0xA4,        // 整个显示打开（使用RAM内容）
		0x8D, 0x14,  // 设置充电泵使能
		0x20, 0x00,  // 设置内存地址模式（水平地址模式）
		0x21, 0x00, OLED_WIDTH - 1,  // 设置列地址范围（0-127）
		0x22, 0x00, OLED_PAGES - 1,  // 设置页地址范围（0-7）
		0xAF         // 开启显示
	};
	//发送初始化硬件相关指令
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0X00;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle , MSG, OLED_Handle->ADDR,
						OLED_Init_Instruction, sizeof(OLED_Init_Instruction),
						OLED_I2C_Callback, OLED_Handle);
	//屏幕相关设置
	OLED_Set_Brightness(OLED_Handle, Brightness);
	OLED_Set_Display_Orientation(OLED_Handle, Orientation);
	OLED_Set_Display_Mode(OLED_Handle, Display_Mode);
						
	OLED_Frame_Refresh(OLED_Handle);
}

/* OLED反初始化 */
void OLED_DeInit(OLED_HandleTypeDef* OLED_Handle)
{
	/* OLED反初始化发送序列 */
	static uint8_t OLED_DeInit_Instruction[] = { 
		0x00,       // 控制字节，表示后面是命令
		0xAF,       // 关闭显示
		0x8D, 0x10  // 关闭充电泵
	};
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0X7F;
	KL_I2C_RegisterTask(OLED_Handle->KL_I2C_Handle , MSG, OLED_Handle->ADDR,
						OLED_DeInit_Instruction, sizeof(OLED_DeInit_Instruction),
						OLED_I2C_Callback, OLED_Handle);
}
