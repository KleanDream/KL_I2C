#ifndef __LED_H
#define __LED_H

//红色LED
#define LED_Pin GPIO_PIN_2
#define LED_GPIO_Port GPIOB

void LED_Init(void);
void LED_On(void);
void LED_Off(void);
void LED_Toggle(void);

#endif
