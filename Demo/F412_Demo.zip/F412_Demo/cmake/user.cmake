message(STATUS "[user.cmake] loaded from ${CMAKE_CURRENT_LIST_DIR}")

# 工程根目录（cmake/ 的上一级）
set(USER_PROJECT_ROOT ${CMAKE_CURRENT_LIST_DIR}/..)

# ---------------------------------------------------------------------------
# 1. 收集用户源码
# ---------------------------------------------------------------------------
file(GLOB_RECURSE USER_SOURCES
    ${USER_PROJECT_ROOT}/KL_Lib/KL_I2C/*.c
    ${USER_PROJECT_ROOT}/System/*.c
    ${USER_PROJECT_ROOT}/Components/*.c
)

# 把用户源码追加到可执行目标
target_sources(${CMAKE_PROJECT_NAME} PRIVATE ${USER_SOURCES})

# ---------------------------------------------------------------------------
# 2. 用户头文件搜索路径
# ---------------------------------------------------------------------------
target_include_directories(${CMAKE_PROJECT_NAME} PRIVATE
    ${USER_PROJECT_ROOT}/KL_Lib/KL_I2C/Inc
    ${USER_PROJECT_ROOT}/System/System_service/UI
    ${USER_PROJECT_ROOT}/Components/BSP/LED
    ${USER_PROJECT_ROOT}/Components/Display/OLED
)
