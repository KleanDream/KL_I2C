/*
 * FreeRTOS 内核 V10.4.6
 * 版权所有 (C) 2021 Amazon.com, Inc. 或其关联公司。保留所有权利。
 *
 * SPDX-License-Identifier: MIT
 *
 * 特此免费授予任何获得本软件及其相关文档文件（“软件”）副本的人，
 * 不受限制地处理本软件的权利，包括但不限于使用、复制、修改、合并、
 * 发布、分发、再许可和/或销售本软件副本的权利，并允许获得本软件的人
 * 这样做，但须遵守以下条件：
 *
 * 上述版权声明和本许可声明应包含在本软件的所有副本或实质性部分中。
 *
 * 本软件按“原样”提供，不提供任何形式的明示或暗示保证，包括但不限于
 * 适销性、特定用途适用性和非侵权性的保证。在任何情况下，作者或版权
 * 持有人均不对因本软件或本软件的使用或其他交易而引起的任何索赔、
 * 损害赔偿或其他责任（无论是合同诉讼、侵权诉讼还是其他诉讼）负责。
 *
 * https://www.FreeRTOS.org
 * https://github.com/FreeRTOS
 *
 */

/*
 * 这是 pvPortMalloc() 最简单的可能实现。
 * 注意：此实现不允许释放已分配的内存。
 *
 * 其他实现请参阅 heap_2.c、heap_3.c 和 heap_4.c，
 * 更多信息请访问 https://www.FreeRTOS.org 的内存管理页面。
 */

#include <stdlib.h>

/* 定义 MPU_WRAPPERS_INCLUDED_FROM_API_FILE 可以防止 task.h 将所有 API 函数
 * 重定义为使用 MPU 包装器。只有当 task.h 从应用程序文件中包含时才应这样做。*/
#define MPU_WRAPPERS_INCLUDED_FROM_API_FILE

#include "FreeRTOS.h"
#include "task.h"

#undef MPU_WRAPPERS_INCLUDED_FROM_API_FILE

/* 如果配置禁用了动态内存分配，则此文件不应被使用 */
#if ( configSUPPORT_DYNAMIC_ALLOCATION == 0 )
    #error 当 configSUPPORT_DYNAMIC_ALLOCATION 为 0 时，不得使用此文件
#endif

/* 为了对齐堆起始地址，可能会损失几个字节 */
#define configADJUSTED_HEAP_SIZE    ( configTOTAL_HEAP_SIZE - portBYTE_ALIGNMENT )

/* 为堆分配内存 */
#if ( configAPPLICATION_ALLOCATED_HEAP == 1 )

/* 应用程序编写者已经定义了用于 RTOS 堆的数组 —— 可能是为了将其放置在
 * 特殊的段或地址中。*/
    extern uint8_t ucHeap[ configTOTAL_HEAP_SIZE ];
#else
    /* 静态数组，由内核内部使用，作为整个堆空间 */
    static uint8_t ucHeap[ configTOTAL_HEAP_SIZE ];
#endif /* configAPPLICATION_ALLOCATED_HEAP */

/* 指向 ucHeap 数组的当前空闲位置索引（字节偏移量） */
static size_t xNextFreeByte = ( size_t ) 0;

/*-----------------------------------------------------------*/

/*
 * 动态内存分配函数
 * 参数 xWantedSize：请求分配的字节数
 * 返回值：指向已分配内存块的指针，若分配失败则返回 NULL
 *
 * 实现特点：
 * - 支持字节对齐（通过 portBYTE_ALIGNMENT 配置）
 * - 分配后不能释放（无 free 功能）
 * - 通过挂起调度器保证分配过程的原子性
 * - 分配失败时可调用钩子函数（需配置 configUSE_MALLOC_FAILED_HOOK）
 */
void * pvPortMalloc( size_t xWantedSize )
{
    void * pvReturn = NULL;
    static uint8_t * pucAlignedHeap = NULL;  /* 指向堆对齐起始地址的指针，仅初始化一次 */

    /* 确保内存块始终按字节对齐 */
    #if ( portBYTE_ALIGNMENT != 1 )
        {
            /* 如果请求的大小不是对齐值的整数倍，则向上取整到下一个对齐边界 */
            if( xWantedSize & portBYTE_ALIGNMENT_MASK )
            {
                /* 检查向上取整时是否会溢出（size_t 类型回绕） */
                if ( (xWantedSize + ( portBYTE_ALIGNMENT - ( xWantedSize & portBYTE_ALIGNMENT_MASK ) )) > xWantedSize )
                {
                    /* 调整大小为对齐后的大小 */
                    xWantedSize += ( portBYTE_ALIGNMENT - ( xWantedSize & portBYTE_ALIGNMENT_MASK ) );
                }
                else
                {
                    /* 溢出发生，将大小设为 0，后续分配会失败 */
                    xWantedSize = 0;
                }
            }
        }
    #endif

    /* 挂起调度器，防止在分配过程中被其他任务或中断打断（如果使用中断则需额外保护）*/
    vTaskSuspendAll();
    {
        /* 首次调用时，需要计算堆的起始对齐地址 */
        if( pucAlignedHeap == NULL )
        {
            /* 将 ucHeap 的起始地址向上对齐到 portBYTE_ALIGNMENT 边界。
             * 计算方法：取 ucHeap 地址中因对齐可能丢失的部分，用掩码清除低几位。*/
            pucAlignedHeap = ( uint8_t * ) ( ( ( portPOINTER_SIZE_TYPE ) & ucHeap[ portBYTE_ALIGNMENT - 1 ] ) & ( ~( ( portPOINTER_SIZE_TYPE ) portBYTE_ALIGNMENT_MASK ) ) );
        }

        /* 检查是否有足够的剩余空间，并防止整数溢出 */
        if( ( xWantedSize > 0 ) &&                                /* 请求大小有效 */
            ( ( xNextFreeByte + xWantedSize ) < configADJUSTED_HEAP_SIZE ) &&  /* 未超出堆总大小 */
            ( ( xNextFreeByte + xWantedSize ) > xNextFreeByte ) )  /* 加法未溢出（size_t 回绕检查）*/
        {
            /* 返回当前空闲块起始地址，然后将空闲指针向前移动 xWantedSize */
            pvReturn = pucAlignedHeap + xNextFreeByte;
            xNextFreeByte += xWantedSize;
        }

        /* 跟踪分配事件（可配置的调试宏）*/
        traceMALLOC( pvReturn, xWantedSize );
    }
    /* 恢复调度器，注意此函数也可能触发任务切换 */
    ( void ) xTaskResumeAll();

    /* 如果启用了分配失败钩子，且在分配失败时调用应用程序定义的钩子函数 */
    #if ( configUSE_MALLOC_FAILED_HOOK == 1 )
        {
            if( pvReturn == NULL )
            {
                extern void vApplicationMallocFailedHook( void );
                vApplicationMallocFailedHook();  /* 用户自定义处理，例如记录日志或采取应急措施 */
            }
        }
    #endif

    return pvReturn;
}
/*-----------------------------------------------------------*/

/*
 * 内存释放函数（此简单实现中不支持释放）
 * 参数 pv：指向要释放的内存块的指针（本实现中未使用）
 *
 * 注意：在 heap_1 方案中，调用此函数会触发断言失败。
 * 如需释放内存，请改用 heap_2、heap_3 或 heap_4 实现。
 */
void vPortFree( void * pv )
{
    /* 此方案无法释放内存。参见 heap_2.c、heap_3.c 和 heap_4.c 中的其他实现，
     * 以及 https://www.FreeRTOS.org 的内存管理页面获取更多信息。*/
    ( void ) pv;   /* 避免编译器警告未使用的参数 */

    /* 强制断言，因为调用此函数是无效的（在配置中应启用 configASSERT）*/
    configASSERT( pv == NULL );
}
/*-----------------------------------------------------------*/

/*
 * 初始化内存分配所需的静态变量。
 * 在 heap_1 中，只需将空闲指针复位为 0。
 * 当静态内存区域未被清零时（例如重启后未重新初始化），此函数可用于重置分配器状态。
 */
void vPortInitialiseBlocks( void )
{
    /* 仅在静态内存未被清零时需要调用 */
    xNextFreeByte = ( size_t ) 0;
}
/*-----------------------------------------------------------*/

/*
 * 获取当前剩余的可用堆内存大小（字节）
 * 返回值：尚未分配的字节数
 *
 * 注意：由于 heap_1 不支持释放，此值只会单调递减（除非重新初始化）。
 */
size_t xPortGetFreeHeapSize( void )
{
    /* 总可用堆大小减去已分配的字节数 */
    return( configADJUSTED_HEAP_SIZE - xNextFreeByte );
}