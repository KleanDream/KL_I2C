#include "KL_I2C.h"
#include "KL_I2C_Init.h"

#if KL_FMPI2C_Enable == 1
	#if USE_SIMPLE_INIT == 1
	FMPI2C_HandleTypeDef KL_FMPI2C_hi2c;
	#endif
	Hardware_I2C_HandleTypeDef KL_FMPI2C_Hardware = {
		.I2C_Handle = NULL,
		.FMPI2C_Handle = &KL_FMPI2C_hi2c,
	};
	#if USE_SIMPLE_INIT == 1
	#if KL_I2C1_USE_DMA_Tx == 1
		DMA_HandleTypeDef KL_FMPI2C_hdma_tx;
	#endif
	#if KL_I2C1_USE_DMA_Rx == 1
		DMA_HandleTypeDef KL_FMPI2C_hdma_rx;
	#endif
	#endif
	KL_I2C_COM_Task_Queue KL_FMPI2C_Task_Queue[KL_FMPI2C_Task_Queue_Len];
	KL_I2C_HandleTypeDef KL_FMPI2C_Handle = {
		.KL_I2C_hi2c->FMPI2C_Handle = &KL_FMPI2C_hi2c,
		.KL_I2C_IT_Tx_Fun = KL_FMPI2C_Transmit_IT,
		.KL_I2C_IT_Rx_Fun = KL_FMPI2C_Receive_IT,
		#if  KL_FMPI2C_USE_DMA_Tx == 1
		.KL_I2C_DMA_Tx_Fun = KL_FMPI2C_Transmit_DMA,
		#else
		.KL_I2C_DMA_Tx_Fun = NULL,
		#endif
		#if  KL_FMPI2C_USE_DMA_Rx == 1
		.KL_I2C_DMA_Rx_Fun = KL_FMPI2C_Receive_DMA,
		#else
		.KL_I2C_DMA_Rx_Fun = NULL,
		#endif
		.Task_Queue = KL_FMPI2C_Task_Queue,
		.KL_I2C_State_Register.bits = {
			.Task_Queue_Len = KL_FMPI2C_Task_Queue_Len,
			.R_Point = 0,
			.W_Point = 0,
			.First_Write = 0,
			.First_Read = 0,
			.Init_ed = 0,
			.State = 0,
			.USE_DMA_Tx_Flag = KL_FMPI2C_USE_DMA_Tx,
			.USE_DMA_Rx_Flag = KL_FMPI2C_USE_DMA_Rx,
		},
	};
#endif
#if KL_I2C1_Enable == 1
	#if USE_SIMPLE_INIT == 1
	I2C_HandleTypeDef KL_I2C1_hi2c;
	#endif
	Hardware_I2C_HandleTypeDef KL_I2C1_Hardware = {
		.I2C_Handle = &KL_I2C1_hi2c,
		#if KL_FMPI2C_Enable == 1
		.FMPI2C_Handle = NULL,
		#endif
	};
	#if USE_SIMPLE_INIT == 1
	#if KL_I2C1_USE_DMA_Tx == 1
		DMA_HandleTypeDef KL_I2C1_hdma_tx;
	#endif
	#if KL_I2C1_USE_DMA_Rx == 1
		DMA_HandleTypeDef KL_I2C1_hdma_rx;
	#endif
	#endif
	KL_I2C_COM_Task_Queue KL_I2C1_Task_Queue[KL_I2C1_Task_Queue_Len];
	KL_I2C_HandleTypeDef KL_I2C1_Handle = {
		.KL_I2C_hi2c = &KL_I2C1_Hardware,
		.KL_I2C_IT_Tx_Fun = KL_I2C_Transmit_IT,
		.KL_I2C_IT_Rx_Fun = KL_I2C_Receive_IT,
		#if  KL_I2C1_USE_DMA_Tx == 1
		.KL_I2C_DMA_Tx_Fun = KL_I2C_Transmit_DMA,
		#else
		.KL_I2C_DMA_Tx_Fun = NULL,
		#endif
		#if  KL_I2C1_USE_DMA_Rx == 1
		.KL_I2C_DMA_Rx_Fun = KL_I2C_Receive_DMA,
		#else
		.KL_I2C_DMA_Rx_Fun = NULL,
		#endif
		.Task_Queue = KL_I2C1_Task_Queue,
		.KL_I2C_State_Register.bits = {
			.Task_Queue_Len = KL_I2C1_Task_Queue_Len,
			.R_Point = 0,
			.W_Point = 0,
			.First_Write = 0,
			.First_Read = 0,
			.Init_ed = 0,
			.State = 0,
			.USE_DMA_Tx_Flag = KL_I2C1_USE_DMA_Tx,
			.USE_DMA_Rx_Flag = KL_I2C1_USE_DMA_Rx,
		},
	};
#endif
#if KL_I2C2_Enable == 1
	#if USE_SIMPLE_INIT == 1
	I2C_HandleTypeDef KL_I2C2_hi2c;
	#endif
	Hardware_I2C_HandleTypeDef KL_I2C2_Hardware = {
		.I2C_Handle = &KL_I2C2_hi2c,
		#if KL_FMPI2C_Enable == 1
		.FMPI2C_Handle = NULL,
		#endif
	};
	#if USE_SIMPLE_INIT == 1
	#if KL_I2C2_USE_DMA_Tx == 1
		DMA_HandleTypeDef KL_I2C2_hdma_tx;
	#endif
	#if KL_I2C2_USE_DMA_Rx == 1
		DMA_HandleTypeDef KL_I2C2_hdma_rx;
	#endif
	#endif
	KL_I2C_COM_Task_Queue KL_I2C2_Task_Queue[KL_I2C2_Task_Queue_Len];
	KL_I2C_HandleTypeDef KL_I2C2_Handle = {
		.KL_I2C_hi2c = &KL_I2C2_Hardware,
		.KL_I2C_IT_Tx_Fun = KL_I2C_Transmit_IT,
		.KL_I2C_IT_Rx_Fun = KL_I2C_Receive_IT,
		#if  KL_I2C2_USE_DMA_Tx == 1
		.KL_I2C_DMA_Tx_Fun = KL_I2C_Transmit_DMA,
		#else
		.KL_I2C_DMA_Tx_Fun = NULL,
		#endif
		#if  KL_I2C2_USE_DMA_Rx == 1
		.KL_I2C_DMA_Rx_Fun = KL_I2C_Receive_DMA,
		#else
		.KL_I2C_DMA_Rx_Fun = NULL,
		#endif
		.Task_Queue = KL_I2C2_Task_Queue,
		.KL_I2C_State_Register.bits = {
			.Task_Queue_Len = KL_I2C2_Task_Queue_Len,
			.R_Point = 0,
			.W_Point = 0,
			.First_Write = 0,
			.First_Read = 0,
			.Init_ed = 0,
			.State = 0,
			.USE_DMA_Tx_Flag = KL_I2C2_USE_DMA_Tx,
			.USE_DMA_Rx_Flag = KL_I2C2_USE_DMA_Rx,
		},
	};
#endif
#if KL_I2C3_Enable == 1
	#if USE_SIMPLE_INIT == 1
	I2C_HandleTypeDef KL_I2C3_hi2c;
	#endif
	Hardware_I2C_HandleTypeDef KL_I2C3_Hardware = {
		.I2C_Handle = &KL_I2C3_hi2c,
		#if KL_FMPI2C_Enable == 1
		.FMPI2C_Handle = NULL,
		#endif
	};
	#if USE_SIMPLE_INIT == 1
	#if KL_I2C3_USE_DMA_Tx == 1
		DMA_HandleTypeDef KL_I2C3_hdma_tx;
	#endif
	#if KL_I2C3_USE_DMA_Rx == 1
		DMA_HandleTypeDef KL_I2C3_hdma_rx;
	#endif
	#endif
	KL_I2C_COM_Task_Queue KL_I2C3_Task_Queue[KL_I2C3_Task_Queue_Len];
	KL_I2C_HandleTypeDef KL_I2C3_Handle = {
		.KL_I2C_hi2c = &KL_I2C3_Hardware,
		.KL_I2C_IT_Tx_Fun = KL_I2C_Transmit_IT,
		.KL_I2C_IT_Rx_Fun = KL_I2C_Receive_IT,
		#if  KL_I2C3_USE_DMA_Tx == 1
		.KL_I2C_DMA_Tx_Fun = KL_I2C_Transmit_DMA,
		#else
		.KL_I2C_DMA_Tx_Fun = NULL,
		#endif
		#if  KL_I2C3_USE_DMA_Rx == 1
		.KL_I2C_DMA_Rx_Fun = KL_I2C_Receive_DMA,
		#else
		.KL_I2C_DMA_Rx_Fun = NULL,
		#endif
		.Task_Queue = KL_I2C3_Task_Queue,
		.KL_I2C_State_Register.bits = {
			.Task_Queue_Len = KL_I2C3_Task_Queue_Len,
			.R_Point = 0,
			.W_Point = 0,
			.First_Write = 0,
			.First_Read = 0,
			.Init_ed = 0,
			.State = 0,
			.USE_DMA_Tx_Flag = KL_I2C3_USE_DMA_Tx,
			.USE_DMA_Rx_Flag = KL_I2C3_USE_DMA_Rx,
		},
	};
#endif

/** 
  * 需要实现至少一种I2C的收发函数
  * 以下为基于STM32 HAL库时需要的封装
  */
#if KL_FMPI2C_Enable == 1
/* FMPI2C通过DMA方法发送数据  */
KL_Status KL_FMPI2C_Transmit_DMA(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_FMPI2C_Hardware->FMPI2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_FMPI2C_Master_Transmit_DMA(KL_FMPI2C_Hardware->FMPI2C_Handle, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

/* FMPI2C通过中断方法发送数据 */
KL_Status KL_FMPI2C_Transmit_IT(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_FMPI2C_Hardware->FMPI2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_FMPI2C_Master_Transmit_IT(KL_FMPI2C_hi2c, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

/* FMPI2C通过DMA方法接收数据  */
KL_Status KL_FMPI2C_Receive_DMA(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_FMPI2C_Hardware->FMPI2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_FMPI2C_Master_Receive_DMA(KL_FMPI2C_hi2c, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

/* FMPI2C通过中断方法接收数据 */
KL_Status KL_FMPI2C_Receive_IT(Hardware_FMPI2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_FMPI2C_Hardware->FMPI2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_FMPI2C_Master_Receive_IT(KL_FMPI2C_hi2c, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}
#endif

/* I2C通过DMA方法发送数据  */
KL_Status KL_I2C_Transmit_DMA(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_I2C_Hardware->I2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_I2C_Master_Transmit_DMA(KL_I2C_Hardware->I2C_Handle, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

/* I2C通过中断方法发送数据 */
KL_Status KL_I2C_Transmit_IT(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_I2C_Hardware->I2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_I2C_Master_Transmit_IT(KL_I2C_Hardware->I2C_Handle, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

/* I2C通过DMA方法接收数据  */
KL_Status KL_I2C_Receive_DMA(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_I2C_Hardware->I2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_I2C_Master_Receive_DMA(KL_I2C_Hardware->I2C_Handle, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

/* I2C通过中断方法接收数据 */
KL_Status KL_I2C_Receive_IT(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size)
{
	if(KL_I2C_Hardware->I2C_Handle == NULL) return KL_ERROR;
	HAL_StatusTypeDef COM_result = HAL_I2C_Master_Receive_IT(KL_I2C_Hardware->I2C_Handle, Addr, pData, Size);

	if(COM_result == HAL_OK)
		return KL_OK;
	return KL_ERROR;
}

#if USE_SIMPLE_INIT == 1
/* KL_I2C硬件FMPI2C外设初始化 */
KL_Status KL_FMPI2C_Bus_Init(void)
{
#if KL_FMPI2C_Enable == 1
	RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};
	PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_FMPI2C1;
	PeriphClkInitStruct.Fmpi2c1ClockSelection = KL_FMPI2C_ClockSelection;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK) return KL_ERROR;
	
	__HAL_RCC_FMPI2C1_CLK_ENABLE();
	HAL_NVIC_SetPriority(FMPI2C1_EV_IRQn, KL_FMPI2C_EV_IRQ_PreemptPriority, KL_FMPI2C_EV_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(FMPI2C1_EV_IRQn);
	HAL_NVIC_SetPriority(FMPI2C1_ER_IRQn, KL_FMPI2C_ER_IRQ_PreemptPriority, KL_FMPI2C_ER_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(FMPI2C1_ER_IRQn);
	
	KL_FMPI2C_hi2c.Instance = KL_FMPI2C;
	KL_FMPI2C_hi2c.Init.Timing = KL_FMPI2C_Timing;
	KL_FMPI2C_hi2c.Init.OwnAddress1 = 0;
	KL_FMPI2C_hi2c.Init.AddressingMode = KL_FMPI2C_Addr_Mode;
	KL_FMPI2C_hi2c.Init.DualAddressMode = FMPI2C_DUALADDRESS_DISABLE;
	KL_FMPI2C_hi2c.Init.OwnAddress2 = 0;
	KL_FMPI2C_hi2c.Init.OwnAddress2Masks = FMPI2C_OA2_NOMASK;
	KL_FMPI2C_hi2c.Init.GeneralCallMode = FMPI2C_GENERALCALL_DISABLE;
	KL_FMPI2C_hi2c.Init.NoStretchMode = FMPI2C_NOSTRETCH_DISABLE;
	if (HAL_FMPI2C_Init(&KL_FMPI2C_hi2c) != HAL_OK) return KL_ERROR;
	if (HAL_FMPI2CEx_ConfigAnalogFilter(&KL_FMPI2C_hi2c, FMPI2C_ANALOGFILTER_ENABLE) != HAL_OK) return KL_ERROR;
	HAL_FMPI2CEx_EnableFastModePlus(FMPI2C_FASTMODEPLUS_SCL);
	HAL_FMPI2CEx_EnableFastModePlus(FMPI2C_FASTMODEPLUS_SDA);
	if(!(KL_FMPI2C_USE_DMA_Tx && KL_FMPI2C_USE_DMA_Rx)) KL_FMPI2C_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C1外设初始化 */
KL_Status KL_I2C1_Bus_Init(void)
{
#if KL_I2C1_Enable == 1
	__HAL_RCC_I2C1_CLK_ENABLE();
	HAL_NVIC_SetPriority(I2C1_EV_IRQn, KL_I2C1_EV_IRQ_PreemptPriority, KL_I2C1_EV_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(I2C1_EV_IRQn);
	HAL_NVIC_SetPriority(I2C1_ER_IRQn, KL_I2C1_ER_IRQ_PreemptPriority, KL_I2C1_ER_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(I2C1_ER_IRQn);
	
	KL_I2C1_hi2c.Instance = KL_I2C1;
	KL_I2C1_hi2c.Init.ClockSpeed = KL_I2C1_SPEED_KHz * 1000;
	KL_I2C1_hi2c.Init.DutyCycle = I2C_DUTYCYCLE_2;
	KL_I2C1_hi2c.Init.OwnAddress1 = 0;
	KL_I2C1_hi2c.Init.AddressingMode = KL_I2C1_Addr_Mode;
	KL_I2C1_hi2c.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	KL_I2C1_hi2c.Init.OwnAddress2 = 0;
	KL_I2C1_hi2c.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	KL_I2C1_hi2c.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&KL_I2C1_hi2c) != HAL_OK) return KL_ERROR;
	if(!(KL_I2C1_USE_DMA_Tx && KL_I2C1_USE_DMA_Rx)) KL_I2C1_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C2外设初始化 */
KL_Status KL_I2C2_Bus_Init(void)
{
#if KL_I2C2_Enable == 1
	__HAL_RCC_I2C2_CLK_ENABLE();
	HAL_NVIC_SetPriority(I2C2_EV_IRQn, KL_I2C2_EV_IRQ_PreemptPriority, KL_I2C2_EV_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(I2C2_EV_IRQn);
	HAL_NVIC_SetPriority(I2C2_ER_IRQn, KL_I2C2_ER_IRQ_PreemptPriority, KL_I2C2_ER_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(I2C2_ER_IRQn);
	
	KL_I2C2_hi2c.Instance = KL_I2C2;
	KL_I2C2_hi2c.Init.ClockSpeed = KL_I2C2_SPEED_KHz * 1000;
	KL_I2C2_hi2c.Init.DutyCycle = I2C_DUTYCYCLE_2;
	KL_I2C2_hi2c.Init.OwnAddress1 = 0;
	KL_I2C2_hi2c.Init.AddressingMode = KL_I2C2_Addr_Mode;
	KL_I2C2_hi2c.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	KL_I2C2_hi2c.Init.OwnAddress2 = 0;
	KL_I2C2_hi2c.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	KL_I2C2_hi2c.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&KL_I2C2_hi2c) != HAL_OK) return KL_ERROR;
	if(!(KL_I2C2_USE_DMA_Tx && KL_I2C2_USE_DMA_Rx)) KL_I2C2_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C3外设初始化 */
KL_Status KL_I2C3_Bus_Init(void)
{
#if KL_I2C3_Enable == 1
	__HAL_RCC_I2C3_CLK_ENABLE();
	HAL_NVIC_SetPriority(I2C3_EV_IRQn, KL_I2C3_EV_IRQ_PreemptPriority, KL_I2C3_EV_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(I2C3_EV_IRQn);
	HAL_NVIC_SetPriority(I2C3_ER_IRQn, KL_I2C3_ER_IRQ_PreemptPriority, KL_I2C3_ER_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(I2C3_ER_IRQn);
	
	KL_I2C3_hi2c.Instance = KL_I2C3;
	KL_I2C3_hi2c.Init.ClockSpeed = KL_I2C3_SPEED_KHz * 1000;
	KL_I2C3_hi2c.Init.DutyCycle = I2C_DUTYCYCLE_2;
	KL_I2C3_hi2c.Init.OwnAddress1 = 0;
	KL_I2C3_hi2c.Init.AddressingMode = KL_I2C3_Addr_Mode;
	KL_I2C3_hi2c.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	KL_I2C3_hi2c.Init.OwnAddress2 = 0;
	KL_I2C3_hi2c.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	KL_I2C3_hi2c.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&KL_I2C3_hi2c) != HAL_OK) return KL_ERROR;
	if(!(KL_I2C3_USE_DMA_Tx && KL_I2C3_USE_DMA_Rx)) KL_I2C3_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件FMPI2C DMA连接 */
KL_Status KL_FMPI2C_DMA_Init(void)
{
#if KL_FMPI2C_Enable == 1
	__HAL_RCC_DMA1_CLK_ENABLE();
	/*************/
	#if KL_FMPI2C_USE_DMA_Tx == 1
	HAL_NVIC_SetPriority(KL_FMPI2C_DMA1_Tx_Stream_IRQn, KL_FMPI2C_DMA_IRQ_PreemptPriority, KL_FMPI2C_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_FMPI2C_DMA1_Tx_Stream_IRQn);
	KL_FMPI2C_hdma_tx.Instance = KL_FMPI2C_DMA1_Tx_Stream;
	KL_FMPI2C_hdma_tx.Init.Channel = KL_FMPI2C_DMA_Tx_CHANNEL;
	KL_FMPI2C_hdma_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
	KL_FMPI2C_hdma_tx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_FMPI2C_hdma_tx.Init.MemInc = DMA_MINC_ENABLE;
	KL_FMPI2C_hdma_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_FMPI2C_hdma_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_FMPI2C_hdma_tx.Init.Mode = DMA_NORMAL;
	KL_FMPI2C_hdma_tx.Init.Priority = DMA_PRIORITY_LOW;
	KL_FMPI2C_hdma_tx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_FMPI2C_hdma_tx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_FMPI2C_hdma_tx.Init.MemBurst = DMA_MBURST_INC16;
	KL_FMPI2C_hdma_tx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	if (HAL_DMA_Init(&KL_FMPI2C_hdma_tx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_FMPI2C_hi2c,hdmatx,KL_FMPI2C_hdma_tx);
	#endif
	/*************/
	
	/*************/
	#if KL_FMPI2C_USE_DMA_Rx == 1
	HAL_NVIC_SetPriority(KL_FMPI2C_DMA1_Rx_Stream_IRQn, KL_FMPI2C_DMA_IRQ_PreemptPriority, KL_FMPI2C_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_FMPI2C_DMA1_Rx_Stream_IRQn);
	KL_FMPI2C_hdma_rx.Instance = KL_FMPI2C_DMA1_Rx_Stream;
	KL_FMPI2C_hdma_rx.Init.Channel = KL_FMPI2C_DMA_Rx_CHANNEL;
	KL_FMPI2C_hdma_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
	KL_FMPI2C_hdma_rx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_FMPI2C_hdma_rx.Init.MemInc = DMA_MINC_ENABLE;
	KL_FMPI2C_hdma_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_FMPI2C_hdma_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_FMPI2C_hdma_rx.Init.Mode = DMA_NORMAL;
	KL_FMPI2C_hdma_rx.Init.Priority = DMA_PRIORITY_LOW;
	KL_FMPI2C_hdma_rx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_FMPI2C_hdma_rx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_FMPI2C_hdma_rx.Init.MemBurst = DMA_MBURST_INC16;
	KL_FMPI2C_hdma_rx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	if (HAL_DMA_Init(&KL_FMPI2C_hdma_rx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_FMPI2C_hi2c,hdmarx,KL_FMPI2C_hdma_rx);
	#endif
	/*************/
	KL_FMPI2C_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C1 DMA连接 */
KL_Status KL_I2C1_DMA_Init(void)
{
#if KL_I2C1_Enable == 1
	__HAL_RCC_DMA1_CLK_ENABLE();
	/*************/
	#if KL_I2C1_USE_DMA_Tx == 1
	#if defined (STM32F1)
	HAL_NVIC_SetPriority(KL_I2C1_DMA1_Tx_Channel_IRQn, KL_I2C1_DMA_IRQ_PreemptPriority, KL_I2C1_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C1_DMA1_Tx_Channel_IRQn);
	KL_I2C1_hdma_tx.Instance = KL_I2C1_DMA1_Tx_Channel;
	#else
	HAL_NVIC_SetPriority(KL_I2C1_DMA1_Tx_Stream_IRQn, KL_I2C1_DMA_IRQ_PreemptPriority, KL_I2C1_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C1_DMA1_Tx_Stream_IRQn);
	KL_I2C1_hdma_tx.Instance = KL_I2C1_DMA1_Tx_Stream;
	KL_I2C1_hdma_tx.Init.Channel = KL_I2C1_DMA_Tx_CHANNEL;
	KL_I2C1_hdma_tx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_I2C1_hdma_tx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_I2C1_hdma_tx.Init.MemBurst = DMA_MBURST_INC16;
	KL_I2C1_hdma_tx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	#endif
	KL_I2C1_hdma_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
	KL_I2C1_hdma_tx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_I2C1_hdma_tx.Init.MemInc = DMA_MINC_ENABLE;
	KL_I2C1_hdma_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_I2C1_hdma_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_I2C1_hdma_tx.Init.Mode = DMA_NORMAL;
	KL_I2C1_hdma_tx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&KL_I2C1_hdma_tx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_I2C1_hi2c,hdmatx,KL_I2C1_hdma_tx);
	#endif
	/*************/
	
	/*************/
	#if KL_I2C1_USE_DMA_Rx == 1
	#if defined (STM32F1)
	HAL_NVIC_SetPriority(KL_I2C1_DMA1_Rx_Channel_IRQn, KL_I2C1_DMA_IRQ_PreemptPriority, KL_I2C1_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C1_DMA1_Rx_Channel_IRQn);
	KL_I2C1_hdma_rx.Instance = KL_I2C1_DMA1_Rx_Channel;
	#else
	HAL_NVIC_SetPriority(KL_I2C1_DMA1_Rx_Stream_IRQn, KL_I2C1_DMA_IRQ_PreemptPriority, KL_I2C1_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C1_DMA1_Rx_Stream_IRQn);
	KL_I2C1_hdma_rx.Instance = KL_I2C1_DMA1_Rx_Stream;
	KL_I2C1_hdma_rx.Init.Channel = KL_I2C1_DMA_Rx_CHANNEL;
	KL_I2C1_hdma_rx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_I2C1_hdma_rx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_I2C1_hdma_rx.Init.MemBurst = DMA_MBURST_INC16;
	KL_I2C1_hdma_rx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	#endif
	KL_I2C1_hdma_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
	KL_I2C1_hdma_rx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_I2C1_hdma_rx.Init.MemInc = DMA_MINC_ENABLE;
	KL_I2C1_hdma_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_I2C1_hdma_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_I2C1_hdma_rx.Init.Mode = DMA_NORMAL;
	KL_I2C1_hdma_rx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&KL_I2C1_hdma_rx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_I2C1_hi2c,hdmarx,KL_I2C1_hdma_rx);
	#endif
	/*************/
	KL_I2C1_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C2 DMA连接 */
KL_Status KL_I2C2_DMA_Init(void)
{
#if KL_I2C2_Enable == 1
	__HAL_RCC_DMA1_CLK_ENABLE();
	/*************/
	#if KL_I2C2_USE_DMA_Tx == 1
	#if defined (STM32F1)
	HAL_NVIC_SetPriority(KL_I2C2_DMA1_Tx_Channel_IRQn, KL_I2C2_DMA_IRQ_PreemptPriority, KL_I2C2_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C2_DMA1_Tx_Channel_IRQn);
	KL_I2C2_hdma_tx.Instance = KL_I2C2_DMA1_Tx_Channel;
	#else
	HAL_NVIC_SetPriority(KL_I2C2_DMA1_Tx_Stream_IRQn, KL_I2C2_DMA_IRQ_PreemptPriority, KL_I2C2_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C2_DMA1_Tx_Stream_IRQn);
	KL_I2C2_hdma_tx.Instance = KL_I2C2_DMA1_Tx_Stream;
	KL_I2C2_hdma_tx.Init.Channel = KL_I2C2_DMA_Tx_CHANNEL;
	KL_I2C2_hdma_tx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_I2C2_hdma_tx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_I2C2_hdma_tx.Init.MemBurst = DMA_MBURST_INC16;
	KL_I2C2_hdma_tx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	#endif
	KL_I2C2_hdma_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
	KL_I2C2_hdma_tx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_I2C2_hdma_tx.Init.MemInc = DMA_MINC_ENABLE;
	KL_I2C2_hdma_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_I2C2_hdma_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_I2C2_hdma_tx.Init.Mode = DMA_NORMAL;
	KL_I2C2_hdma_tx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&KL_I2C2_hdma_tx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_I2C2_hi2c,hdmatx,KL_I2C2_hdma_tx);
	#endif
	/*************/
	
	/*************/
	#if KL_I2C2_USE_DMA_Rx == 1
	#if defined (STM32F1)
	HAL_NVIC_SetPriority(KL_I2C2_DMA1_Rx_Channel_IRQn, KL_I2C2_DMA_IRQ_PreemptPriority, KL_I2C2_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C2_DMA1_Rx_Channel_IRQn);
	KL_I2C2_hdma_rx.Instance = KL_I2C2_DMA1_Rx_Channel;
	#else
	HAL_NVIC_SetPriority(KL_I2C2_DMA1_Rx_Stream_IRQn, KL_I2C2_DMA_IRQ_PreemptPriority, KL_I2C2_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C2_DMA1_Rx_Stream_IRQn);
	KL_I2C2_hdma_rx.Instance = KL_I2C2_DMA1_Rx_Stream;
	KL_I2C2_hdma_rx.Init.Channel = KL_I2C2_DMA_Rx_CHANNEL;
	KL_I2C2_hdma_rx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_I2C2_hdma_rx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_I2C2_hdma_rx.Init.MemBurst = DMA_MBURST_INC16;
	KL_I2C2_hdma_rx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	#endif
	KL_I2C2_hdma_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
	KL_I2C2_hdma_rx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_I2C2_hdma_rx.Init.MemInc = DMA_MINC_ENABLE;
	KL_I2C2_hdma_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_I2C2_hdma_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_I2C2_hdma_rx.Init.Mode = DMA_NORMAL;
	KL_I2C2_hdma_rx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&KL_I2C2_hdma_rx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_I2C2_hi2c,hdmarx,KL_I2C2_hdma_rx);
	#endif
	/*************/
	KL_I2C2_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C3 DMA连接 */
KL_Status KL_I2C3_DMA_Init(void)
{
#if KL_I2C3_Enable == 1
	__HAL_RCC_DMA1_CLK_ENABLE();
	/*************/
	#if KL_I2C3_USE_DMA_Tx == 1
	#if defined (STM32F1)
	HAL_NVIC_SetPriority(KL_I2C3_DMA1_Tx_Channel_IRQn, KL_I2C3_DMA_IRQ_PreemptPriority, KL_I2C3_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C3_DMA1_Tx_Channel_IRQn);
	KL_I2C3_hdma_tx.Instance = KL_I2C3_DMA1_Tx_Channel;
	#else
	HAL_NVIC_SetPriority(KL_I2C3_DMA1_Tx_Stream_IRQn, KL_I2C3_DMA_IRQ_PreemptPriority, KL_I2C3_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C3_DMA1_Tx_Stream_IRQn);
	KL_I2C3_hdma_tx.Instance = KL_I2C3_DMA1_Tx_Stream;
	KL_I2C3_hdma_tx.Init.Channel = KL_I2C3_DMA_Tx_CHANNEL;
	KL_I2C3_hdma_tx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_I2C3_hdma_tx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_I2C3_hdma_tx.Init.MemBurst = DMA_MBURST_INC16;
	KL_I2C3_hdma_tx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	#endif
	KL_I2C3_hdma_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
	KL_I2C3_hdma_tx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_I2C3_hdma_tx.Init.MemInc = DMA_MINC_ENABLE;
	KL_I2C3_hdma_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_I2C3_hdma_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_I2C3_hdma_tx.Init.Mode = DMA_NORMAL;
	KL_I2C3_hdma_tx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&KL_I2C3_hdma_tx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_I2C3_hi2c,hdmatx,KL_I2C3_hdma_tx);
	#endif
	/*************/
	
	/*************/
	#if KL_I2C3_USE_DMA_Rx == 1
	#if defined (STM32F1)
	HAL_NVIC_SetPriority(KL_I2C3_DMA1_Rx_Channel_IRQn, KL_I2C3_DMA_IRQ_PreemptPriority, KL_I2C3_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C3_DMA1_Rx_Channel_IRQn);
	KL_I2C3_hdma_rx.Instance = KL_I2C3_DMA1_Rx_Channel;
	#else
	HAL_NVIC_SetPriority(KL_I2C3_DMA1_Rx_Stream_IRQn, KL_I2C3_DMA_IRQ_PreemptPriority, KL_I2C3_DMA_IRQ_SubPriority);
	HAL_NVIC_EnableIRQ(KL_I2C3_DMA1_Rx_Stream_IRQn);
	KL_I2C3_hdma_rx.Instance = KL_I2C3_DMA1_Rx_Stream;
	KL_I2C3_hdma_rx.Init.Channel = KL_I2C3_DMA_Rx_CHANNEL;
	KL_I2C3_hdma_rx.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	KL_I2C3_hdma_rx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	KL_I2C3_hdma_rx.Init.MemBurst = DMA_MBURST_INC16;
	KL_I2C3_hdma_rx.Init.PeriphBurst = DMA_PBURST_SINGLE;
	#endif
	KL_I2C3_hdma_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
	KL_I2C3_hdma_rx.Init.PeriphInc = DMA_PINC_DISABLE;
	KL_I2C3_hdma_rx.Init.MemInc = DMA_MINC_ENABLE;
	KL_I2C3_hdma_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	KL_I2C3_hdma_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	KL_I2C3_hdma_rx.Init.Mode = DMA_NORMAL;
	KL_I2C3_hdma_rx.Init.Priority = DMA_PRIORITY_LOW;
	if (HAL_DMA_Init(&KL_I2C3_hdma_rx) != HAL_OK) return KL_ERROR;
	__HAL_LINKDMA(&KL_I2C3_hi2c,hdmarx,KL_I2C3_hdma_rx);
	#endif
	/*************/
	KL_I2C3_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
#endif
	return KL_OK;
}

/* KL_I2C硬件FMPI2C 引脚接口初始化 */
KL_Status KL_FMPI2C_PIN_Init(void)
{
#if KL_FMPI2C_Enable == 1
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	
	GPIO_InitStruct.Alternate = KL_FMPI2C_SCL_AF;
	GPIO_InitStruct.Pin = KL_FMPI2C_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(KL_FMPI2C_SCL_Port, &GPIO_InitStruct);

	GPIO_InitStruct.Alternate = KL_FMPI2C_SDA_AF;
	GPIO_InitStruct.Pin = KL_FMPI2C_Pin_SDA;
	HAL_GPIO_Init(KL_FMPI2C_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C1 引脚接口初始化 */
KL_Status KL_I2C1_PIN_Init(void)
{
#if KL_I2C1_Enable == 1
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	#if defined (STM32F1)
	#if KL_I2C1_USE_AFIO == 1
		__HAL_AFIO_REMAP_I2C1_ENABLE();
	#endif
	#endif
	
	#if !defined (STM32F1)
		GPIO_InitStruct.Alternate = KL_I2C1_SCL_AF;
	#endif
	GPIO_InitStruct.Pin = KL_I2C1_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(KL_I2C1_SCL_Port, &GPIO_InitStruct);

	#if !defined (STM32F1)
		GPIO_InitStruct.Alternate = KL_I2C1_SDA_AF;
	#endif
	GPIO_InitStruct.Pin = KL_I2C1_Pin_SDA;
	HAL_GPIO_Init(KL_I2C1_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C2 引脚接口初始化 */
KL_Status KL_I2C2_PIN_Init(void)
{
#if KL_I2C2_Enable == 1
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	#if defined (STM32F1)
	#if KL_I2C2_USE_AFIO == 1
		__HAL_AFIO_REMAP_I2C2_ENABLE();
	#endif
	#endif
	
	#if !defined (STM32F1)
		GPIO_InitStruct.Alternate = KL_I2C2_SCL_AF;
	#endif
	GPIO_InitStruct.Pin = KL_I2C2_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(KL_I2C2_SCL_Port, &GPIO_InitStruct);

	#if !defined (STM32F1)
		GPIO_InitStruct.Alternate = KL_I2C2_SDA_AF;
	#endif
	GPIO_InitStruct.Pin = KL_I2C2_Pin_SDA;
	HAL_GPIO_Init(KL_I2C2_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C3 引脚接口初始化 */
KL_Status KL_I2C3_PIN_Init(void)
{
#if KL_I2C3_Enable == 1
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	#if defined (STM32F1)
	#if KL_I2C3_USE_AFIO == 1
		__HAL_AFIO_REMAP_I2C3_ENABLE();
	#endif
	#endif
	
	#if !defined (STM32F1)
		GPIO_InitStruct.Alternate = KL_I2C3_SCL_AF;
	#endif
	GPIO_InitStruct.Pin = KL_I2C3_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(KL_I2C3_SCL_Port, &GPIO_InitStruct);

	#if !defined (STM32F1)
		GPIO_InitStruct.Alternate = KL_I2C3_SDA_AF;
	#endif
	GPIO_InitStruct.Pin = KL_I2C3_Pin_SDA;
	HAL_GPIO_Init(KL_I2C3_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件FMPI2C初始化 */
KL_Status KL_FMPI2C_Hardware_Init(void)
{
	if(KL_FMPI2C_PIN_Init() != KL_OK) return KL_ERROR;
	if(KL_FMPI2C_Bus_Init() != KL_OK) return KL_ERROR;
	if(KL_FMPI2C_DMA_Init() != KL_OK) return KL_ERROR;
	return KL_OK;
}

/* KL_I2C硬件I2C1初始化 */
KL_Status KL_I2C1_Hardware_Init(void)
{
	if(KL_I2C1_PIN_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C1_Bus_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C1_DMA_Init() != KL_OK) return KL_ERROR;
	return KL_OK;
}

/* KL_I2C硬件I2C2初始化 */
KL_Status KL_I2C2_Hardware_Init(void)
{
	if(KL_I2C2_PIN_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C2_Bus_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C2_DMA_Init() != KL_OK) return KL_ERROR;
	return KL_OK;
}

/* KL_I2C硬件I2C3初始化 */
KL_Status KL_I2C3_Hardware_Init(void)
{
	if(KL_I2C3_PIN_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C3_Bus_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C3_DMA_Init() != KL_OK) return KL_ERROR;
	return KL_OK;
}

/* KL_I2C硬件I2C初始化 */
KL_Status KL_I2C_Hardware_Init(void)
{
	if(KL_FMPI2C_Hardware_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C1_Hardware_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C2_Hardware_Init() != KL_OK) return KL_ERROR;
	if(KL_I2C3_Hardware_Init() != KL_OK) return KL_ERROR;
	return KL_OK;
}
#else
KL_Status KL_I2C_Hardware_Init(void)
{
	#if KL_FMPI2C_Enable == 1
	KL_FMPI2C_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
	#endif
	#if KL_I2C1_Enable == 1
	KL_I2C1_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
	#endif
	#if KL_I2C2_Enable == 1
	KL_I2C2_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
	#endif
	#if KL_I2C3_Enable == 1
	KL_I2C3_Handle.KL_I2C_State_Register.bits.Init_ed = 1;
	#endif
	return KL_OK;
}

#endif

#if USE_SIMPLE_INIT == 1
/* KL_I2C硬件FMPI2C反初始化 */
KL_Status KL_FMPI2C_Hardware_DeInit(void)
{
#if KL_FMPI2C_Enable == 1
	KL_FMPI2C_Handle.KL_I2C_State_Register.bits.Init_ed = 0;
	/* ===========================硬件I2C总线反初始化=========================== */
	if(HAL_FMPI2C_DeInit(&KL_FMPI2C_hi2c) != HAL_OK) return KL_ERROR;
	__HAL_RCC_FMPI2C1_CLK_DISABLE();
	HAL_NVIC_DisableIRQ(FMPI2C1_EV_IRQn);
	HAL_NVIC_DisableIRQ(FMPI2C1_ER_IRQn);
	
	/* ===========================总线DMA外设反初始化=========================== */
	/*************/
	#if KL_FMPI2C_USE_DMA_Tx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_FMPI2C_hdma_tx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	HAL_NVIC_DisableIRQ(KL_FMPI2C_DMA1_Tx_Stream_IRQn);
	#endif
	/*************/
	
	/*************/
	#if KL_FMPI2C_USE_DMA_Rx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_FMPI2C_hdma_rx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	HAL_NVIC_DisableIRQ(KL_FMPI2C_DMA1_Rx_Stream_IRQn);
	#endif
	/*************/
	
	/* ===========================引脚反初始化=========================== */
	/* 将GPIO引脚恢复为默认状态（模拟输入）以降低功耗 */
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* 配置SCL引脚 */
	GPIO_InitStruct.Pin = KL_FMPI2C_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;  /* 模拟模式，减小功耗 */
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(KL_FMPI2C_SCL_Port, &GPIO_InitStruct);

	/* 配置SDA引脚 */
	GPIO_InitStruct.Pin = KL_FMPI2C_Pin_SDA;
	HAL_GPIO_Init(KL_FMPI2C_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C1反初始化 */
KL_Status KL_I2C1_Hardware_DeInit(void)
{
#if KL_I2C1_Enable == 1
	KL_I2C1_Handle.KL_I2C_State_Register.bits.Init_ed = 0;
	/* ===========================硬件I2C总线反初始化=========================== */
	if(HAL_I2C_DeInit(&KL_I2C1_hi2c) != HAL_OK) return KL_ERROR;
	__HAL_RCC_I2C1_CLK_DISABLE();
	HAL_NVIC_DisableIRQ(I2C1_EV_IRQn);
	HAL_NVIC_DisableIRQ(I2C1_ER_IRQn);
	#if defined (STM32F1)
		#if KL_I2C1_USE_AFIO == 1
		__HAL_AFIO_REMAP_I2C1_DISABLE();
		#endif
	#endif
	
	/* ===========================总线DMA外设反初始化=========================== */
	/*************/
	#if KL_I2C1_USE_DMA_Tx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_I2C1_hdma_tx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	#if defined (STM32F1)
		HAL_NVIC_DisableIRQ(KL_I2C1_DMA1_Tx_Channel_IRQn);
	#else
		HAL_NVIC_DisableIRQ(KL_I2C1_DMA1_Tx_Stream_IRQn);
	#endif
	#endif
	/*************/
	
	/*************/
	#if KL_I2C1_USE_DMA_Rx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_I2C1_hdma_rx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	#if defined (STM32F1)
		HAL_NVIC_DisableIRQ(KL_I2C1_DMA1_Rx_Channel_IRQn);
	#else
		HAL_NVIC_DisableIRQ(KL_I2C1_DMA1_Rx_Stream_IRQn);
	#endif
	#endif
	/*************/
	
	/* ===========================引脚反初始化=========================== */
	/* 将GPIO引脚恢复为默认状态（模拟输入）以降低功耗 */
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* 配置SCL引脚 */
	GPIO_InitStruct.Pin = KL_I2C1_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;  /* 模拟模式，减小功耗 */
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(KL_I2C1_SCL_Port, &GPIO_InitStruct);

	/* 配置SDA引脚 */
	GPIO_InitStruct.Pin = KL_I2C1_Pin_SDA;
	HAL_GPIO_Init(KL_I2C1_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C2反初始化 */
KL_Status KL_I2C2_Hardware_DeInit(void)
{
#if KL_I2C2_Enable == 1
	KL_I2C2_Handle.KL_I2C_State_Register.bits.Init_ed = 0;
	/* ===========================硬件I2C总线反初始化=========================== */
	if(HAL_I2C_DeInit(&KL_I2C2_hi2c) != HAL_OK) return KL_ERROR;
	__HAL_RCC_I2C2_CLK_DISABLE();
	HAL_NVIC_DisableIRQ(I2C2_EV_IRQn);
	HAL_NVIC_DisableIRQ(I2C2_ER_IRQn);
	#if defined (STM32F1)
		#if KL_I2C2_USE_AFIO == 1
		__HAL_AFIO_REMAP_I2C2_DISABLE();
		#endif
	#endif
	
	/* ===========================总线DMA外设反初始化=========================== */
	/*************/
	#if KL_I2C2_USE_DMA_Tx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_I2C2_hdma_tx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	#if defined (STM32F1)
		HAL_NVIC_DisableIRQ(KL_I2C2_DMA1_Tx_Channel_IRQn);
	#else
		HAL_NVIC_DisableIRQ(KL_I2C2_DMA1_Tx_Stream_IRQn);
	#endif
	#endif
	/*************/
	
	/*************/
	#if KL_I2C2_USE_DMA_Rx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_I2C2_hdma_rx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	#if defined (STM32F1)
		HAL_NVIC_DisableIRQ(KL_I2C2_DMA1_Rx_Channel_IRQn);
	#else
		HAL_NVIC_DisableIRQ(KL_I2C2_DMA1_Rx_Stream_IRQn);
	#endif
	#endif
	/*************/
	
	/* ===========================引脚反初始化=========================== */
	/* 将GPIO引脚恢复为默认状态（模拟输入）以降低功耗 */
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* 配置SCL引脚 */
	GPIO_InitStruct.Pin = KL_I2C2_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;  /* 模拟模式，减小功耗 */
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(KL_I2C2_SCL_Port, &GPIO_InitStruct);

	/* 配置SDA引脚 */
	GPIO_InitStruct.Pin = KL_I2C2_Pin_SDA;
	HAL_GPIO_Init(KL_I2C2_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}

/* KL_I2C硬件I2C3反初始化 */
KL_Status KL_I2C3_Hardware_DeInit(void)
{
#if KL_I2C3_Enable == 1
	KL_I2C3_Handle.KL_I2C_State_Register.bits.Init_ed = 0;
	/* ===========================硬件I2C总线反初始化=========================== */
	if(HAL_I2C_DeInit(&KL_I2C3_hi2c) != HAL_OK) return KL_ERROR;
	__HAL_RCC_I2C3_CLK_DISABLE();
	HAL_NVIC_DisableIRQ(I2C3_EV_IRQn);
	HAL_NVIC_DisableIRQ(I2C3_ER_IRQn);
	#if defined (STM32F1)
		#if KL_I2C3_USE_AFIO == 1
		__HAL_AFIO_REMAP_I2C3_DISABLE();
		#endif
	#endif
	
	/* ===========================总线DMA外设反初始化=========================== */
	/*************/
	#if KL_I2C3_USE_DMA_Tx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_I2C3_hdma_tx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	#if defined (STM32F1)
		HAL_NVIC_DisableIRQ(KL_I2C3_DMA1_Tx_Channel_IRQn);
	#else
		HAL_NVIC_DisableIRQ(KL_I2C3_DMA1_Tx_Stream_IRQn);
	#endif
	#endif
	/*************/
	
	/*************/
	#if KL_I2C3_USE_DMA_Rx == 1
	/* 停止并反初始化DMA */
	if(HAL_DMA_DeInit(&KL_I2C3_hdma_rx) != HAL_OK) return KL_ERROR;
	/* 禁用DMA中断 */
	#if defined (STM32F1)
		HAL_NVIC_DisableIRQ(KL_I2C3_DMA1_Rx_Channel_IRQn);
	#else
		HAL_NVIC_DisableIRQ(KL_I2C3_DMA1_Rx_Stream_IRQn);
	#endif
	#endif
	/*************/
	
	/* ===========================引脚反初始化=========================== */
	/* 将GPIO引脚恢复为默认状态（模拟输入）以降低功耗 */
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* 配置SCL引脚 */
	GPIO_InitStruct.Pin = KL_I2C3_Pin_SCL;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;  /* 模拟模式，减小功耗 */
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(KL_I2C3_SCL_Port, &GPIO_InitStruct);

	/* 配置SDA引脚 */
	GPIO_InitStruct.Pin = KL_I2C3_Pin_SDA;
	HAL_GPIO_Init(KL_I2C3_SDA_Port, &GPIO_InitStruct);
#endif
	return KL_OK;
}
#endif

//中断函数配置
#if USE_SIMPLE_INIT == 1
#if KL_FMPI2C_Enable == 1
void FMPI2C1_EV_IRQHandler(void)
{ HAL_FMPI2C_EV_IRQHandler(&KL_FMPI2C_hi2c); }
void FMPI2C1_ER_IRQHandler(void)
{ HAL_FMPI2C_ER_IRQHandler(&KL_FMPI2C_hi2c); }
	#if KL_FMPI2C_USE_DMA_Tx == 1
		#if defined (STM32F1)
			#if KL_FMPI2C_DMA_Tx_Line == 0
			void DMA1_Channel0_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 1
			void DMA1_Channel1_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 2
			void DMA1_Channel2_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 3
			void DMA1_Channel3_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 4
			void DMA1_Channel4_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 5
			void DMA1_Channel5_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 6
			void DMA1_Channel6_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 7
			void DMA1_Channel7_IRQHandler(void)
			#endif
		#else
			#if KL_FMPI2C_DMA_Tx_Line == 0
			void DMA1_Stream0_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 1
			void DMA1_Stream1_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 2
			void DMA1_Stream2_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 3
			void DMA1_Stream3_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 4
			void DMA1_Stream4_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 5
			void DMA1_Stream5_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 6
			void DMA1_Stream6_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Tx_Line == 7
			void DMA1_Stream7_IRQHandler(void)
			#endif
		#endif
		{ HAL_DMA_IRQHandler(&KL_FMPI2C_hdma_tx); }
	#endif
	#if KL_FMPI2C_USE_DMA_Rx == 1
		#if defined (STM32F1)
			#if KL_FMPI2C_DMA_Rx_Line == 0
			void DMA1_Channel0_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 1
			void DMA1_Channel1_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 2
			void DMA1_Channel2_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 3
			void DMA1_Channel3_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 4
			void DMA1_Channel4_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 5
			void DMA1_Channel5_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 6
			void DMA1_Channel6_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 7
			void DMA1_Channel7_IRQHandler(void)
			#endif
		#else
			#if KL_FMPI2C_DMA_Rx_Line == 0
			void DMA1_Stream0_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 1
			void DMA1_Stream1_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 2
			void DMA1_Stream2_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 3
			void DMA1_Stream3_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 4
			void DMA1_Stream4_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 5
			void DMA1_Stream5_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 6
			void DMA1_Stream6_IRQHandler(void)
			#elif KL_FMPI2C_DMA_Rx_Line == 7
			void DMA1_Stream7_IRQHandler(void)
			#endif
		#endif
		{ HAL_DMA_IRQHandler(&KL_FMPI2C_hdma_rx); }
	#endif
#endif

#if KL_I2C1_Enable == 1
void I2C1_EV_IRQHandler(void)
{ HAL_I2C_EV_IRQHandler(&KL_I2C1_hi2c); }
void I2C1_ER_IRQHandler(void)
{ HAL_I2C_ER_IRQHandler(&KL_I2C1_hi2c); }
	#if KL_I2C1_USE_DMA_Tx == 1
		#if defined (STM32F1)
			#if KL_I2C1_DMA_Tx_Line == 0
			void DMA1_Channel0_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 1
			void DMA1_Channel1_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 2
			void DMA1_Channel2_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 3
			void DMA1_Channel3_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 4
			void DMA1_Channel4_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 5
			void DMA1_Channel5_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 6
			void DMA1_Channel6_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 7
			void DMA1_Channel7_IRQHandler(void)
			#endif
		#else
			#if KL_I2C1_DMA_Tx_Line == 0
			void DMA1_Stream0_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 1
			void DMA1_Stream1_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 2
			void DMA1_Stream2_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 3
			void DMA1_Stream3_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 4
			void DMA1_Stream4_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 5
			void DMA1_Stream5_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 6
			void DMA1_Stream6_IRQHandler(void)
			#elif KL_I2C1_DMA_Tx_Line == 7
			void DMA1_Stream7_IRQHandler(void)
			#endif
		#endif
		{ HAL_DMA_IRQHandler(&KL_I2C1_hdma_tx); }
	#endif
	#if KL_I2C1_USE_DMA_Rx == 1
		#if defined (STM32F1)
			#if KL_I2C1_DMA_Rx_Line == 0
			void DMA1_Channel0_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 1
			void DMA1_Channel1_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 2
			void DMA1_Channel2_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 3
			void DMA1_Channel3_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 4
			void DMA1_Channel4_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 5
			void DMA1_Channel5_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 6
			void DMA1_Channel6_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 7
			void DMA1_Channel7_IRQHandler(void)
			#endif
		#else
			#if KL_I2C1_DMA_Rx_Line == 0
			void DMA1_Stream0_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 1
			void DMA1_Stream1_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 2
			void DMA1_Stream2_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 3
			void DMA1_Stream3_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 4
			void DMA1_Stream4_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 5
			void DMA1_Stream5_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 6
			void DMA1_Stream6_IRQHandler(void)
			#elif KL_I2C1_DMA_Rx_Line == 7
			void DMA1_Stream7_IRQHandler(void)
			#endif
		#endif
		{ HAL_DMA_IRQHandler(&KL_I2C1_hdma_rx); }
	#endif
#endif

#if KL_I2C2_Enable == 1
void I2C2_EV_IRQHandler(void)
{ HAL_I2C_EV_IRQHandler(&KL_I2C2_hi2c); }
void I2C2_ER_IRQHandler(void)
{ HAL_I2C_ER_IRQHandler(&KL_I2C2_hi2c); }
#if KL_I2C2_USE_DMA_Tx == 1
	#if defined (STM32F1)
		#if KL_I2C2_DMA_Tx_Line == 0
		void DMA1_Channel0_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 1
		void DMA1_Channel1_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 2
		void DMA1_Channel2_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 3
		void DMA1_Channel3_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 4
		void DMA1_Channel4_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 5
		void DMA1_Channel5_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 6
		void DMA1_Channel6_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 7
		void DMA1_Channel7_IRQHandler(void)
		#endif
	#else
		#if KL_I2C2_DMA_Tx_Line == 0
		void DMA1_Stream0_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 1
		void DMA1_Stream1_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 2
		void DMA1_Stream2_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 3
		void DMA1_Stream3_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 4
		void DMA1_Stream4_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 5
		void DMA1_Stream5_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 6
		void DMA1_Stream6_IRQHandler(void)
		#elif KL_I2C2_DMA_Tx_Line == 7
		void DMA1_Stream7_IRQHandler(void)
		#endif
	#endif
	{ HAL_DMA_IRQHandler(&KL_I2C2_hdma_tx); }
#endif
#if KL_I2C2_USE_DMA_Rx == 1
	#if defined (STM32F1)
		#if KL_I2C2_DMA_Rx_Line == 0
		void DMA1_Channel0_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 1
		void DMA1_Channel1_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 2
		void DMA1_Channel2_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 3
		void DMA1_Channel3_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 4
		void DMA1_Channel4_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 5
		void DMA1_Channel5_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 6
		void DMA1_Channel6_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 7
		void DMA1_Channel7_IRQHandler(void)
		#endif
	#else
		#if KL_I2C2_DMA_Rx_Line == 0
		void DMA1_Stream0_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 1
		void DMA1_Stream1_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 2
		void DMA1_Stream2_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 3
		void DMA1_Stream3_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 4
		void DMA1_Stream4_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 5
		void DMA1_Stream5_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 6
		void DMA1_Stream6_IRQHandler(void)
		#elif KL_I2C2_DMA_Rx_Line == 7
		void DMA1_Stream7_IRQHandler(void)
		#endif
	#endif
	{ HAL_DMA_IRQHandler(&KL_I2C2_hdma_rx); }
#endif
#endif

#if KL_I2C3_Enable == 1
void I2C3_EV_IRQHandler(void)
{ HAL_I2C_EV_IRQHandler(&KL_I2C3_hi2c); }
void I2C3_ER_IRQHandler(void)
{ HAL_I2C_ER_IRQHandler(&KL_I2C3_hi2c); }
#if KL_I2C3_USE_DMA_Tx == 1
	#if defined (STM32F1)
		#if KL_I2C3_DMA_Tx_Line == 0
		void DMA1_Channel0_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 1
		void DMA1_Channel1_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 2
		void DMA1_Channel2_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 3
		void DMA1_Channel3_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 4
		void DMA1_Channel4_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 5
		void DMA1_Channel5_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 6
		void DMA1_Channel6_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 7
		void DMA1_Channel7_IRQHandler(void)
		#endif
	#else
		#if KL_I2C3_DMA_Tx_Line == 0
		void DMA1_Stream0_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 1
		void DMA1_Stream1_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 2
		void DMA1_Stream2_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 3
		void DMA1_Stream3_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 4
		void DMA1_Stream4_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 5
		void DMA1_Stream5_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 6
		void DMA1_Stream6_IRQHandler(void)
		#elif KL_I2C3_DMA_Tx_Line == 7
		void DMA1_Stream7_IRQHandler(void)
		#endif
	#endif
	{ HAL_DMA_IRQHandler(&KL_I2C3_hdma_tx); }
#endif
#if KL_I2C3_USE_DMA_Rx == 1
	#if defined (STM32F1)
		#if KL_I2C3_DMA_Rx_Line == 0
		void DMA1_Channel0_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 1
		void DMA1_Channel1_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 2
		void DMA1_Channel2_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 3
		void DMA1_Channel3_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 4
		void DMA1_Channel4_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 5
		void DMA1_Channel5_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 6
		void DMA1_Channel6_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 7
		void DMA1_Channel7_IRQHandler(void)
		#endif
	#else
		#if KL_I2C3_DMA_Rx_Line == 0
		void DMA1_Stream0_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 1
		void DMA1_Stream1_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 2
		void DMA1_Stream2_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 3
		void DMA1_Stream3_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 4
		void DMA1_Stream4_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 5
		void DMA1_Stream5_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 6
		void DMA1_Stream6_IRQHandler(void)
		#elif KL_I2C3_DMA_Rx_Line == 7
		void DMA1_Stream7_IRQHandler(void)
		#endif
	#endif
	{ HAL_DMA_IRQHandler(&KL_I2C3_hdma_rx); }
#endif
#endif
#endif

//中断回调函数配置
#if KL_FMPI2C_Enable == 1
void HAL_FMPI2C_MasterTxCpltCallback(FMPI2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance == KL_FMPI2C)
    {
		KL_I2C_IT(&KL_FMPI2C_Handle, 1);
    }
}

void HAL_FMPI2C_MasterRxCpltCallback(FMPI2C_HandleTypeDef *hi2c)
{
    if (hi2c->Instance == KL_FMPI2C)
    {
		KL_I2C_IT(&KL_FMPI2C_Handle, 1);
    }
}

void HAL_FMPI2C_ErrorCallback(FMPI2C_HandleTypeDef *hi2c)
{
	if (hi2c->Instance == KL_FMPI2C)
    {
		KL_I2C_IT(&KL_FMPI2C_Handle, 0);
    }
}
#endif

void HAL_I2C_MasterTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
	#if KL_I2C1_Enable == 1
    if (hi2c->Instance == KL_I2C1)
    {
		KL_I2C_IT(&KL_I2C1_Handle, 1);
    }
	#endif
	#if KL_I2C2_Enable == 1
	if (hi2c->Instance == KL_I2C2)
    {
		KL_I2C_IT(&KL_I2C2_Handle, 1);
    }
	#endif
	#if KL_I2C3_Enable == 1
	if (hi2c->Instance == KL_I2C3)
    {
		KL_I2C_IT(&KL_I2C3_Handle, 1);
    }
	#endif
}

void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
	#if KL_I2C1_Enable == 1
    if (hi2c->Instance == KL_I2C1)
    {
		KL_I2C_IT(&KL_I2C1_Handle, 1);
    }
	#endif
	#if KL_I2C2_Enable == 1
	if (hi2c->Instance == KL_I2C2)
    {
		KL_I2C_IT(&KL_I2C2_Handle, 1);
    }
	#endif
	#if KL_I2C3_Enable == 1
	if (hi2c->Instance == KL_I2C3)
    {
		KL_I2C_IT(&KL_I2C3_Handle, 1);
    }
	#endif
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
	#if KL_I2C1_Enable == 1
    if (hi2c->Instance == KL_I2C1)
    {
		KL_I2C_IT(&KL_I2C1_Handle, 0);
    }
	#endif
	#if KL_I2C2_Enable == 1
	if (hi2c->Instance == KL_I2C2)
    {
		KL_I2C_IT(&KL_I2C2_Handle, 0);
    }
	#endif
	#if KL_I2C3_Enable == 1
	if (hi2c->Instance == KL_I2C3)
    {
		KL_I2C_IT(&KL_I2C3_Handle, 0);
    }
	#endif
}

