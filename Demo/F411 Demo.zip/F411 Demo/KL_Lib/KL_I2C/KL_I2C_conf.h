#ifndef _KL_I2C_CONF_H_
#define _KL_I2C_CONF_H_

/* ============================================================================
							 KL_I2C配置规范示例文件
 ============================================================================*/

/* ============================================================================
								   KL_I2C说明书
1. 需要使用哪条总线就设置KL_I2Cx_Enable	(1)

2. 全异步任务管理功能。用户在设置时，可以选择不使用自带的任务管理，自己实现
传输逻辑。任务管理使能时中断回调逻辑由本程序接管，用户无需自行配置，开箱即用。
不使能时程序仅提供硬件全自动配置和中断接口初始化（类似CubeMX），此时中断回调
需用户自行实现。

3. 关闭DMA时，驱动会自动切换为中断方式传输，系统仍保持完全无阻塞；使用全异步
任务管理时，严禁调用HAL库原生I2C收发函数，否则极易引发总线冲突。

4. 全异步任务管理为全局使能配置，不支持单总线独立开关。使能后，库将全权接管所
有I2C总线中断回调逻辑，实现总线独占式安全调度。
 ============================================================================*/

/* 包含对应平台的头文件 */
#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"

/* I2C外设句柄结构体绑定 */
// 为适配F4平台在下方定义Hardware_I2C_HandleTypeDef

/* ==============以下为详细硬件配置管理部分============== */
/* 如果使用CubeMX生成代码，将USE_SIMPLE_INIT置0 */
#define USE_SIMPLE_INIT					(1)

/* 当芯片中有多个I2C外设需要管理时的示例 */
/* 硬件I2C线路使用情况 */
/* 适配部分型号FMPI2C  */
#define KL_FMPI2C_Enable				(0)
#define KL_I2C1_Enable					(0)
#define KL_I2C2_Enable					(1)
#define KL_I2C3_Enable					(1)

typedef struct Hardware_I2C_HandleTypeDef
{
	I2C_HandleTypeDef* I2C_Handle;
	#if KL_FMPI2C_Enable == 1
	FMPI2C_HandleTypeDef* FMPI2C_Handle;
	#endif
} Hardware_I2C_HandleTypeDef;

/* 增强性I2C总线配置 */
#if KL_FMPI2C_Enable == 1
/* 基础配置项目 */
/* 传输任务队列配置 */
#define KL_FMPI2C_Task_Queue_Len			(16)
#define KL_FMPI2C_USE_DMA_Tx				(1)		// DMA外设选择(Tx)
#define KL_FMPI2C_USE_DMA_Rx				(1)		// DMA外设选择(Rx)

/* Simple Init配置参数 */
#if USE_SIMPLE_INIT == 1
/* F1系列无此外设故排除 */
#if !defined (STM32F1)
/* 引脚使用情况 */
//注意：驱动不会打开对应GPIO的时钟，请在初始化前先自行开启对应的时钟
//__HAL_RCC_GPIOx_CLK_ENABLE();
#define KL_FMPI2C_SCL_Port		GPIOB
#define KL_FMPI2C_SDA_Port		GPIOB
#define KL_FMPI2C_Pin_SCL		GPIO_PIN_15
#define KL_FMPI2C_Pin_SDA   	GPIO_PIN_14

#define KL_FMPI2C_SCL_AF		GPIO_AF4_FMPI2C1
#define KL_FMPI2C_SDA_AF		GPIO_AF4_FMPI2C1

/* 总线速度配置 */
/* 通过STM32CubeMX计算或自行根据实际情况微调 */
#define KL_FMPI2C_ClockSelection			RCC_FMPI2C1CLKSOURCE_PCLK1
#define KL_FMPI2C_Timing					(0)
/* 总线地址模式 */
#define KL_FMPI2C_Addr_Mode					FMPI2C_ADDRESSINGMODE_7BIT

/* DMA通道使用情况，根据手册进行配置 */
/* 0不使用DMA 1使用DMA1 2使用DMA2 */
/* 发送DMA配置 */
#if KL_FMPI2C_USE_DMA_Tx != 0
	#define KL_FMPI2C_DMA_Tx_Line			(1)		// DMA数据流选择
	
	#define KL_FMPI2C_DMA_Tx_Channel		(2)		// 数据流通道配置
#endif
/* 接收DMA配置 */
#if KL_FMPI2C_USE_DMA_Rx != 0
	#define KL_FMPI2C_DMA_Rx_Line			(0)		// DMA数据流选择
	
	#define KL_FMPI2C_DMA_Rx_Channel		(7)		// 数据流通道配置
#endif

/* 中断优先级设置 */
#define KL_FMPI2C_EV_IRQ_PreemptPriority	(2)
#define KL_FMPI2C_EV_IRQ_SubPriority		(0)
#define KL_FMPI2C_ER_IRQ_PreemptPriority	(2)
#define KL_FMPI2C_ER_IRQ_SubPriority		(0)
#define KL_FMPI2C_DMA_IRQ_PreemptPriority	(2)
#define KL_FMPI2C_DMA_IRQ_SubPriority		(0)
#endif
#endif
#endif

/* I2C1总线配置 */
#if KL_I2C1_Enable == 1
/* 基础配置项目 */
/* 传输任务队列配置 */
#define KL_I2C1_Task_Queue_Len				(16)
#define KL_I2C1_USE_DMA_Tx					(1)		// DMA外设选择(Tx)
#define KL_I2C1_USE_DMA_Rx					(1)		// DMA外设选择(Rx)

/* Simple Init配置参数 */
#if USE_SIMPLE_INIT == 1
/* 引脚使用情况 */
//注意：驱动不会打开对应GPIO的时钟，请在初始化前先自行开启对应的时钟
//__HAL_RCC_GPIOx_CLK_ENABLE();
#define KL_I2C1_SCL_Port		GPIOB
#define KL_I2C1_SDA_Port		GPIOB
#define KL_I2C1_Pin_SCL			GPIO_PIN_8
#define KL_I2C1_Pin_SDA   		GPIO_PIN_9

/* 兼容F1系列引脚重映射 */
#if defined (STM32F1)
	#define KL_I2C1_USE_AFIO			(1)
#else
	#define KL_I2C1_SCL_AF				GPIO_AF4_I2C1
	#define KL_I2C1_SDA_AF				GPIO_AF4_I2C1
#endif

/* 总线速度配置 */
#define KL_I2C1_SPEED_KHz				(400)
/* 总线地址模式 */
#define KL_I2C1_Addr_Mode				I2C_ADDRESSINGMODE_7BIT

/* DMA通道使用情况，根据手册进行配置 */
/* 0不使用DMA 1使用DMA1 2使用DMA2 */
/* 发送DMA配置 */
#if KL_I2C1_USE_DMA_Tx != 0
	#define KL_I2C1_DMA_Tx_Line			(6)		// DMA通道(F1)/数据流(F4)选择
	#if !defined (STM32F1)
		#define KL_I2C1_DMA_Tx_Channel	(1)		// 对F4平台需要为数据流配置通道
	#endif
#endif
/* 接收DMA配置 */
#if KL_I2C1_USE_DMA_Rx != 0
	#define KL_I2C1_DMA_Rx_Line			(0)		// DMA通道(F1)/数据流(F4)选择
	#if !defined (STM32F1)
		#define KL_I2C1_DMA_Rx_Channel	(1)		// 对F4平台需要为数据流配置通道
	#endif
#endif

/* 中断优先级设置 */
#define KL_I2C1_EV_IRQ_PreemptPriority	(2)
#define KL_I2C1_EV_IRQ_SubPriority		(0)
#define KL_I2C1_ER_IRQ_PreemptPriority	(2)
#define KL_I2C1_ER_IRQ_SubPriority		(0)
#define KL_I2C1_DMA_IRQ_PreemptPriority	(2)
#define KL_I2C1_DMA_IRQ_SubPriority		(0)
#endif
#endif

/* I2C2总线配置 */
#if KL_I2C2_Enable == 1
/* 基础配置项目 */
/* 传输任务队列配置 */
#define KL_I2C2_Task_Queue_Len				(32)
#define KL_I2C2_USE_DMA_Tx					(1)		// DMA外设选择(Tx)
#define KL_I2C2_USE_DMA_Rx					(1)		// DMA外设选择(Rx)

/* Simple Init配置参数 */
#if USE_SIMPLE_INIT == 1
/* 引脚使用情况 */
//注意：驱动不会打开对应GPIO的时钟，请在初始化前先自行开启对应的时钟
//__HAL_RCC_GPIOx_CLK_ENABLE();
#define KL_I2C2_SCL_Port		GPIOB
#define KL_I2C2_SDA_Port		GPIOB
#define KL_I2C2_Pin_SCL			GPIO_PIN_10
#define KL_I2C2_Pin_SDA   		GPIO_PIN_3

/* 兼容F1系列引脚重映射 */
#if defined (STM32F1)
	#define KL_I2C2_USE_AFIO			(0)
#else
	#define KL_I2C2_SCL_AF				GPIO_AF4_I2C2
	#define KL_I2C2_SDA_AF				GPIO_AF9_I2C2
#endif

/* 总线速度配置 */
#define KL_I2C2_SPEED_KHz				(400)
/* 总线地址模式 */
#define KL_I2C2_Addr_Mode				I2C_ADDRESSINGMODE_7BIT

/* DMA通道使用情况，根据手册进行配置 */
/* 0不使用DMA 1使用DMA1 2使用DMA2 */
/* 发送DMA配置 */
#if KL_I2C2_USE_DMA_Tx != 0
	#define KL_I2C2_DMA_Tx_Line			(7)		// DMA通道(F1)/数据流(F4)选择
	#if !defined (STM32F1)
		#define KL_I2C2_DMA_Tx_Channel	(7)		// 对F4平台需要为数据流配置通道
	#endif
#endif
/* 接收DMA配置 */
#if KL_I2C2_USE_DMA_Rx != 0
	#define KL_I2C2_DMA_Rx_Line			(2)		// DMA通道(F1)/数据流(F4)选择
	#if !defined (STM32F1)
		#define KL_I2C2_DMA_Rx_Channel	(7)		// 对F4平台需要为数据流配置通道
	#endif
#endif

/* 中断优先级设置 */
#define KL_I2C2_EV_IRQ_PreemptPriority	(2)
#define KL_I2C2_EV_IRQ_SubPriority		(0)
#define KL_I2C2_ER_IRQ_PreemptPriority	(2)
#define KL_I2C2_ER_IRQ_SubPriority		(0)
#define KL_I2C2_DMA_IRQ_PreemptPriority	(2)
#define KL_I2C2_DMA_IRQ_SubPriority		(0)
#endif
#endif

/* I2C3总线配置 */
#if KL_I2C3_Enable == 1
/* 基础配置项目 */
/* 传输任务队列配置 */
#define KL_I2C3_Task_Queue_Len				(16)
#define KL_I2C3_USE_DMA_Tx					(0)		// DMA外设选择(Tx)
#define KL_I2C3_USE_DMA_Rx					(0)		// DMA外设选择(Rx)

/* Simple Init配置参数 */
#if USE_SIMPLE_INIT == 1
/* 引脚使用情况 */
//注意：驱动不会打开对应GPIO的时钟，请在初始化前先自行开启对应的时钟
//__HAL_RCC_GPIOx_CLK_ENABLE();
#define KL_I2C3_SCL_Port		GPIOA
#define KL_I2C3_SDA_Port		GPIOB
#define KL_I2C3_Pin_SCL			GPIO_PIN_8
#define KL_I2C3_Pin_SDA   		GPIO_PIN_4

/* 兼容F1系列引脚重映射 */
#if defined (STM32F1)
	#define KL_I2C3_USE_AFIO			(0)
#else
	#define KL_I2C3_SCL_AF				GPIO_AF4_I2C3
	#define KL_I2C3_SDA_AF				GPIO_AF9_I2C3
#endif

/* 总线速度配置 */
#define KL_I2C3_SPEED_KHz				(400)
/* 总线地址模式 */
#define KL_I2C3_Addr_Mode				I2C_ADDRESSINGMODE_7BIT

/* DMA通道使用情况，根据手册进行配置 */
/* 0不使用DMA 1使用DMA1 2使用DMA2 */
/* 发送DMA配置 */
#if KL_I2C3_USE_DMA_Tx != 0
	#define KL_I2C3_DMA_Tx_Line			(4)		// DMA通道(F1)/数据流(F4)选择
	#if !defined (STM32F1)
		#define KL_I2C3_DMA_Tx_Channel	(3)		// 对F4平台需要为数据流配置通道
	#endif
#endif
/* 接收DMA配置 */
#if KL_I2C3_USE_DMA_Rx != 0
	#define KL_I2C3_DMA_Rx_Line			(2)		// DMA通道(F1)/数据流(F4)选择
	#if !defined (STM32F1)
		#define KL_I2C3_DMA_Rx_Channel	(3)		// 对F4平台需要为数据流配置通道
	#endif
#endif

/* 中断优先级设置 */
#define KL_I2C3_EV_IRQ_PreemptPriority	(2)
#define KL_I2C3_EV_IRQ_SubPriority		(0)
#define KL_I2C3_ER_IRQ_PreemptPriority	(2)
#define KL_I2C3_ER_IRQ_SubPriority		(0)
#define KL_I2C3_DMA_IRQ_PreemptPriority	(2)
#define KL_I2C3_DMA_IRQ_SubPriority		(0)
#endif
#endif

#endif
