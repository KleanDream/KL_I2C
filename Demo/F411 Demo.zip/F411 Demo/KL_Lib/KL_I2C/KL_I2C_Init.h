#ifndef _KL_I2C_Init_H_
#define _KL_I2C_Init_H_

#include "main.h"
#include "KL_I2C.h"
#include "KL_I2C_conf.h"

/* ===================I2C外设初始化部分支持================== */
/* 句柄命名规则兼容CubeMX风格 */
#if KL_FMPI2C_Enable == 1
#define KL_FMPI2C_hi2c		hfmpi2c1
#define KL_FMPI2C			FMPI2C1

/* FMPI2C传输完成中断函数声明 */
void FMPI2C_EV_IRQHandler(void);
void FMPI2C_ER_IRQHandler(void);
extern KL_I2C_HandleTypeDef KL_FMPI2C_Handle;
	
/* DMA相关配置(Tx) */
#if KL_FMPI2C_USE_DMA_Tx == 1
#define KL_FMPI2C_hdma_tx		hdma_fmpi2c1_tx
/*************/
#if !defined (STM32F1)
	#if KL_FMPI2C_DMA_Tx_Channel == 0
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_0
	#elif KL_FMPI2C_DMA_Tx_Channel == 1
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_1
	#elif KL_FMPI2C_DMA_Tx_Channel == 2
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_2
	#elif KL_FMPI2C_DMA_Tx_Channel == 3
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_3
	#elif KL_FMPI2C_DMA_Tx_Channel == 4
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_4
	#elif KL_FMPI2C_DMA_Tx_Channel == 5
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_5
	#elif KL_FMPI2C_DMA_Tx_Channel == 6
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_6
	#elif KL_FMPI2C_DMA_Tx_Channel == 7
		#define KL_FMPI2C_DMA_Tx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_FMPI2C_DMA_Tx_Line == 0
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel0
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream0
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 1
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel1
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream1
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 2
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel2
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream2
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 3
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel3
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream3
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 4
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel4
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream4
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 5
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel5
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream5
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 6
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel6
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream6
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_FMPI2C_DMA_Tx_Line == 7
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Tx_Channel			DMA1_Channel7
		#define KL_FMPI2C_DMA1_Tx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_FMPI2C_DMA1_Tx_Stream			DMA1_Stream7
		#define KL_FMPI2C_DMA1_Tx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_FMPI2C_DMA_Tx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_FMPI2C_DMA_Tx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Tx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/

/* DMA相关配置(Rx) */
#if KL_FMPI2C_USE_DMA_Rx == 1
#define KL_FMPI2C_hdma_rx		hdma_fmpi2c1_rx
/*************/
#if !defined (STM32F1)
	#if KL_FMPI2C_DMA_Rx_Channel == 0
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_0
	#elif KL_FMPI2C_DMA_Rx_Channel == 1
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_1
	#elif KL_FMPI2C_DMA_Rx_Channel == 2
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_2
	#elif KL_FMPI2C_DMA_Rx_Channel == 3
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_3
	#elif KL_FMPI2C_DMA_Rx_Channel == 4
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_4
	#elif KL_FMPI2C_DMA_Rx_Channel == 5
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_5
	#elif KL_FMPI2C_DMA_Rx_Channel == 6
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_6
	#elif KL_FMPI2C_DMA_Rx_Channel == 7
		#define KL_FMPI2C_DMA_Rx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_FMPI2C_DMA_Rx_Line == 0
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel0
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream0
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 1
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel1
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream1
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 2
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel2
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream2
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 3
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel3
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream3
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 4
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel4
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream4
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 5
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel5
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream5
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 6
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel6
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream6
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_FMPI2C_DMA_Rx_Line == 7
	#if defined (STM32F1)
		#define KL_FMPI2C_DMA1_Rx_Channel			DMA1_Channel7
		#define KL_FMPI2C_DMA1_Rx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_FMPI2C_DMA1_Rx_Stream			DMA1_Stream7
		#define KL_FMPI2C_DMA1_Rx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_FMPI2C_DMA_Rx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_FMPI2C_DMA_Rx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_FMPI2C_DMA_Rx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/
#endif

/* 句柄命名规则兼容CubeMX风格 */
#if KL_I2C1_Enable == 1
#define KL_I2C1_hi2c	hi2c1
#define KL_I2C1			I2C1

/* I2C1传输完成中断函数声明 */
void I2C1_EV_IRQHandler(void);
void I2C1_ER_IRQHandler(void);
extern KL_I2C_HandleTypeDef KL_I2C1_Handle;
	
/* DMA相关配置(Tx) */
#if KL_I2C1_USE_DMA_Tx == 1
#define KL_I2C1_hdma_tx		hdma_i2c1_tx
/*************/
#if !defined (STM32F1)
	#if KL_I2C1_DMA_Tx_Channel == 0
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_0
	#elif KL_I2C1_DMA_Tx_Channel == 1
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_1
	#elif KL_I2C1_DMA_Tx_Channel == 2
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_2
	#elif KL_I2C1_DMA_Tx_Channel == 3
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_3
	#elif KL_I2C1_DMA_Tx_Channel == 4
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_4
	#elif KL_I2C1_DMA_Tx_Channel == 5
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_5
	#elif KL_I2C1_DMA_Tx_Channel == 6
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_6
	#elif KL_I2C1_DMA_Tx_Channel == 7
		#define KL_I2C1_DMA_Tx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_I2C1_DMA_Tx_Line == 0
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel0
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream0
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 1
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel1
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream1
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 2
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel2
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream2
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 3
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel3
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream3
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 4
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel4
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream4
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 5
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel5
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream5
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 6
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel6
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream6
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_I2C1_DMA_Tx_Line == 7
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Tx_Channel			DMA1_Channel7
		#define KL_I2C1_DMA1_Tx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_I2C1_DMA1_Tx_Stream			DMA1_Stream7
		#define KL_I2C1_DMA1_Tx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_I2C1_DMA_Tx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_I2C1_DMA_Tx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_I2C1_DMA_Tx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/

/* DMA相关配置(Rx) */
#if KL_I2C1_USE_DMA_Rx == 1
#define KL_I2C1_hdma_rx		hdma_i2c1_rx
/*************/
#if !defined (STM32F1)
	#if KL_I2C1_DMA_Rx_Channel == 0
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_0
	#elif KL_I2C1_DMA_Rx_Channel == 1
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_1
	#elif KL_I2C1_DMA_Rx_Channel == 2
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_2
	#elif KL_I2C1_DMA_Rx_Channel == 3
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_3
	#elif KL_I2C1_DMA_Rx_Channel == 4
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_4
	#elif KL_I2C1_DMA_Rx_Channel == 5
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_5
	#elif KL_I2C1_DMA_Rx_Channel == 6
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_6
	#elif KL_I2C1_DMA_Rx_Channel == 7
		#define KL_I2C1_DMA_Rx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_I2C1_DMA_Rx_Line == 0
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel0
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream0
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 1
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel1
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream1
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 2
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel2
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream2
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 3
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel3
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream3
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 4
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel4
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream4
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 5
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel5
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream5
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 6
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel6
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream6
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_I2C1_DMA_Rx_Line == 7
	#if defined (STM32F1)
		#define KL_I2C1_DMA1_Rx_Channel			DMA1_Channel7
		#define KL_I2C1_DMA1_Rx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_I2C1_DMA1_Rx_Stream			DMA1_Stream7
		#define KL_I2C1_DMA1_Rx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_I2C1_DMA_Rx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_I2C1_DMA_Rx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_I2C1_DMA_Rx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/
#endif

/* 句柄命名规则兼容CubeMX风格 */
#if KL_I2C2_Enable == 1
#define KL_I2C2_hi2c	hi2c2
#define KL_I2C2			I2C2

/* I2C2传输完成中断函数声明 */
void I2C2_EV_IRQHandler(void);
void I2C2_ER_IRQHandler(void);
extern KL_I2C_HandleTypeDef KL_I2C2_Handle;

/* DMA相关配置(Tx) */
#if KL_I2C2_USE_DMA_Tx == 1
#define KL_I2C2_hdma_tx		hdma_i2c2_tx
/*************/
#if !defined (STM32F1)
	#if KL_I2C2_DMA_Tx_Channel == 0
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_0
	#elif KL_I2C2_DMA_Tx_Channel == 1
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_1
	#elif KL_I2C2_DMA_Tx_Channel == 2
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_2
	#elif KL_I2C2_DMA_Tx_Channel == 3
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_3
	#elif KL_I2C2_DMA_Tx_Channel == 4
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_4
	#elif KL_I2C2_DMA_Tx_Channel == 5
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_5
	#elif KL_I2C2_DMA_Tx_Channel == 6
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_6
	#elif KL_I2C2_DMA_Tx_Channel == 7
		#define KL_I2C2_DMA_Tx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_I2C2_DMA_Tx_Line == 0
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel0
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream0
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 1
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel1
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream1
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 2
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel2
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream2
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 3
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel3
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream3
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 4
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel4
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream4
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 5
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel5
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream5
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 6
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel6
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream6
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_I2C2_DMA_Tx_Line == 7
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Tx_Channel			DMA1_Channel7
		#define KL_I2C2_DMA1_Tx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_I2C2_DMA1_Tx_Stream			DMA1_Stream7
		#define KL_I2C2_DMA1_Tx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_I2C2_DMA_Tx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_I2C2_DMA_Tx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_I2C2_DMA_Tx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/

/* DMA相关配置(Rx) */
#if KL_I2C2_USE_DMA_Rx == 1
#define KL_I2C2_hdma_rx		hdma_i2c2_rx
/*************/
#if !defined (STM32F1)
	#if KL_I2C2_DMA_Rx_Channel == 0
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_0
	#elif KL_I2C2_DMA_Rx_Channel == 1
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_1
	#elif KL_I2C2_DMA_Rx_Channel == 2
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_2
	#elif KL_I2C2_DMA_Rx_Channel == 3
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_3
	#elif KL_I2C2_DMA_Rx_Channel == 4
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_4
	#elif KL_I2C2_DMA_Rx_Channel == 5
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_5
	#elif KL_I2C2_DMA_Rx_Channel == 6
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_6
	#elif KL_I2C2_DMA_Rx_Channel == 7
		#define KL_I2C2_DMA_Rx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_I2C2_DMA_Rx_Line == 0
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel0
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream0
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 1
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel1
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream1
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 2
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel2
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream2
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 3
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel3
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream3
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 4
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel4
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream4
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 5
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel5
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream5
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 6
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel6
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream6
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_I2C2_DMA_Rx_Line == 7
	#if defined (STM32F1)
		#define KL_I2C2_DMA1_Rx_Channel			DMA1_Channel7
		#define KL_I2C2_DMA1_Rx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_I2C2_DMA1_Rx_Stream			DMA1_Stream7
		#define KL_I2C2_DMA1_Rx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_I2C2_DMA_Rx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_I2C2_DMA_Rx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_I2C2_DMA_Rx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/
#endif

/* 句柄命名规则兼容CubeMX风格 */
#if KL_I2C3_Enable == 1
#define KL_I2C3_hi2c	hi2c3
#define KL_I2C3			I2C3

/* I2C3传输完成中断函数声明 */
void I2C3_EV_IRQHandler(void);
void I2C3_ER_IRQHandler(void);
extern KL_I2C_HandleTypeDef KL_I2C3_Handle;
	
/* DMA相关配置(Tx) */
#if KL_I2C3_USE_DMA_Tx == 1
#define KL_I2C3_hdma_tx		hdma_i2c3_tx
/*************/
#if !defined (STM32F1)
	#if KL_I2C3_DMA_Tx_Channel == 0
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_0
	#elif KL_I2C3_DMA_Tx_Channel == 1
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_1
	#elif KL_I2C3_DMA_Tx_Channel == 2
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_2
	#elif KL_I2C3_DMA_Tx_Channel == 3
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_3
	#elif KL_I2C3_DMA_Tx_Channel == 4
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_4
	#elif KL_I2C3_DMA_Tx_Channel == 5
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_5
	#elif KL_I2C3_DMA_Tx_Channel == 6
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_6
	#elif KL_I2C3_DMA_Tx_Channel == 7
		#define KL_I2C3_DMA_Tx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_I2C3_DMA_Tx_Line == 0
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel0
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream0
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 1
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel1
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream1
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 2
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel2
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream2
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 3
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel3
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream3
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 4
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel4
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream4
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 5
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel5
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream5
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 6
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel6
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream6
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_I2C3_DMA_Tx_Line == 7
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Tx_Channel			DMA1_Channel7
		#define KL_I2C3_DMA1_Tx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_I2C3_DMA1_Tx_Stream			DMA1_Stream7
		#define KL_I2C3_DMA1_Tx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_I2C3_DMA_Tx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_I2C3_DMA_Tx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_I2C3_DMA_Tx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/

/* DMA相关配置(Rx) */
#if KL_I2C3_USE_DMA_Rx == 1
#define KL_I2C3_hdma_rx		hdma_i2c3_rx
/*************/
#if !defined (STM32F1)
	#if KL_I2C3_DMA_Rx_Channel == 0
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_0
	#elif KL_I2C3_DMA_Rx_Channel == 1
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_1
	#elif KL_I2C3_DMA_Rx_Channel == 2
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_2
	#elif KL_I2C3_DMA_Rx_Channel == 3
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_3
	#elif KL_I2C3_DMA_Rx_Channel == 4
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_4
	#elif KL_I2C3_DMA_Rx_Channel == 5
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_5
	#elif KL_I2C3_DMA_Rx_Channel == 6
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_6
	#elif KL_I2C3_DMA_Rx_Channel == 7
		#define KL_I2C3_DMA_Rx_CHANNEL		DMA_CHANNEL_7
	#endif
#endif
/*************/

/*************/
#if KL_I2C3_DMA_Rx_Line == 0
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel0
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel0_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream0
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream0_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 1
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel1
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel1_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream1
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream1_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 2
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel2
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel2_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream2
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream2_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 3
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel3
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel3_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream3
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream3_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 4
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel4
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel4_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream4
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream4_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 5
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel5
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel5_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream5
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream5_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 6
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel6
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel6_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream6
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream6_IRQn
	#endif
#elif KL_I2C3_DMA_Rx_Line == 7
	#if defined (STM32F1)
		#define KL_I2C3_DMA1_Rx_Channel			DMA1_Channel7
		#define KL_I2C3_DMA1_Rx_Channel_IRQn	DMA1_Channel7_IRQn
	#else
		#define KL_I2C3_DMA1_Rx_Stream			DMA1_Stream7
		#define KL_I2C3_DMA1_Rx_Stream_IRQn		DMA1_Stream7_IRQn
	#endif
#endif
/*************/

/* DMA1传输完成中断函数声明 */
/*************/
#if defined (STM32F1)
	#if KL_I2C3_DMA_Rx_Line == 0
	void DMA1_Channel0_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 1
	void DMA1_Channel1_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 2
	void DMA1_Channel2_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 3
	void DMA1_Channel3_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 4
	void DMA1_Channel4_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 5
	void DMA1_Channel5_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 6
	void DMA1_Channel6_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 7
	void DMA1_Channel7_IRQHandler(void);
	#endif
#else
	#if KL_I2C3_DMA_Rx_Line == 0
	void DMA1_Stream0_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 1
	void DMA1_Stream1_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 2
	void DMA1_Stream2_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 3
	void DMA1_Stream3_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 4
	void DMA1_Stream4_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 5
	void DMA1_Stream5_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 6
	void DMA1_Stream6_IRQHandler(void);
	#elif KL_I2C3_DMA_Rx_Line == 7
	void DMA1_Stream7_IRQHandler(void);
	#endif
#endif
#endif
/*************/
#endif
/* ========================================================== */
#if KL_FMPI2C_Enable == 1
KL_Status KL_FMPI2C_Transmit_DMA(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
KL_Status KL_FMPI2C_Transmit_IT(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
KL_Status KL_FMPI2C_Receive_DMA(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
KL_Status KL_FMPI2C_Receive_IT(Hardware_I2C_HandleTypeDef* KL_FMPI2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
#endif
KL_Status KL_I2C_Transmit_DMA(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
KL_Status KL_I2C_Transmit_IT(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
KL_Status KL_I2C_Receive_DMA(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);
KL_Status KL_I2C_Receive_IT(Hardware_I2C_HandleTypeDef* KL_I2C_Hardware, uint16_t Addr, uint8_t *pData, uint16_t Size);

#if USE_SIMPLE_INIT == 1
KL_Status KL_I2C_Hardware_Init(void);
#if KL_FMPI2C_Enable == 1
KL_Status KL_FMPI2C_Hardware_DeInit(void);
#endif
KL_Status KL_I2C1_Hardware_DeInit(void);
KL_Status KL_I2C2_Hardware_DeInit(void);
KL_Status KL_I2C3_Hardware_DeInit(void);
#endif
#endif
