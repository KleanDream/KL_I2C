#ifndef __Bluetooth_H
#define __Bluetooth_H

#define Bluetooth_Tx_Pin				GPIO_PIN_2
#define Bluetooth_Tx_GPIO_Port			GPIOA
#define Bluetooth_Rx_Pin				GPIO_PIN_3
#define Bluetooth_Rx_GPIO_Port			GPIOA
#define Bluetooth_GPIO_AF				GPIO_AF7_USART2

#define Bluetooth_huart					huart2
#define Bluetooth_USE_UART				USART2

#define Bluetooth_Speed				115200

extern UART_HandleTypeDef Bluetooth_huart;
extern uint8_t Bluetooth_Transmit_Rate_Control_Parameters;

void Bluetooth_Transmit_IT(void);
void Bluetooth_Receive_IT(void);
void Bluetooth_Init(void);
void Bluetooth_Printf(char *format, ...);
#endif
