#include "main.h"
#include "Bluetooth.h"
#include "System_Core.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include "CRC.h"

UART_HandleTypeDef Bluetooth_huart;

void Bluetooth_Transmit_IT(void)
{
	
}

void Bluetooth_Receive_IT(void)
{
	
}

void Bluetooth_Pin_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOA_CLK_ENABLE();

	GPIO_InitStruct.Pin = Bluetooth_Tx_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = Bluetooth_GPIO_AF;
	HAL_GPIO_Init(Bluetooth_Tx_GPIO_Port, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = Bluetooth_Rx_Pin;
	HAL_GPIO_Init(Bluetooth_Rx_GPIO_Port, &GPIO_InitStruct);
}

void Bluetooth_Init(void)
{
	Bluetooth_Pin_Init();
	
	HAL_NVIC_SetPriority(USART2_IRQn, 4, 0);
	HAL_NVIC_EnableIRQ(USART2_IRQn);
	
	__HAL_RCC_USART2_CLK_ENABLE();
	Bluetooth_huart.Instance = Bluetooth_USE_UART;
	Bluetooth_huart.Init.BaudRate = Bluetooth_Speed;
	Bluetooth_huart.Init.WordLength = UART_WORDLENGTH_8B;
	Bluetooth_huart.Init.StopBits = UART_STOPBITS_1;
	Bluetooth_huart.Init.Parity = UART_PARITY_NONE;
	Bluetooth_huart.Init.Mode = UART_MODE_TX_RX;
	Bluetooth_huart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	Bluetooth_huart.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&Bluetooth_huart) != HAL_OK) Error_Handler();
}

void Bluetooth_Printf(char *format, ...)
{
	static char String[255];		//定义字符数组
	while(__HAL_UART_GET_FLAG(&huart1, UART_FLAG_TC) == RESET);
	va_list arg;					//定义可变参数列表数据类型的变量arg
	va_start(arg, format);			//从format开始，接收参数列表到arg变量
	vsprintf(String, format, arg);	//使用vsprintf打印格式化字符串和参数列表到字符数组中
	va_end(arg);					//结束变量arg
	HAL_UART_Transmit_IT(&Bluetooth_huart, (uint8_t*)String, strlen(String));	//串口发送字符数组（字符串）
//	HAL_UART_Transmit(&Bluetooth_huart, (uint8_t*)String, strlen(String),10);	//串口发送字符数组（字符串）
}

// 中断服务函数
void USART2_IRQHandler(void)
{ HAL_UART_IRQHandler(&Bluetooth_huart); }
