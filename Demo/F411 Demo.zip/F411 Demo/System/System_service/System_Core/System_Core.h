#ifndef _SYS_CORE_H_
#define _SYS_CORE_H_

/* ======================================== */
#include "KL_I2C_Init.h"
#include "IWDG.h"
#include "LED.h"
#include "Key.h"
#include "OLED.h"
#include "CJ3.h"
#include "SHT.h"
#include "GY302.h"
#include "SCD41.h"
#include "SGP41.h"
#include "UI.h"

extern TIM_HandleTypeDef htim2;

void Sys_IT_Serve(void);
void Sys_IT_TIM_Init(void);
void SystemClock_Config(void);

#endif
