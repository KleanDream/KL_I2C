#include "main.h"
#include "System_Core.h"

TIM_HandleTypeDef htim2;

uint8_t Measurement_Counter = 0;
uint8_t Data_Out_Counter = 0;
uint8_t Touch_Counter = 0;

void Sys_IT_Serve(void)
{
	OLED1_Handle.Frame_Rate_Control_Parameters++;
	OLED2_Handle.Frame_Rate_Control_Parameters++;
	OLED3_Handle.Frame_Rate_Control_Parameters++;
	OLED4_Handle.Frame_Rate_Control_Parameters++;
//	Touch_Counter++;
	Measurement_Counter++;
	
	if(Measurement_Counter >= 10)
	{
		Measurement_Counter = 0;
		
		// 温湿度逻辑
		SHT45_Handle1.Measure_Rate_Control_Parameters++;
		if(SHT45_Handle1.Measure_Rate_Control_Parameters == 3)
			SHT_StartMeasure(&SHT45_Handle1);
		if(SHT45_Handle1.Measure_Rate_Control_Parameters == 4)
			SHT_Read_TempHumi(&SHT45_Handle1);
		if(SHT45_Handle1.Measure_Rate_Control_Parameters >= 5)
			SHT45_Handle1.Measure_Rate_Control_Parameters = 0;
		
		// VOC_NOx逻辑
		SGP41_Handle1.Measure_Rate_Control_Parameters++;
		if(SGP41_Handle1.Measure_Rate_Control_Parameters == 8)
			SGP41_StartMeasure(&SGP41_Handle1);
		if(SGP41_Handle1.Measure_Rate_Control_Parameters == 9)
			SGP41_ReadData(&SGP41_Handle1);
		if(SGP41_Handle1.Measure_Rate_Control_Parameters >= 10)
			SGP41_Handle1.Measure_Rate_Control_Parameters = 0;
		
		// 光照传感器逻辑
		L_Measure_Rate_Control_Parameters++;
		if(L_Measure_Rate_Control_Parameters == 4)
		{
//			GY302_Read_Data(&GY302_Handle0);
			GY302_Read_Data(&GY302_Handle1);
		}
		if(L_Measure_Rate_Control_Parameters >= 5)
			L_Measure_Rate_Control_Parameters = 0;
		
		// CO2传感器逻辑
		CO2_Measure_Rate_Control_Parameters++;
		if(CO2_Measure_Rate_Control_Parameters == 90)
			SCD41_Read_Data(&SCD41_Handle1);
		if(CO2_Measure_Rate_Control_Parameters >= 100)
			CO2_Measure_Rate_Control_Parameters = 50;
		
		// UART数据发送逻辑
		Data_Out_Counter++;
		if(Data_Out_Counter >= 105)
		{
			Data_Out_Counter = 5;
			// 蓝牙数据发送逻辑
			#pragma diag_suppress 870
			Bluetooth_Printf("温度：%.2f°C\t湿度：%.2f %%\r\n二氧化碳浓度：%d ppm\r\nPM1.0浓度：%d μg/m³ PM2.5浓度：%d μg/m³ PM10浓度：%d μg/m³\r\n有机挥发物指数：%d\r\n氮氧化物指数：%d\r\n光照1：%d lx\t光照2：%d lx\r\n\r\n",
			SHT45_Handle1.Temp_Fil,SHT45_Handle1.Humi_Fil,SCD41_Handle1.CO2_ppm_Fil,CJ3_Handle.PM1_0_Fil,CJ3_Handle.PM2_5_Fil,CJ3_Handle.PM10_Fil,SGP41_Handle1.VOC_Fil,SGP41_Handle1.nox_index,GY302_Handle0.Light_Data, GY302_Handle1.Light_Data);
			#pragma diag_default 870
			UART_COM1_OutData();
		}
	}
	
	// 按键消抖计数器
	if(Key_Delay_Num != 0)
		Key_Delay_Num--;
	
	// OLED帧刷新
	if(OLED1_Handle.Frame_Rate_Control_Parameters == 19)
		displayflag[0] = 1;
	else if(OLED1_Handle.Frame_Rate_Control_Parameters >= 20)
	{
		OLED_Frame_Refresh(&OLED1_Handle);
		OLED1_Handle.Frame_Rate_Control_Parameters = 0;
	}
	
	if(OLED2_Handle.Frame_Rate_Control_Parameters == 19)
		displayflag[1] = 1;
	else if(OLED2_Handle.Frame_Rate_Control_Parameters >= 20)
	{
		OLED_Frame_Refresh(&OLED2_Handle);
		OLED2_Handle.Frame_Rate_Control_Parameters = 0;
	}
	
	if(OLED3_Handle.Frame_Rate_Control_Parameters == 19)
		displayflag[2] = 1;
	else if(OLED3_Handle.Frame_Rate_Control_Parameters >= 20)
	{
		OLED_Frame_Refresh(&OLED3_Handle);
		OLED3_Handle.Frame_Rate_Control_Parameters = 0;
	}
	
	if(OLED4_Handle.Frame_Rate_Control_Parameters == 19)
		displayflag[3] = 1;
	else if(OLED4_Handle.Frame_Rate_Control_Parameters >= 20)
	{
		OLED_Frame_Refresh(&OLED4_Handle);
		OLED4_Handle.Frame_Rate_Control_Parameters = 0;
	}
}

void Sys_IT_TIM_Init(void)
{
	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};
	
	__HAL_RCC_TIM2_CLK_ENABLE();
	
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 200 - 1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 5000 - 1;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	
	HAL_NVIC_SetPriority(TIM2_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(TIM2_IRQn);
	
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	HAL_TIM_Base_Start_IT(&htim2);
}

void SystemClock_Config(void)
{
	/* 系统时钟配置 */
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/* 配置电压调节器的输出电压等级 */
	__HAL_RCC_PWR_CLK_ENABLE();
	//设置最高的核心电压。系统时钟频率较高时，需要较高的核心电压来保证稳定运行
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

	/* 初始化RCC振荡器 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLM = 12;
	RCC_OscInitStruct.PLL.PLLN = 96;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = 4;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/* 初始化 CPU,AHB和APB总线时钟 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
							  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
	{
		Error_Handler();
	}
}
