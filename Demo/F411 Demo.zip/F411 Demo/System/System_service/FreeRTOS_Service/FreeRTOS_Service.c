#include "main.h"
#include "math.h"
#include "System_Core.h"

uint8_t displayflag[4] = { 0 };
uint8_t Bri = 100;

/* ====================== FreeRTOS 堆内存 ====================== */
uint8_t ucHeap[configTOTAL_HEAP_SIZE];

/* ===================== FreeRTOS 钩子函数 ===================== */
// 栈溢出钩子
void vApplicationStackOverflowHook( TaskHandle_t xTask, char *pcTaskName )
{
	#pragma diag_suppress 870
	Bluetooth_Printf("任务：%s 栈溢出！\r\n", pcTaskName);
	#pragma diag_default 870
	while(1);
}

// 内存分配失败钩子
void vApplicationMallocFailedHook( void )
{
	#pragma diag_suppress 870
	Bluetooth_Printf("内存分配失败！\r\n");
	#pragma diag_default 870
	while(1);
}

/* ===================== FreeRTOS 任务函数 ===================== */
// 空闲任务
void vApplicationIdleHook( void )
{
	static uint8_t i = 0;
	static uint8_t delay = 0;
	static uint8_t Orientation = 0;
	static uint8_t r = 0;
	static uint16_t gamma_r = 0;
	
	gamma_r = ((uint16_t)r * r * 250) / 10000 + 5;

	if(i < gamma_r) LED_On();
	else LED_Off();
	i++;

	if(i == 150)
	{
		i = 0;
		delay++;
		if(delay >= 200)
		{
			delay = 0;
			if(Orientation == 0){ r++; if(r >= 100) Orientation = 1; }
			else{ r--; if(r <= 0) Orientation = 0; }
		}
		IWDG_Feed();
	}
}

void OLED_Display_Refresh(void *pvParameters)
{
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	while(1)
	{
		if(displayflag[0])
		{
			displayflag[0] = 0;
			UI_Display(&OLED1_Handle, 0);
		}

		if(displayflag[1])
		{
			displayflag[1] = 0;
			UI_Display(&OLED2_Handle, 1);
		}
		
		if(displayflag[2])
		{
			displayflag[2] = 0;
			UI_Display(&OLED3_Handle, 2);
		}
		
		if(displayflag[3])
		{
			displayflag[3] = 0;
			UI_Display(&OLED4_Handle, 3);
		}
		
		vTaskDelayUntil(&xLastWakeTime, 5);
	}
}

void OLED_Auto_Bri(void *pvParameters)
{
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	vTaskDelayUntil(&xLastWakeTime, 1000);
	while(1)
	{
		// 自动亮度
		if(GY302_Handle1.Light_Data <= 100 & GY302_Handle1.Light_Data >= 16)
		{
			if(Bri <= sqrt(GY302_Handle1.Light_Data * 100)) Bri++;
			else Bri--;
		}
		else if(GY302_Handle1.Light_Data > 100)
		{
			if(Bri <= 100) Bri++;
		}
		else if((GY302_Handle1.Light_Data < 30))
		{
			if(Bri >= 40) Bri--;
		}
		OLED_Set_Brightness(&OLED1_Handle, Bri);
		OLED_Set_Brightness(&OLED2_Handle, Bri);
		OLED_Set_Brightness(&OLED3_Handle, Bri);
		OLED_Set_Brightness(&OLED4_Handle, Bri);
		vTaskDelayUntil(&xLastWakeTime, 10);
	}
}

void FreeRTOS_Login(void)
{
	taskENTER_CRITICAL();
	/* ===================== 创建任务 ===================== */
//	xTaskCreate(
//		LVGL_UI_Service,		// 任务函数
//		"LVGL_UI_Service",		// 任务名
//		2048,					// 任务栈大小（uint32_t）
//		NULL,					// 任务参数
//		2,						// 任务优先级
//		NULL					// 任务句柄
//	);
	xTaskCreate(
		OLED_Display_Refresh,		// 任务函数
		"OLED_Display_Refresh",		// 任务名
		512,					// 任务栈大小（uint32_t）
		NULL,					// 任务参数
		3,						// 任务优先级
		NULL					// 任务句柄
	);
	xTaskCreate(
		OLED_Auto_Bri,		// 任务函数
		"OLED_Auto_Bri",		// 任务名
		512,					// 任务栈大小（uint32_t）
		NULL,					// 任务参数
		3,						// 任务优先级
		NULL					// 任务句柄
	);
	
	/* ==================================================== */
	taskEXIT_CRITICAL();
	vTaskStartScheduler();
}
