#ifndef _CRC_H_
#define _CRC_H_

#include "main.h"

unsigned char CRC_Verify_8(uint8_t *data, uint8_t len, uint8_t Check_Code);

#endif
