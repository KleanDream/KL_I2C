#include "CRC.h"

unsigned char CRC_Verify_8(uint8_t *data, uint8_t len, uint8_t Check_Code)
{
	uint8_t bit;        // bit mask
	uint8_t crc = 0xFF; // calculated checksum
	uint8_t byteCtr;    // byte counter

	// calculates 8-Bit checksum with given polynomial @GZCXDZ
	for(byteCtr = 0; byteCtr < len; byteCtr++) {
			crc ^= (data[byteCtr]);
			for(bit = 8; bit > 0; --bit) {
					if(crc & 0x80) {
							crc = (crc << 1) ^ Check_Code;
					}  else {
							crc = (crc << 1);
					}
			}
	}
  return crc;
}
