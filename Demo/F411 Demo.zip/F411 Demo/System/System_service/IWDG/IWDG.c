#include "IWDG.h"

static IWDG_HandleTypeDef hiwdg;
static uint8_t iwdg_is_init = 0;

#if defined(STM32F1)
#define LSI_FREQ_X100        400U    /* 40kHz = 400 * 100Hz */
#else
#define LSI_FREQ_X100        320U    /* 32kHz = 320 * 100Hz */
#endif

#define IWDG_MAX_RELOAD      0x0FFFU /* IWDG 重装载最大值 */

/* 分频系数表 */
static const uint32_t prescaler_table[] = {
    IWDG_PRESCALER_4,
    IWDG_PRESCALER_8,
    IWDG_PRESCALER_16,
    IWDG_PRESCALER_32,
    IWDG_PRESCALER_64,
    IWDG_PRESCALER_128,
    IWDG_PRESCALER_256
};

static const uint32_t prescaler_value[] = {4,8,16,32,64,128,256};
#define PRESCALER_NUM        (sizeof(prescaler_table)/sizeof(prescaler_table[0]))

/**
  * @brief  初始化独立看门狗，TimeOut：超时时间（单位 ms）
  * @retval 0：成功  1：失败
  */
uint8_t System_IWDG_Init(uint32_t TimeOut)
{
    uint32_t rlr;
    uint8_t i;

    /* 防止重复初始化 */
    if(iwdg_is_init == 1) return 0;
	
	TimeOut *= 10;

    /* 参数检查：防止 0 和溢出 */
    if(TimeOut == 0 || TimeOut > 1000000) return 1;

    /* 自动选择最合适的分频系数 */
    for(i = 0; i < PRESCALER_NUM; i++)
    {
        rlr = (TimeOut * LSI_FREQ_X100) / prescaler_value[i];

        if(rlr >= 1 && rlr <= IWDG_MAX_RELOAD)
        {
            hiwdg.Instance = IWDG;
            hiwdg.Init.Prescaler = prescaler_table[i];
            hiwdg.Init.Reload    = rlr;
            if(HAL_IWDG_Init(&hiwdg) != HAL_OK) return 1;
            iwdg_is_init = 1;
            return 0;
        }
    }

    /* 无法匹配合适的分频系数 */
    return 1;
}

/**
  * @brief  喂狗
  * @retval None
  */
void IWDG_Feed(void)
{
    if(iwdg_is_init)
    {
        HAL_IWDG_Refresh(&hiwdg);
    }
}
