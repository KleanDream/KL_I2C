#ifndef _IWDG_H_
#define _IWDG_H_

#include "main.h"

uint8_t System_IWDG_Init(uint32_t TimeOut_100us);
void IWDG_Feed(void);

#endif
