#ifndef _UI_H_
#define _UI_H_

#include "main.h"
#include "OLED.h"

#define Weicome_Page	0
#define TempHumi_Page	1
#define VOT_NOx_Page	2
#define CO2_Page		3
#define Light_Page		4
#define PM_Page		5

typedef union{
	struct {
		uint8_t	Page			: 3;	// 6个界面
		uint8_t	reserved		: 5;	// 6位暂未使用
	} bits;
	uint8_t byte;         // 整体访问，主要是清空时使用
}UI_State;

extern UI_State UI_State_register[4];
extern uint8_t Ctrl_Display;

void UI_Display(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID);

void OLED_Clear(OLED_HandleTypeDef* OLED_Handle);
void OLED_ShowChinese(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t CHN, uint8_t Cover_Enable);
void OLED_ShowChineseString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t* CHN, uint8_t num, uint8_t Cover_Enable);
void OLED_ShowChar(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char Char, uint8_t Cover_Enable);
void OLED_ShowString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char *String, uint8_t Cover_Enable);
void OLED_Printf(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t Cover_Enable, char *format, ...);
void OLED_ShowNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable);
void OLED_ShowSignedNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, int32_t Number, uint8_t Length, uint8_t Cover_Enable);
void OLED_ShowHexNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable);
void OLED_ShowBinNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable);

#endif
