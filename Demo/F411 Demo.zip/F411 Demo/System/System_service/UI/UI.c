#include "main.h"
#include "UI.h"
#include "Font.h"
#include "System_Core.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

UI_State UI_State_register[4] = { 0 };
UI_State UI_State_register_cache[4] = { 0 };
uint8_t Ctrl_Display = 3;

//中文语句
const uint8_t Margin[8] = { 0 };       			//行清空
const uint8_t Digital_Temperature_And_Humidity_Meter[7] = {5,6,7,1,3,2,8};		//数字型温湿度表
const uint8_t Air_Quality_Index[6] = {9,10,11,12,13,5};							//空气质量指数
const uint8_t Organic_Vapour[5] = {14,15,16,17,18};								//有机挥发物
const uint8_t Nitric_Oxide[4] = {19,20,21,18};									//氮氧化物
const uint8_t Carbon_Dioxide_ppm[6] = {22,20,21,23,24,2};						//二氧化碳浓度
const uint8_t Strength_Draught[4] = {25,26,27,2};								//通风强度
const uint8_t Indoor_Lighting[4] = {28,29,30,31};								//室内光照
const uint8_t Room[2] = {32,33};												//房间
const uint8_t Inhalable_Particle[6] = {36,37,38,39,40,18};						//可吸入颗粒物

void System_Welcome(OLED_HandleTypeDef* OLED_Handle)
{
//	OLED_Clear(OLED_Handle);
	OLED_Printf(OLED_Handle,0x10,0x00,1,"System is");
	OLED_Printf(OLED_Handle,0x20,0x18,1,"starting up.");
}

void Display_T_H(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID)
{
	SHT_HandleTypeDef* SHT_Handle = &SHT45_Handle1;
	if(UI_State_register[Display_ID].bits.Page != UI_State_register_cache[Display_ID].bits.Page)
	{
		OLED_Clear(OLED_Handle);
		uint8_t* Chinese_String;
		Chinese_String = (uint8_t*)Digital_Temperature_And_Humidity_Meter;
		OLED_ShowChineseString(OLED_Handle,0x00,0x08,Chinese_String,7,1);
		OLED_ShowChinese(OLED_Handle,0x16,0x08,1,1);
		OLED_ShowChinese(OLED_Handle,0x16,0x1C,2,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x08,3,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x1C,2,1);
		OLED_ShowString(OLED_Handle,0x16,0x2C,":",1);
		OLED_ShowString(OLED_Handle,0x2A,0x2C,":",1);
		UI_State_register_cache[Display_ID].bits.Page = UI_State_register[Display_ID].bits.Page;
	}
	uint8_t a = 11;
	uint8_t b = 11;
	/* 符号部分 */
	if(SHT_Handle->Temp_Fil < 0)a--;
	/* 数字部分 */
	if(SHT_Handle->Temp_Fil < 10 && SHT_Handle->Temp_Fil > -10)a++;
	if(SHT_Handle->Temp_Fil > 100)a--;
	if(SHT_Handle->Humi_Fil == 100)b--;
	if(SHT_Handle->Humi_Fil < 10 )b++;
	if(a == 10) OLED_Printf(OLED_Handle,0x16,0x34,1,"%.2f",SHT_Handle->Temp_Fil);
	else if(a == 11) OLED_Printf(OLED_Handle,0x16,0x34,1," %.2f",SHT_Handle->Temp_Fil);
	else if(a == 12) OLED_Printf(OLED_Handle,0x16,0x34,1,"  %.2f",SHT_Handle->Temp_Fil);
	OLED_ShowChinese(OLED_Handle,0x16,0x64,4,1);
	if(b == 10) OLED_Printf(OLED_Handle,0x2A,0x34,1,"%.2f",SHT_Handle->Humi_Fil);
	else if(b == 11) OLED_Printf(OLED_Handle,0x2A,0x34,1," %.2f",SHT_Handle->Humi_Fil);
	else if(b == 12) OLED_Printf(OLED_Handle,0x2A,0x34,1,"  %.2f",SHT_Handle->Humi_Fil);
	OLED_ShowChar(OLED_Handle,0x2A,0x6C,'%',1);
}

void Display_VOC_NOx(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID)
{
	SGP41_HandleTypeDef* SGP41_Handle = &SGP41_Handle1;
	if(UI_State_register[Display_ID].bits.Page != UI_State_register_cache[Display_ID].bits.Page)
	{
		OLED_Clear(OLED_Handle);
		uint8_t* Chinese_String;
		Chinese_String = (uint8_t*)Air_Quality_Index;
		OLED_ShowChineseString(OLED_Handle,0x00,0x10,Chinese_String,6,1);
		Chinese_String = (uint8_t*)Organic_Vapour;
		OLED_ShowChineseString(OLED_Handle,0x16,0x00,Chinese_String,5,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x00,19,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x15,20,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x2A,21,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x3F,18,1);
		OLED_ShowString(OLED_Handle,0x16,0x50,":",1);
		OLED_ShowString(OLED_Handle,0x2A,0x50,":",1);
		UI_State_register_cache[Display_ID].bits.Page = UI_State_register[Display_ID].bits.Page;
	}
	OLED_Printf(OLED_Handle,0x16,0x60,1,"   ");
	OLED_Printf(OLED_Handle,0x16,0x60,1,"%d", SGP41_Handle->VOC_Fil);
	OLED_Printf(OLED_Handle,0x2A,0x60,1,"   ");
	OLED_Printf(OLED_Handle,0x2A,0x60,1,"%d", SGP41_Handle->nox_index);
}

void Display_CO2(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID)
{
	SCD41_HandleTypeDef* SCD41_Handle = &SCD41_Handle1;
	if(UI_State_register[Display_ID].bits.Page != UI_State_register_cache[Display_ID].bits.Page)
	{
		OLED_Clear(OLED_Handle);
		uint8_t* Chinese_String;
		Chinese_String = (uint8_t*)Carbon_Dioxide_ppm;
		OLED_ShowChineseString(OLED_Handle,0x00,0x10,Chinese_String,6,1);
		Chinese_String = (uint8_t*)Strength_Draught;
		OLED_Printf(OLED_Handle,0x20,0x48,1,"ppm");
		UI_State_register_cache[Display_ID].bits.Page = UI_State_register[Display_ID].bits.Page;
	}
	/* 第0行左半：显示 CO₂ 浓度 */
	OLED_Printf(OLED_Handle,0x20,0x18,1,"      ");
	if(SCD41_Handle->CO2_ppm_Fil < 10) OLED_Printf(OLED_Handle,0x20,0x38,1,"%d", SCD41_Handle->CO2_ppm_Fil);
	else if(SCD41_Handle->CO2_ppm_Fil < 100) OLED_Printf(OLED_Handle,0x20,0x30,1,"%d", SCD41_Handle->CO2_ppm_Fil);
	else if(SCD41_Handle->CO2_ppm_Fil < 1000) OLED_Printf(OLED_Handle,0x20,0x28,1,"%d", SCD41_Handle->CO2_ppm_Fil);
	else if(SCD41_Handle->CO2_ppm_Fil < 10000) OLED_Printf(OLED_Handle,0x20,0x20,1,"%d", SCD41_Handle->CO2_ppm_Fil);
	else OLED_Printf(OLED_Handle,0x20,0x18,1,"%d", SCD41_Handle->CO2_ppm_Fil);
}

void Display_PM(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID)
{
	if(UI_State_register[Display_ID].bits.Page != UI_State_register_cache[Display_ID].bits.Page)
	{
		OLED_Clear(OLED_Handle);
		uint8_t* Chinese_String;
		Chinese_String = (uint8_t*)Inhalable_Particle;
		OLED_ShowChineseString(OLED_Handle,0x00,0x10,Chinese_String,6,1);
		OLED_Printf(OLED_Handle,0x10,0x00,1,"PM1.0:");
		OLED_ShowChinese(OLED_Handle,0x10,0x58,34,1);
		OLED_ShowChinese(OLED_Handle,0x10,0x70,35,1);
		OLED_ShowChar(OLED_Handle,0x10,0x68,'/',1);
		OLED_Printf(OLED_Handle,0x20,0x00,1,"PM2.5:");
		OLED_ShowChinese(OLED_Handle,0x20,0x58,34,1);
		OLED_ShowChinese(OLED_Handle,0x20,0x70,35,1);
		OLED_ShowChar(OLED_Handle,0x20,0x68,'/',1);
		OLED_Printf(OLED_Handle,0x30,0x00,1,"PM10 :");
		OLED_ShowChinese(OLED_Handle,0x30,0x58,34,1);
		OLED_ShowChinese(OLED_Handle,0x30,0x70,35,1);
		OLED_ShowChar(OLED_Handle,0x30,0x68,'/',1);
		
		UI_State_register_cache[Display_ID].bits.Page = UI_State_register[Display_ID].bits.Page;
	}
	OLED_Printf(OLED_Handle,0x10,0x30,1,"     ");
	if(CJ3_Handle.PM1_0_Fil < 10) OLED_Printf(OLED_Handle,0x10,0x4C,1,"%d", CJ3_Handle.PM1_0_Fil);
	else if(CJ3_Handle.PM1_0_Fil < 100) OLED_Printf(OLED_Handle,0x10,0x44,1,"%d", CJ3_Handle.PM1_0_Fil);
	else if(CJ3_Handle.PM1_0_Fil < 1000) OLED_Printf(OLED_Handle,0x10,0x3C,1,"%d", CJ3_Handle.PM1_0_Fil);
	else OLED_Printf(OLED_Handle,0x10,0x34,1,"%d", CJ3_Handle.PM1_0_Fil);
	
	OLED_Printf(OLED_Handle,0x20,0x30,1,"     ");
	if(CJ3_Handle.PM2_5_Fil < 10) OLED_Printf(OLED_Handle,0x20,0x4C,1,"%d", CJ3_Handle.PM2_5_Fil);
	else if(CJ3_Handle.PM2_5_Fil < 100) OLED_Printf(OLED_Handle,0x20,0x44,1,"%d", CJ3_Handle.PM2_5_Fil);
	else if(CJ3_Handle.PM2_5_Fil < 1000) OLED_Printf(OLED_Handle,0x20,0x3C,1,"%d", CJ3_Handle.PM2_5_Fil);
	else OLED_Printf(OLED_Handle,0x20,0x34,1,"%d", CJ3_Handle.PM2_5_Fil);
	
	OLED_Printf(OLED_Handle,0x30,0x30,1,"     ");
	if(CJ3_Handle.PM10_Fil < 10) OLED_Printf(OLED_Handle,0x30,0x4C,1,"%d", CJ3_Handle.PM10_Fil);
	else if(CJ3_Handle.PM10_Fil < 100) OLED_Printf(OLED_Handle,0x30,0x44,1,"%d", CJ3_Handle.PM10_Fil);
	else if(CJ3_Handle.PM10_Fil < 1000) OLED_Printf(OLED_Handle,0x30,0x3C,1,"%d", CJ3_Handle.PM10_Fil);
	else OLED_Printf(OLED_Handle,0x30,0x34,1,"%d", CJ3_Handle.PM10_Fil);
}

void Display_L(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID)
{
	
	GY302_HandleTypeDef* GY302_Handle_1 = &GY302_Handle0;
	GY302_HandleTypeDef* GY302_Handle_2 = &GY302_Handle1;
	if(UI_State_register[Display_ID].bits.Page != UI_State_register_cache[Display_ID].bits.Page)
	{
		OLED_Clear(OLED_Handle);
		uint8_t* Chinese_String;
		Chinese_String = (uint8_t*)Indoor_Lighting;
		OLED_ShowChineseString(OLED_Handle,0x00,0x10,Chinese_String,4,1);
		OLED_ShowString(OLED_Handle,0x00,0x50,"(lx)",1);
		OLED_ShowChinese(OLED_Handle,0x16,0x00,32,1);
		OLED_ShowChinese(OLED_Handle,0x16,0x14,33,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x00,32,1);
		OLED_ShowChinese(OLED_Handle,0x2A,0x14,33,1);
		OLED_ShowString(OLED_Handle,0x16,0x26,"1",1);
		OLED_ShowString(OLED_Handle,0x2A,0x26,"2",1);
		OLED_ShowString(OLED_Handle,0x16,0x30,":",1);
		OLED_ShowString(OLED_Handle,0x2A,0x30,":",1);
		UI_State_register_cache[Display_ID].bits.Page = UI_State_register[Display_ID].bits.Page;
	}
	OLED_Printf(OLED_Handle,0x16,0x3B,1,"      ");
	if(GY302_Handle_1->Light_Data == 121556) OLED_Printf(OLED_Handle,0x16,0x3B,1,"HIGH");//量程上限
	else OLED_Printf(OLED_Handle,0x16,0x3B,1,"%d",GY302_Handle_1->Light_Data);
	
	OLED_Printf(OLED_Handle,0x2A,0x3B,1,"      ");
	if(GY302_Handle_2->Light_Data == 121556) OLED_Printf(OLED_Handle,0x2A,0x3B,1,"HIGH");//量程上限
	else OLED_Printf(OLED_Handle,0x2A,0x3B,1,"%d",GY302_Handle_2->Light_Data);
}

void UI_Display(OLED_HandleTypeDef* OLED_Handle, uint8_t Display_ID)
{
	switch(UI_State_register[Display_ID].bits.Page)
	{
		case Weicome_Page:{
			System_Welcome(OLED_Handle);
			break;
		}
		case TempHumi_Page:{
			Display_T_H(OLED_Handle, Display_ID);
			break;
		}
		case VOT_NOx_Page:{
			Display_VOC_NOx(OLED_Handle, Display_ID);
			break;
		}
		case CO2_Page:{
			Display_CO2(OLED_Handle, Display_ID);
			break;
		}
		case PM_Page:{
			Display_PM(OLED_Handle, Display_ID);
			break;
		}
		case Light_Page:{
			Display_L(OLED_Handle, Display_ID);
			break;
		}
	}
}

/* ================OLED相关函数================ */
/**
  * @brief  OLED清屏
  * @param  无
  * @retval 无
  */
void OLED_Clear(OLED_HandleTypeDef* OLED_Handle)
{  
    for (uint8_t i = 0; i < OLED_PAGES; i++)
		memset(OLED_Handle->Video_Memory[i], 0x00, OLED_WIDTH);
}

/**
 *  @brief OLED显示汉字
 *  @param Line起始位置，范围1~4
 *  @param Column 起始列位置，1~8
 *  @param CHN 汉字序列
 */
void OLED_ShowChinese(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t CHN, uint8_t Cover_Enable)
{
	int8_t Start_page;
	int8_t shift;
	if(y >= 0)
	{
		Start_page = y / 8;
		shift = y % 8;
	}
	else 
	{
		Start_page = -((-y - 1) / 8 + 1);
		shift = -((-y) % 8);
	}
	uint8_t i;
	
		// 上半部分
	for (i = 0; i < 16; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if(Start_page >= 0 && Start_page <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page][x + i + 1] &= 0xFF >> (8 - shift);
					OLED_Handle->Video_Memory[Start_page][x + i + 1] |= Chinese_Font[CHN * 2][i] << shift;
				}
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= Chinese_Font[CHN * 2][i] >> (8 - shift);
				}
			}
			else 
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= (Chinese_Font[CHN * 2][i] >> (-shift)) | (Chinese_Font[CHN * 2 + 1][i] << (8 - (-shift)));
				}
			}
		}
	}
	// 下半部分
	for (i = 0; i < 16; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= Chinese_Font[CHN * 2 + 1][i] << shift;
				}
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << shift;
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= Chinese_Font[CHN * 2 + 1][i] >> (8 - shift);
				}
			}
			else
			{
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << (8 + shift);
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= Chinese_Font[CHN * 2 + 1][i] >> (-shift);
				}
			}
		}
	}
}

void OLED_ShowChineseString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t *CHN, uint8_t num, uint8_t Cover_Enable)
{
	uint8_t i;
    for (i = 0; i < num; i++)
    {
		OLED_ShowChinese(OLED_Handle,y, x + 16 * i, CHN[i], Cover_Enable);
    }
}

/**
  * @brief  OLED显示一个字符
  * @param  Line 行位置，范围：1~4
  * @param  Column 列位置，范围：1~16
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowChar(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char Char, uint8_t Cover_Enable)
{
	int8_t Start_page;
	int8_t shift;
	if(y >= 0)
	{
		Start_page = y / 8;
		shift = y % 8;
	}
	else 
	{
		Start_page = -((-y - 1) / 8 + 1);
		shift = -((-y) % 8);
	}
	uint8_t i;
	
		// 上半部分
	for (i = 0; i < 8; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if(Start_page >= 0 && Start_page <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page][x + i + 1] &= 0xFF >> (8 - shift);
					OLED_Handle->Video_Memory[Start_page][x + i + 1] |= OLED_F8x16[Char - ' '][i] << shift;
				}
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= OLED_F8x16[Char - ' '][i] >> (8 - shift);
				}
			}
			else 
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= (OLED_F8x16[Char - ' '][i] >> (-shift)) | (OLED_F8x16[Char - ' '][i + 8] << (8 - (-shift)));
				}
			}
		}
	}
	// 下半部分
	for (i = 0; i < 8; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= OLED_F8x16[Char - ' '][i + 8] << shift;
				}
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << shift;
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= OLED_F8x16[Char - ' '][i + 8] >> (8 - shift);
				}
			}
			else
			{
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << (8 + shift);
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= OLED_F8x16[Char - ' '][i + 8] >> (-shift);
				}
			}
		}
	}
}

/**
  * @brief  OLED显示字符串
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char *String, uint8_t Cover_Enable)
{
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++)
    {
        OLED_ShowChar(OLED_Handle, y, x + 8 * i, String[i], Cover_Enable);
    }
}

void OLED_Printf(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t Cover_Enable, char *format, ...) 
{
    char String[17];
    va_list arg;
    va_start(arg, format);
    vsnprintf(String, sizeof(String), format, arg);
    va_end(arg);
    OLED_ShowString(OLED_Handle, y, x, String, Cover_Enable);
}

/**
  * @brief  OLED次方函数
  * @retval 返回值等于X的Y次方
  */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
    uint32_t Result = 1;
    while (Y--)
    {
        Result *= X;
    }
    return Result;
}

/**
  * @brief  OLED显示数字（十进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~4294967295
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i;
    for (i = 0; i < Length; i++)                            
    {
        OLED_ShowChar(OLED_Handle, y, x + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0', Cover_Enable);
    }
}

/**
  * @brief  OLED显示数字（十进制，带符号数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：-2147483648~2147483647
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowSignedNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, int32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i;
    uint32_t Number1;
    if (Number >= 0)
    {
        OLED_ShowChar(OLED_Handle, y, x, '+', Cover_Enable);
        Number1 = Number;
    }
    else
    {
        OLED_ShowChar(OLED_Handle, y, x, '-', Cover_Enable);
        Number1 = -Number;
    }
    for (i = 0; i < Length; i++)                            
    {
        OLED_ShowChar(OLED_Handle, y, x + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0', Cover_Enable);
    }
}

/**
  * @brief  OLED显示数字（十六进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~0xFFFFFFFF
  * @param  Length 要显示数字的长度，范围：1~8
  * @retval 无
  */
void OLED_ShowHexNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i, SingleNumber;
    for (i = 0; i < Length; i++)                            
    {
        SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
        if (SingleNumber < 10)
        {
            OLED_ShowChar(OLED_Handle, y, x + i, SingleNumber + '0', Cover_Enable);
        }
        else
        {
            OLED_ShowChar(OLED_Handle, y, x + i, SingleNumber - 10 + 'A', Cover_Enable);
        }
    }
}

/**
  * @brief  OLED显示数字（二进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~1111 1111 1111 1111
  * @param  Length 要显示数字的长度，范围：1~16
  * @retval 无
  */
void OLED_ShowBinNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i;
    for (i = 0; i < Length; i++)                            
    {
        OLED_ShowChar(OLED_Handle, y, x + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0', Cover_Enable);
    }
}

