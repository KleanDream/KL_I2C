#include "main.h"
#include "System_Core.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include "CRC.h"

#define DATA_CRC	0x75

UART_HandleTypeDef UART_COM1_huart;

uint8_t UART_COM1_Transmit_Rate_Control_Parameters = 0;

void UART_COM1_Transmit_IT(void)
{
	
}

void UART_COM1_Receive_IT(void)
{
	
}

void UART_COM1_Pin_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOA_CLK_ENABLE();

	GPIO_InitStruct.Pin = UART_COM1_Tx_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = UART_COM1_GPIO_AF;
	HAL_GPIO_Init(UART_COM1_Tx_GPIO_Port, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = UART_COM1_Rx_Pin;
	HAL_GPIO_Init(UART_COM1_Rx_GPIO_Port, &GPIO_InitStruct);
}

void UART_COM1_Init(void)
{
	UART_COM1_Pin_Init();
	
	HAL_NVIC_SetPriority(USART1_IRQn, 4, 0);
	HAL_NVIC_EnableIRQ(USART1_IRQn);
	
	__HAL_RCC_USART1_CLK_ENABLE();
	UART_COM1_huart.Instance = UART_COM1_USE_UART;
	UART_COM1_huart.Init.BaudRate = UART_COM1_Speed;
	UART_COM1_huart.Init.WordLength = UART_WORDLENGTH_8B;
	UART_COM1_huart.Init.StopBits = UART_STOPBITS_1;
	UART_COM1_huart.Init.Parity = UART_PARITY_NONE;
	UART_COM1_huart.Init.Mode = UART_MODE_TX_RX;
	UART_COM1_huart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	UART_COM1_huart.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&UART_COM1_huart) != HAL_OK) Error_Handler();
}

void UART_COM1_OutData(void)
{
	static uint8_t Data_In_Sec[16] = { 0x00 };
		
/*
*	SHTXX系列温湿度传感器
*	温度 		int8_t 		8bit（计算值整数部分）
*	温度		uint8_t		8bit（计算值小数部分）
*	湿度 		uint8_t 	8bit（计算值整数部分）
*	湿度 		uint8_t		8bit（计算值小数部分）
**/
	Data_In_Sec[0] = (uint8_t)((int8_t)SHT45_Handle1.Temp_Fil);												// 温度整数部分
	Data_In_Sec[1] = (uint8_t)fabsf(roundf((SHT45_Handle1.Temp_Fil - (int8_t)SHT45_Handle1.Temp_Fil) * 100));	// 温度小数部分
	Data_In_Sec[2] = (uint8_t)SHT45_Handle1.Humi_Fil;														// 湿度整数部分
	Data_In_Sec[3] = (uint8_t)roundf((SHT45_Handle1.Humi_Fil - (int8_t)SHT45_Handle1.Humi_Fil) * 100);			// 湿度小数部分
/*
*	SCD41二氧化碳传感器
*	二氧化碳	uint16_t		14bit（原始数据）
**/
	Data_In_Sec[4] = (uint8_t)(SCD41_Handle1.CO2_ppm_Fil >> 8);		// 二氧化碳高八位
	Data_In_Sec[5] = (uint8_t)SCD41_Handle1.CO2_ppm_Fil;			// 二氧化碳低八位
/*
*	CJ3 粉尘传感器
*	PM1.0浓度	uint12_t		12bit（UART接收原始数据）
*	PM2.5浓度	uint12_t		12bit（UART接收原始数据）
*	PM10浓度	uint12_t		12bit（UART接收原始数据）
**/
	Data_In_Sec[6] = (uint8_t)(CJ3_Handle.PM1_0_Fil >> 4);				// PM1.0高八位
	Data_In_Sec[7] = (uint8_t)(CJ3_Handle.PM1_0_Fil & 0x000F) << 4;		// PM1.0低四位
	Data_In_Sec[7] |= (uint8_t)(CJ3_Handle.PM2_5_Fil >> 8) & 0x0F;		// PM2.5高四位
	Data_In_Sec[8] = (uint8_t)CJ3_Handle.PM2_5_Fil;						// PM2.5低八位
	Data_In_Sec[9] = (uint8_t)(CJ3_Handle.PM10_Fil >> 4);				// PM10高八位
	Data_In_Sec[10] = (uint8_t)(CJ3_Handle.PM10_Fil & 0x000F) << 4;		// PM10低四位
/*
*	SGP41空气污染物
*	有机挥发物	uint10_t		10bit（指数数据）
*	氮氧化物	uint10_t		10bit（指数数据）
**/
	Data_In_Sec[10] |= (uint8_t)(SGP41_Handle1.VOC_Fil >> 6) & 0x0F;		// 有机挥发高四位
	Data_In_Sec[11] = (uint8_t)((SGP41_Handle1.VOC_Fil << 2) & 0xFC);		// 有机挥发低六位
	Data_In_Sec[11] |= (uint8_t)((SGP41_Handle1.nox_index >> 8) & 0x03);	// 氮氧化物高二位
	Data_In_Sec[12] = (uint8_t)SGP41_Handle1.nox_index;						// 氮氧化物低八位
	
	Data_In_Sec[13] = 0x00;		// 融合算法预留1
	Data_In_Sec[14] = 0x00;		// 融合算法预留2
	
	Data_In_Sec[15] = CRC_Verify_8(Data_In_Sec, 15, DATA_CRC);	//CRC多项式0x75
	
	HAL_UART_Transmit_IT(&UART_COM1_huart, Data_In_Sec, sizeof(Data_In_Sec));
}

// 中断服务函数
void USART1_IRQHandler(void)
{ HAL_UART_IRQHandler(&UART_COM1_huart); }
