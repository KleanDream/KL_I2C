#ifndef __UART_COM1_H
#define __UART_COM1_H

#define UART_COM1_Tx_Pin				GPIO_PIN_9
#define UART_COM1_Tx_GPIO_Port			GPIOA
#define UART_COM1_Rx_Pin				GPIO_PIN_10
#define UART_COM1_Rx_GPIO_Port			GPIOA
#define UART_COM1_GPIO_AF				GPIO_AF7_USART1

#define UART_COM1_huart					huart1
#define UART_COM1_USE_UART				USART1

#define UART_COM1_Speed				115200

extern UART_HandleTypeDef UART_COM1_huart;
extern uint8_t UART_COM1_Transmit_Rate_Control_Parameters;

void UART_COM1_Transmit_IT(void);
void UART_COM1_Receive_IT(void);
void UART_COM1_Init(void);
void UART_COM1_OutData(void);
#endif
