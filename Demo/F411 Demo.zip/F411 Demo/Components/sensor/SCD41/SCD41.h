#ifndef _SCD41_H_
#define _SCD41_H_

#include "main.h"
#include "KL_I2C.h"

#define SCD41_ADDR_WRITE 	(uint8_t)(0x62<<1)
#define SCD41_ADDR_READ  	(uint8_t)((0x62<<1) | 1)
#define SCD41_Avg_Len		(2)
#define SCD41_DATA_LEN		(9)

typedef struct {
	KL_I2C_HandleTypeDef*	KL_I2C_Handle;		// 总线绑定
	uint8_t					Buff[SCD41_DATA_LEN];		// 数据缓冲区
	float					Temp_SCD41;			// 参考温度
	float					Humi_SCD41;			// 参考湿度
	uint16_t				Temp_SCD41_u16;		// 参考温度原始值
	uint16_t				Humi_SCD41_u16;		// 参考湿度原始值
	uint16_t				CO2_ppm_Ori;		// 测得数据(原始)
	uint16_t				CO2_ppm_Fil;		// 测得数据(滤波) - 当前输出
	
	// ---------- 滤波参数 ----------
	float					CO2_ppm_limit;		// 差值限幅
	float					CO2_ppm_power;		// 幂参数
	float					CO2_ppm_P;			// 卡尔曼滤波协方差
	float					CO2_ppm_QH;			// 滤波Q值上限
	float					CO2_ppm_QL;			// 滤波Q值下限
	float					CO2_ppm_R;			// 滤波R值
	float					CO2_ppm_integral;	// 积分补偿基值
	float					CO2_ppm_Gain;		// 积分补偿增益
	float					CO2_ppm_decay;		// 积分补偿基值衰减参数
	float					CO2_ppm_alpha;		// 低通滤波参数
	float					CO2_ppm_prev;		// 上一次卡尔曼滤波值（x_hat）
	float					CO2_ppm_lp_prev;	// 上一次低通输出（lp_prev）
	
	// ---------- 其他 ----------
	float					Avg_Queue[SCD41_Avg_Len];	// 均值计算队列
	uint8_t					Avg_Queue_P;		// 均值计算队列指针
	uint8_t					First_Read;			// 首次读取标志位
	uint8_t					ADDR_W;				// 写地址
	uint8_t					ADDR_R;				// 读地址
//	uint8_t					Measure_Rate_Control_Parameters;	// 采样速率控制参数(这边用同步方案)
} SCD41_HandleTypeDef;

/* =======SCD41句柄配置======== */
#define SCD41_I2C_Handle1 	KL_I2C2_Handle
extern SCD41_HandleTypeDef SCD41_Handle1;
/* ============================ */

extern uint8_t CO2_Measure_Rate_Control_Parameters;

void SCD41_Init(SCD41_HandleTypeDef* SCD41_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r);
void SCD41_Read_Data(SCD41_HandleTypeDef* SCD41_Handle);
#endif
