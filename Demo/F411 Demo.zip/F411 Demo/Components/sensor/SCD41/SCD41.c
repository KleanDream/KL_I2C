#include "SCD41.h"
#include "System_Core.h"
#include "filter_algorithm.h"
#include "CRC.h"

#define SCD41_CRC 0x31 // X^8 + X^5 + X^4 + 1

SCD41_HandleTypeDef SCD41_Handle1 = {
	.Buff = { 0x00 },
	.First_Read = 0,
	// 实时值初始化
	.Temp_SCD41 = 0,
	.Humi_SCD41 = 0,
	.Temp_SCD41_u16 = 0,
	.Humi_SCD41_u16 = 0,
	.CO2_ppm_Ori = 0,
	// 均值滤波部分
	.Avg_Queue = { 0x00 },
	.Avg_Queue_P = 0,
	// 卡尔曼滤波部分
	.CO2_ppm_limit = 35,
	.CO2_ppm_power = 3.655,
	.CO2_ppm_P = 1.0,
	.CO2_ppm_QH = 0.005,
	.CO2_ppm_QL = 0.001,
	.CO2_ppm_R = 0.01,
	.CO2_ppm_Fil = 0,
	.CO2_ppm_lp_prev = 0,
	.CO2_ppm_prev = 0,
	// 输出部分（积分补偿）
	.CO2_ppm_integral = 0,
	.CO2_ppm_Gain = 0.002,
	.CO2_ppm_decay = 1.02,
	.CO2_ppm_alpha = 0.2,
};

uint8_t CO2_Measure_Rate_Control_Parameters = 0;

void SCD41_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess);

void SCD41_Init(SCD41_HandleTypeDef* SCD41_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r)
{
	SCD41_Handle->KL_I2C_Handle = I2C_Bus;
	SCD41_Handle->ADDR_W = Addr_w;
	SCD41_Handle->ADDR_R = Addr_r;
	
	static uint8_t SCD41_Init_Set[2] = { 0x21, 0xB1 };
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x00;
	KL_I2C_RegisterTask(SCD41_Handle->KL_I2C_Handle, MSG, SCD41_Handle->ADDR_W, SCD41_Init_Set, sizeof(SCD41_Init_Set), SCD41_I2C_Callback, SCD41_Handle);
}

void SCD41_Data_Setout(SCD41_HandleTypeDef* SCD41_Handle)
{
	static uint8_t SCD41_Read_Wait[2] = { 0xE4, 0xB8 };
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x01;
	KL_I2C_RegisterTask(SCD41_Handle->KL_I2C_Handle, MSG, SCD41_Handle->ADDR_W, SCD41_Read_Wait, sizeof(SCD41_Read_Wait), SCD41_I2C_Callback, SCD41_Handle);
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x02;
	KL_I2C_RegisterTask(SCD41_Handle->KL_I2C_Handle, MSG, SCD41_Handle->ADDR_R, SCD41_Handle->Buff, 3, SCD41_I2C_Callback, SCD41_Handle);
}

void SCD41_Read_Data_I2C(SCD41_HandleTypeDef* SCD41_Handle)
{
	static uint8_t SCD41_Read_Data[2] = { 0xEC, 0x05 };
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x03;
	KL_I2C_RegisterTask(SCD41_Handle->KL_I2C_Handle, MSG, SCD41_Handle->ADDR_W, SCD41_Read_Data, sizeof(SCD41_Read_Data), SCD41_I2C_Callback, SCD41_Handle);
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x04 + SCD41_Handle->First_Read;
	KL_I2C_RegisterTask(SCD41_Handle->KL_I2C_Handle, MSG, SCD41_Handle->ADDR_R, SCD41_Handle->Buff, sizeof(SCD41_Handle->Buff), SCD41_I2C_Callback, SCD41_Handle);
}

/* 温湿度读取 */
void SCD41_Data_T_To_Float(SCD41_HandleTypeDef* SCD41_Handle)
{
	SCD41_Handle->Temp_SCD41 = -45.0f + (175.0f * (float)SCD41_Handle->Temp_SCD41_u16 / 65536.00f);
}
	
void SCD41_Data_H_To_Float(SCD41_HandleTypeDef* SCD41_Handle)
{
	SCD41_Handle->Humi_SCD41 = 100.0f * (float)SCD41_Handle->Humi_SCD41_u16 / 65536.00f;
}

void SCD41_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess)
{
	SCD41_HandleTypeDef* SCD41_Handle = (SCD41_HandleTypeDef*)Handle;
	switch(MSG.bits.Callback_Num)
	{
		case 0x00:{
			//无需操作
			break;
		}
		case 0x01:{
			//无需操作
			break;
		}
		case 0x02:{
			uint16_t data = (SCD41_Handle->Buff[0] << 8) | SCD41_Handle->Buff[1];
			if ((data & 0x07FF) != 0)
				SCD41_Read_Data_I2C(SCD41_Handle);
			break;
		}
		case 0x03:{
			//无需操作
			break;
		}
		case 0x04:{
			if(CRC_Verify_8(&SCD41_Handle->Buff[0],2,SCD41_CRC) != SCD41_Handle->Buff[2]) break;
				SCD41_Handle->CO2_ppm_Ori = (SCD41_Handle->Buff[0] << 8) + SCD41_Handle->Buff[1];
			SCD41_Handle->CO2_ppm_prev = (float)SCD41_Handle->CO2_ppm_Ori;
			SCD41_Handle->CO2_ppm_lp_prev = (float)SCD41_Handle->CO2_ppm_Ori;
			SCD41_Handle->CO2_ppm_Fil = SCD41_Handle->CO2_ppm_Ori;
			SCD41_Handle->Avg_Queue[SCD41_Handle->Avg_Queue_P] = (float)SCD41_Handle->CO2_ppm_Ori;
			SCD41_Handle->First_Read = 1;
			
			if(CRC_Verify_8(&SCD41_Handle->Buff[3],2,SCD41_CRC) != SCD41_Handle->Buff[5]) break;
				SCD41_Handle->Temp_SCD41_u16 = (SCD41_Handle->Buff[3] << 8) + SCD41_Handle->Buff[4];
			SCD41_Data_T_To_Float(SCD41_Handle);
			if(CRC_Verify_8(&SCD41_Handle->Buff[6],2,SCD41_CRC) != SCD41_Handle->Buff[8]) break;
				SCD41_Handle->Humi_SCD41_u16 = (SCD41_Handle->Buff[6] << 8) + SCD41_Handle->Buff[7];
			SCD41_Data_H_To_Float(SCD41_Handle);
			
			break;
		}
		case 0x05:{
			
			if(CRC_Verify_8(&SCD41_Handle->Buff[0],2,SCD41_CRC) != SCD41_Handle->Buff[2]) break;
				SCD41_Handle->CO2_ppm_Ori = (SCD41_Handle->Buff[0] << 8) + SCD41_Handle->Buff[1];
			if(SCD41_Handle->Avg_Queue_P < (SCD41_Avg_Len - 1))
				SCD41_Handle->Avg_Queue_P++;
			else
			{
				float CO2_ppm_Avg;
				CO2_ppm_Avg = Avg_Filter_float(SCD41_Handle->Avg_Queue, SCD41_Avg_Len);
				SCD41_Handle->CO2_ppm_Fil = (uint16_t)(Kalman_Filter_Step(&CO2_ppm_Avg,
																			&(SCD41_Handle->CO2_ppm_prev),
																			&(SCD41_Handle->CO2_ppm_P), 
																			SCD41_Handle->CO2_ppm_limit,
																			SCD41_Handle->CO2_ppm_power,
																			SCD41_Handle->CO2_ppm_QL,
																			SCD41_Handle->CO2_ppm_QH,
																			SCD41_Handle->CO2_ppm_R,
																			&(SCD41_Handle->CO2_ppm_integral),
																			&(SCD41_Handle->CO2_ppm_lp_prev),
																			SCD41_Handle->CO2_ppm_Gain,
																			SCD41_Handle->CO2_ppm_decay,
																			SCD41_Handle->CO2_ppm_alpha
																			) +0.5f);
				SCD41_Handle->Avg_Queue_P = 0;
			}
			SCD41_Handle->Avg_Queue[SCD41_Handle->Avg_Queue_P] = SCD41_Handle->CO2_ppm_Ori;
			
			// 剩下数据只简单转换，无输出需求，故不滤波
			if(CRC_Verify_8(&SCD41_Handle->Buff[3],2,SCD41_CRC) != SCD41_Handle->Buff[5]) break;
				SCD41_Handle->Temp_SCD41_u16 = (SCD41_Handle->Buff[3] << 8) + SCD41_Handle->Buff[4];
			SCD41_Data_T_To_Float(SCD41_Handle);
			if(CRC_Verify_8(&SCD41_Handle->Buff[6],2,SCD41_CRC) != SCD41_Handle->Buff[8]) break;
				SCD41_Handle->Humi_SCD41_u16 = (SCD41_Handle->Buff[6] << 8) + SCD41_Handle->Buff[7];
			SCD41_Data_H_To_Float(SCD41_Handle);
			break;
		}
		default: break;
	}
}

void SCD41_Read_Data(SCD41_HandleTypeDef* SCD41_Handle)
{
	SCD41_Data_Setout(SCD41_Handle);
}
