#include "GY302.h"

/* ========GY302句柄配置======== */
GY302_HandleTypeDef GY302_Handle0 = { 0x00 };
GY302_HandleTypeDef GY302_Handle1 = { 0x00 };
/* ============================= */

uint8_t L_Measure_Rate_Control_Parameters = 0;

void GY302_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess);

void GY302_Set_MTreg(GY302_HandleTypeDef* GY302_Handle, uint8_t sensitivity)
{
	if(!((sensitivity >= 31) && (sensitivity <= 254))) return;
	GY302_Handle->GY302_State_Register.MTreg = sensitivity;
	//修改 MTreg 的值，必须分两次写入两个不同的“指令”
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x02;
	GY302_Handle->Buff[2] = (0x40 | (GY302_Handle->GY302_State_Register.MTreg >> 5));
	KL_I2C_RegisterTask(GY302_Handle->KL_I2C_Handle, MSG, GY302_Handle->ADDR_W, &GY302_Handle->Buff[2], 1, GY302_I2C_Callback, GY302_Handle);
	GY302_Handle->Buff[3] = (0x60 | (GY302_Handle->GY302_State_Register.MTreg & 0x1F));
	KL_I2C_RegisterTask(GY302_Handle->KL_I2C_Handle , MSG, GY302_Handle->ADDR_W, &GY302_Handle->Buff[3], 1, GY302_I2C_Callback, GY302_Handle);
}

void GY302_Set_Mode(GY302_HandleTypeDef* GY302_Handle, uint8_t Mode)
{
	if(!((Mode == BHModeH1) || (Mode == BHModeH2) || (Mode == BHModeL))) return;
	GY302_Handle->GY302_State_Register.Mode = Mode;
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x03;
	KL_I2C_RegisterTask(GY302_Handle->KL_I2C_Handle, MSG, GY302_Handle->ADDR_W, &GY302_Handle->GY302_State_Register.Mode, 1, GY302_I2C_Callback, GY302_Handle);
}
	
void GY302_Auto_MTreg(GY302_HandleTypeDef* GY302_Handle, uint32_t light)
{
	if(light <= 3000 && GY302_Handle->GY302_State_Register.MTreg != 254) GY302_Set_MTreg(GY302_Handle, 254);
	else if((light > 3000 && light <= 6500) && GY302_Handle->GY302_State_Register.MTreg != 200) GY302_Set_MTreg(GY302_Handle, 200);
	else if((light > 6500 && light <= 9500) && GY302_Handle->GY302_State_Register.MTreg != 150) GY302_Set_MTreg(GY302_Handle, 150);
	else if((light > 9500 && light <= 12500) && GY302_Handle->GY302_State_Register.MTreg != 100) GY302_Set_MTreg(GY302_Handle, 100);
	else if((light > 12500 && light <= 20000) && GY302_Handle->GY302_State_Register.MTreg != 50) GY302_Set_MTreg(GY302_Handle, 50);
	else if((light > 20000 && light <= 90000) && GY302_Handle->GY302_State_Register.MTreg != 32) GY302_Set_MTreg(GY302_Handle, 32);
	else if(light > 90000 && GY302_Handle->GY302_State_Register.MTreg != 31) GY302_Set_MTreg(GY302_Handle, 31);
}

void GY302_Auto_Mode(GY302_HandleTypeDef* GY302_Handle, uint32_t light)
{
	if(GY302_Handle->GY302_State_Register.Mode == BHModeL) return;
	if(light <= 30000 && GY302_Handle->GY302_State_Register.Mode != BHModeH2) GY302_Set_Mode(GY302_Handle, BHModeH2);
	else if(light > 30000 && GY302_Handle->GY302_State_Register.Mode != BHModeH1) GY302_Set_Mode(GY302_Handle, BHModeH1);
}

void GY302_I2C_Callback(KL_I2C_Task_MSG MSG,void* Handle, uint8_t isSuccess)
{
	GY302_HandleTypeDef* GY302_Handle = (GY302_HandleTypeDef*)Handle;
	switch(MSG.bits.Callback_Num)
	{
		case 0x00:{
			//无需操作
			break;
		}
		case 0x01:{
			float light_f;
			uint16_t light = (GY302_Handle->Buff[0] << 8) + GY302_Handle->Buff[1];
			if(GY302_Handle->GY302_State_Register.Mode == BHModeH2) 
				light_f = (((float)light / 1.2f) * (69.0f / (float)GY302_Handle->GY302_State_Register.MTreg) / 2.0f);
			else if(GY302_Handle->GY302_State_Register.Mode == BHModeH1 || GY302_Handle->GY302_State_Register.Mode == BHModeL) 
				light_f = (((float)light / 1.2f) * (69.0f / (float)GY302_Handle->GY302_State_Register.MTreg));
			GY302_Handle->Light_Data = (uint32_t)light_f;
			
			//灵敏度自动切换
			GY302_Auto_MTreg(GY302_Handle, GY302_Handle->Light_Data);
			//模式自动切换
			GY302_Auto_Mode(GY302_Handle, GY302_Handle->Light_Data);
			break;
		}
		case 0x02:{
			//无需操作
			break;
		}
		case 0x03:{
			//无需操作
			break;
		}
		default: break;
	}
}

void GY302_Mode_Fast(GY302_HandleTypeDef* GY302_Handle)
{
	GY302_Set_Mode(GY302_Handle, BHModeL);
}

void GY302_Mode_HighPrecision(GY302_HandleTypeDef* GY302_Handle)
{
	GY302_Set_Mode(GY302_Handle, BHModeH1);
}

void GY302_Init(GY302_HandleTypeDef* GY302_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r, uint8_t Mode)
{
	GY302_Handle->KL_I2C_Handle = I2C_Bus;
	GY302_Handle->ADDR_W = Addr_w;
	GY302_Handle->ADDR_R = Addr_r;
	
	static uint8_t GY302_Init_Instruction[2] = { BHPowON, BHReset };
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x00;
	KL_I2C_RegisterTask(GY302_Handle->KL_I2C_Handle , MSG, GY302_Handle->ADDR_W, GY302_Init_Instruction, 1, GY302_I2C_Callback, GY302_Handle);
	KL_I2C_RegisterTask(GY302_Handle->KL_I2C_Handle , MSG, GY302_Handle->ADDR_W, GY302_Init_Instruction + 1, 1, GY302_I2C_Callback, GY302_Handle);
	//Mode=1 高精度模式		Mode=0或其他值 快速模式
	if(Mode == GY302_High_Precision_Mode) GY302_Mode_HighPrecision(GY302_Handle);
	else if(Mode == GY302_Fast_Mode) GY302_Mode_Fast(GY302_Handle);
	GY302_Set_MTreg(GY302_Handle, 31);
}

uint8_t GY302_Read_Data(GY302_HandleTypeDef* GY302_Handle)
{
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x01;
	return KL_I2C_RegisterTask(GY302_Handle->KL_I2C_Handle , MSG, GY302_Handle->ADDR_R, GY302_Handle->Buff, 2, GY302_I2C_Callback, GY302_Handle);
}
