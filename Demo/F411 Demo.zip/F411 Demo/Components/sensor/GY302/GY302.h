#ifndef _GY302_H_
#define _GY302_H_

#include "main.h"
#include "KL_I2C.h"

#define GY302_R_ADDR_0	(uint8_t)((0x23 << 1) | 1)
#define GY302_R_ADDR_1	(uint8_t)((0x5C << 1) | 1)
#define GY302_W_ADDR_0	(uint8_t)(0x23 << 1)
#define GY302_W_ADDR_1	(uint8_t)(0x5C << 1)
#define BHPowOFF		0x00
#define BHPowON			0x01
#define BHReset			0x07
#define BHModeH1		0x10
#define BHModeH2		0x11
#define BHModeL			0x13
#define BHSigModeH1		0x20
#define BHSigModeH2		0x21
#define BHSigModeL		0x23

#define GY302_DATA_LEN		(4)

typedef struct {
	uint8_t Mode;
	uint8_t MTreg;
} GY302_State;

typedef struct {
	KL_I2C_HandleTypeDef*	KL_I2C_Handle;				// 总线绑定
	uint8_t					Buff[GY302_DATA_LEN];		// 数据缓冲区
	uint32_t 				Light_Data;					// 测得数据
	GY302_State				GY302_State_Register;		// 状态机
	uint8_t					ADDR_W;						// 写地址
	uint8_t					ADDR_R;						// 读地址
//	uint8_t					Measure_Rate_Control_Parameters;	// 采样速率控制参数(这边用同步方案)
} GY302_HandleTypeDef;

extern uint8_t L_Measure_Rate_Control_Parameters;

/* =======GY302句柄配置======== */
#define GY302_I2C_Handle0 	KL_I2C2_Handle
extern GY302_HandleTypeDef GY302_Handle0;
#define GY302_I2C_Handle1 	KL_I2C2_Handle
extern GY302_HandleTypeDef GY302_Handle1;
/* ============================ */
#define GY302_Fast_Mode				0
#define GY302_High_Precision_Mode	1

void GY302_Mode_Fast(GY302_HandleTypeDef* GY302_Handle);
void GY302_Mode_HighPrecision(GY302_HandleTypeDef* GY302_Handle);
void GY302_Init(GY302_HandleTypeDef* GY302_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r, uint8_t Mode);
uint8_t GY302_Read_Data(GY302_HandleTypeDef* GY302_Handle);
#endif
