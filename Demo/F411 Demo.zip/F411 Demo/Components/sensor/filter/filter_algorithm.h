#ifndef __FILTER_ALGORITHM_H
#define __FILTER_ALGORITHM_H

#include "main.h"

float Avg_Filter_float(float* Data, uint32_t len);
double Avg_Filter_double(double* Data, uint32_t len);

float Kalman_Filter_Step(float* rawData, float* rawData_, float* P,
						float limit, float power, float Q1,
						float Q2, float R, float* integral,
						float* lp_prev, float Gain, float decay, float alpha);

#endif
