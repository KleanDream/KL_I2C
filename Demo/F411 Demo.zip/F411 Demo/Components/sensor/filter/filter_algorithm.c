#include "filter_algorithm.h"
#include "math.h"

float Avg_Filter_float(float* Data, uint32_t len)
{
	if (len == 0) return 0;
	float avg = Data[0];
	for(uint32_t i = 1; i < len; i++)
		avg += (Data[i] - avg) / i;
	return avg;
}

double Avg_Filter_double(double* Data, uint32_t len)
{
	if (len == 0) return 0;
	double avg = Data[0];
	for(uint32_t i = 1; i < len; i++)
		avg += (Data[i] - avg) / i;
	return avg;
}

/*
*	自适应卡尔曼滤波函数（带低通前置 + 积分补偿）
*	rawData		本次原始数据（输入），滤波后输出值（输出）
*	rawData_	上一时刻卡尔曼滤波值（输入/输出）
*	P			协方差值（输入/输出）
*	limit		差值限幅
*	power		幂参数
*	Q1			过程噪声下限
*	Q2			过程噪声上限
*	R			测量噪声
*	integral	积分补偿值（输入/输出）
*	lp_prev		上一时刻低通滤波输出（输入/输出）
*	Gain		积分补偿增益
*	decay		积分衰减系数
*	alpha		低通滤波系数
*/
float Kalman_Filter_Step(float* rawData, float* rawData_, float* P,
						float limit, float power, float Q1,
						float Q2, float R, float* integral,
						float* lp_prev, float Gain, float decay, float alpha)
{
	/* ========== 第一步：一阶低通滤波（使用独立的上一步低通状态） ========== */
	float lp_out = alpha * (*rawData) + (1.0f - alpha) * (*lp_prev);

	/* ========== 第二步：自适应卡尔曼滤波 ========== */
	float diff = fminf(limit, fabsf(lp_out - (*rawData_)));
	float Q = Q1 + fabsf(Q2 - Q1) * powf(fabsf(diff / limit), power);

	float x_predict = *rawData_;
	float P_predict = *P + Q;
	float K = P_predict / (P_predict + R);
	float kf_out = x_predict + K * (lp_out - x_predict);
	*P = (1.0f - K) * P_predict;

	/* ========== 第三步：积分补偿 ========== */
	float err = kf_out - lp_out;
	*integral = *integral + err;
	float output = kf_out - Gain * (*integral);
	*integral = *integral / decay;

	/* ========== 更新状态，供下一帧使用 ========== */
	*rawData_ = kf_out;   // 更新卡尔曼状态（下一帧的 rawData_）
	*lp_prev  = lp_out;   // 更新低通状态（下一帧的 lp_prev）
	return output;   // 最终滤波输出
}


//uint8_t Avg_Filter_u8(uint8_t* Data, uint32_t len)
//{
//	if (len == 0) return 0;
//	uint64_t avg = 0;
//	for (uint32_t i = 0; i < len; i++)
//		avg += Data[i];
//	avg /= len;
//	return avg;
//}

//int8_t Avg_Filter_8(int8_t* Data, uint32_t len)
//{
//	if (len == 0) return 0;
//	int64_t avg = 0;
//	for (uint32_t i = 0; i < len; i++)
//		avg += Data[i];
//	avg /= len;
//	return avg;
//}

//uint16_t Avg_Filter_u16(uint16_t* Data, uint32_t len)
//{
//	if (len == 0) return 0;
//	uint64_t avg = 0;
//	for (uint32_t i = 0; i < len; i++)
//		avg += Data[i];
//	avg /= len;
//	return avg;
//}

//int16_t Avg_Filter_16(int16_t* Data, uint32_t len)
//{
//	if (len == 0) return 0;
//	int64_t avg = 0;
//	for (uint32_t i = 0; i < len; i++)
//		avg += Data[i];
//	avg /= len;
//	return avg;
//}

//uint32_t Avg_Filter_u32(uint32_t* Data, uint32_t len)
//{
//	if (len == 0) return 0;
//	uint64_t avg = 0;
//	for (uint32_t i = 0; i < len; i++)
//		avg += Data[i];
//	avg /= len;
//	return avg;
//}

//int32_t Avg_Filter_32(int32_t* Data, uint32_t len)
//{
//	if (len == 0) return 0;
//	int64_t avg = 0;
//	for (uint32_t i = 0; i < len; i++)
//		avg += Data[i];
//	avg /= len;
//	return avg;
//}
///*
//*	卡尔曼滤波函数
//*	rawData		本次的数据
//*	rawData_	上一次的滤波值
//*	P			协方差值
//*	Q			过程噪声（调参：Q越大，越信任原始数据）
//*	R			测量噪声（调参：R越大，越信任滤波模型）
//**/
//void Kalman_Filter(float* rawData, float* rawData_, float* P, float Q, float R)
//{
//    float x_predict, P_predict, K;

//    // 预测步：预测当前状态（常值模型，预测值=上一次滤波值）
//    x_predict = *rawData_;
//    P_predict = *P + Q;	// 协方差预测

//    // 计算卡尔曼增益
//    K = P_predict / (P_predict + R);

//    // 更新步：融合预测值 + 本次原始数据，得到最终滤波值
//    *rawData = x_predict + K * (*rawData - x_predict);

//    // 更新协方差（供下次滤波使用）
//    *P = (1.0f - K) * P_predict;
//}
