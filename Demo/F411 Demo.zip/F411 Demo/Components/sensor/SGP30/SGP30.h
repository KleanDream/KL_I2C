#ifndef SGP30_H
#define SGP30_H

#include "main.h"
#include "KL_I2C.h"

#define SGP41_ADDR_WRITE			(uint8_t)(0x58<<1)
#define SGP41_ADDR_READ				(uint8_t)((0x58<<1) | 1)
#define SGP41_DATA_LEN				(6)
#define SGP41_Base_LEN				(8)
#define SGP41_Avg_Len				(10)

// 命令宏定义
#define SGP30_Init_CMD        			0x2003		// 初始化
#define SGP30_CMD_MEASURE				0x2008		// 读取数据
#define SGP30_Get_Baseline				0x2015		// 获取基线
#define SGP30_Set_Baseline				0x201E		// 写入基线

typedef struct {
	KL_I2C_HandleTypeDef*	KL_I2C_Handle;		// 总线绑定
	uint8_t					Buff[SGP30_DATA_LEN];		// 数据缓冲区
	uint8_t					CMD[SGP30_CMD_LEN];			// 命令缓冲区
	int32_t 				TVOC_index;			// 测得数据
	int32_t 				TVOC_index;			// 测得数据
	
	// ---------- 滤波参数 ----------
	float					TVOC_limit;			// 差值限幅
	float					TVOC_power;			// 幂参数
	float					TVOC_P;				// 卡尔曼滤波协方差
	float					TVOC_QH;			// 滤波Q值上限
	float					TVOC_QL;			// 滤波Q值下限
	float					TVOC_R;				// 滤波R值
	float					TVOC_integral;		// 积分补偿基值
	float					TVOC_Gain;			// 积分补偿增益
	float					TVOC_decay;			// 积分补偿基值衰减参数
	float					TVOC_alpha;			// 低通滤波参数
	float					TVOC_prev;			// 上一次卡尔曼滤波值（x_hat）
	float					TVOC_lp_prev;		// 上一次低通输出（lp_prev）
	
	float					eCO2_limit;			// 差值限幅
	float					eCO2_power;			// 幂参数
	float					eCO2_P;				// 卡尔曼滤波协方差
	float					eCO2_QH;			// 滤波Q值上限
	float					eCO2_QL;			// 滤波Q值下限
	float					eCO2_R;				// 滤波R值
	float					eCO2_integral;		// 积分补偿基值
	float					eCO2_Gain;			// 积分补偿增益
	float					eCO2_decay;			// 积分补偿基值衰减参数
	float					eCO2_alpha;			// 低通滤波参数
	float					eCO2_prev;			// 上一次卡尔曼滤波值（x_hat）
	float					eCO2_lp_prev;		// 上一次低通输出（lp_prev）
	
	// ---------- 其他 ----------
	float					Avg_Queue[SGP41_Avg_Len];	// 均值计算队列
	uint8_t					Avg_Queue_P;		// 均值计算队列指针
	uint8_t					First_Read;			// 首次读取标志位
	
	uint16_t				VOC_Fil;			// 测得数据(滤波) - 当前输出
	uint8_t					ADDR_W;				// 写地址
	uint8_t					ADDR_R;				// 读地址
	uint8_t					Init_ed;			// 初始化完成标志位
	uint8_t					Measure_Rate_Control_Parameters;	// 采样速率控制参数
} SGP30_HandleTypeDef;

/* =======SGP41句柄配置======== */
#define SGP30_I2C_Handle1 	KL_I2C2_Handle
extern SGP30_HandleTypeDef	SGP30_Handle1;
/* ============================ */

// 函数声明
void SGP30_Init(SGP30_HandleTypeDef* SGP30_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r);		// 初始化
uint8_t SGP41_StartMeasure(SGP41_HandleTypeDef* SGP41_Handle);		// 启动测量
uint8_t SGP41_ReadData(SGP41_HandleTypeDef* SGP41_Handle);			// 读取并计算指数
#endif
