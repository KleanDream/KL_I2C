#include "SGP30.h"
#include "filter_algorithm.h"
#include "System_Core.h"
#include "CRC.h"

// CRC 相关定义
#define SGP30_CRC8_POLYNOMIAL	0x31

SGP30_HandleTypeDef SGP30_Handle1 = {
	.Buff = { 0x00 },
	.CMD = { 0x26, 0x12, 0x80, 0x00, 0xA2, 0x66, 0x66, 0x93 },
	.voc_index = 0,
	.nox_index = 0,
	.VOC_Fil = 0,
	.Avg_Queue = { 0x00 },
	.Avg_Queue_P = 0,
	.First_Read = 0,
	
	.TVOC_limit = 5,
	.TVOC_power = 4.269,
	.TVOC_P = 1.0,
	.TVOC_QH = 0.001,
	.TVOC_QL = 0.0008,
	.TVOC_R = 0.1,
	.TVOC_integral = 0,
	.TVOC_Gain = 0.002,
	.TVOC_decay = 1.002,
	.TVOC_alpha = 0.2,
	.TVOC_prev = 0,
	.TVOC_lp_prev = 0,
	
	.eCO2_limit = 35,
	.eCO2_power = 3.655,
	.eCO2_P = 1.0,
	.eCO2_QH = 0.005,
	.eCO2_QL = 0.001,
	.eCO2_R = 0.01,
	.eCO2_integral = 0,
	.eCO2_Gain = 0.002,
	.eCO2_decay = 1.02,
	.eCO2_alpha = 0.2,
	.eCO2_prev = 0,
	.eCO2_lp_prev = 0,
	
	.Init_ed = 0,
	.Measure_Rate_Control_Parameters = 0,
};

void SGP30_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess)
{
	SGP30_HandleTypeDef* SGP30_Handle = (SGP30_HandleTypeDef*)Handle;
	switch(MSG.bits.Callback_Num)
	{
		case 0x00:{
			
			break;
		}
		case 0x01:{
			
			break;
		}
		default: break;
	}
}

/* SGP41初始化 */
void SGP30_Init(SGP30_HandleTypeDef* SGP30_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r)
{
	SGP30_Handle->KL_I2C_Handle = I2C_Bus;
	SGP30_Handle->ADDR_W = Addr_w;
	SGP30_Handle->ADDR_R = Addr_r;
	
	// 发送初始化命令 (0x2003)
	SGP30_Handle->Buff[0] = (SGP30_Init_CMD >> 8) & 0xFF;
	SGP30_Handle->Buff[1] = SGP30_Init_CMD & 0xFF;
	
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x00;
	KL_I2C_RegisterTask(SGP30_Handle->KL_I2C_Handle , MSG, SGP30_Handle->ADDR_W, SGP30_Handle->Buff, 2, SGP30_I2C_Callback, SGP30_Handle);
}

uint8_t SGP30_StartMeasure(SGP30_HandleTypeDef* SGP30_Handle)
{
	if (SGP30_Handle->Init_ed != 1) return 0xFF; // 未初始化
	
	SGP30_Handle->Buff[0] = (SGP30_Init_CMD >> 8) & 0xFF;
	SGP30_Handle->Buff[1] = SGP30_Init_CMD & 0xFF;
	
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x00;
	KL_I2C_RegisterTask(SGP30_Handle->KL_I2C_Handle , MSG, SGP30_Handle->ADDR_W, SGP30_Handle->Buff, 2, SGP30_I2C_Callback, SGP30_Handle);
}

uint8_t SGP41_ReadData(SGP41_HandleTypeDef* SGP41_Handle)
{
	if (SGP41_Handle->Init_ed != 1) return 0xFF;
	// 读取 6 字节数据
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x05 + SGP41_Handle->First_Read;
	return KL_I2C_RegisterTask(SGP41_Handle->KL_I2C_Handle , MSG, SGP41_Handle->ADDR_R, SGP41_Handle->Buff, SGP41_DATA_LEN, SGP41_I2C_Callback, SGP41_Handle);
}
