#include "CJ3.h"
#include "System_Core.h"
#include "filter_algorithm.h"

UART_HandleTypeDef huart6;

CJ3_HandleTypeDef CJ3_Handle = {
	.CJ3_huart = &huart6,
	.CJ3_UART = USART6,
	.CJ3_IO_Port = GPIOA,
	.CJ3_IO_Pin = GPIO_PIN_12,
	.CJ3_IO_AF = GPIO_AF8_USART6,
	.CJ3_Speed = 9600,
	.buff = { 0x00 },
	.PM1_0_Ori = 0,
	.PM1_0_Fil = 0,
	.PM2_5_Ori = 0,
	.PM2_5_Fil = 0,
	.PM10_Ori = 0,
	.PM10_Fil = 0,
	
	.PM1_0_limit = 20,
	.PM1_0_power = 2.822,
	.PM1_0_P = 1.0,
	.PM1_0_QH = 1000,
	.PM1_0_QL = 0.0005,
	.PM1_0_R = 5,
	.PM1_0_integral = 0,
	.PM1_0_Gain = 0.02,
	.PM1_0_decay = 1.05,
	.PM1_0_alpha = 0.2,
	.PM1_0_prev = 0,
	.PM1_0_lp_prev = 0,
	 
	.PM2_5_limit = 20,
	.PM2_5_power = 2.822,
	.PM2_5_P = 1.0,
	.PM2_5_QH = 1000,
	.PM2_5_QL = 0.0005,
	.PM2_5_R = 5,
	.PM2_5_integral = 0,
	.PM2_5_Gain = 0.02,
	.PM2_5_decay = 1.05,
	.PM2_5_alpha = 0.2,
	.PM2_5_prev = 0,
	.PM2_5_lp_prev = 0,
	 
	.PM10_limit = 20,
	.PM10_power = 2.822,
	.PM10_P = 1.00,
	.PM10_QH = 1000,
	.PM10_QL = 0.0005,
	.PM10_R = 5,
	.PM10_integral = 0,
	.PM10_Gain = 0.02,
	.PM10_decay = 1.05,
	.PM10_alpha = 0.2,
	.PM10_prev = 0,
	.PM10_lp_prev = 0,
	 
	.PM1_0_Avg_Queue = { 0x00 },
	.PM2_5_Avg_Queue = { 0x00 },
	.PM10_Avg_Queue = { 0x00 },
	.PM1_0_Avg_Queue_P = 0,
	.PM2_5_Avg_Queue_P = 0,
	.PM10_Avg_Queue_P = 0,
	.CJ3_State_Register = { 0x00 },
};

void CJ3_Start_Read_Data(void);

void CJ3_Receive_IT(void)
{
	switch(CJ3_Handle.CJ3_State_Register.bits.State)
	{
		case CJ3_Start:{
			uint32_t RX_Start = (uint32_t)CJ3_Handle.buff[0] << 24;
			RX_Start |= (uint32_t)CJ3_Handle.buff[1] << 16;
			RX_Start |= (uint32_t)CJ3_Handle.buff[2] << 8;
			RX_Start |= (uint32_t)CJ3_Handle.buff[3];
			if(RX_Start == 0x424D001C)
			{
//				HAL_UART_Receive_IT(CJ3_Handle.CJ3_huart, CJ3_Handle.buff + 4, 28);
				CJ3_Handle.CJ3_State_Register.bits.State = CJ3_Get_Data;
			}
			else
			{
				CJ3_Handle.buff[0] = 0;
				CJ3_Handle.buff[1] = 0;
				CJ3_Handle.buff[2] = 0;
				CJ3_Handle.buff[3] = 0;
				CJ3_Handle.CJ3_State_Register.bits.State = CJ3_Free;
				CJ3_Start_Read_Data();
				break;
			}
//			break;
		}
		case CJ3_Get_Data:{
			uint16_t CJ3_SUM = 0; uint8_t i;
			for(i = 0; i < 30; i++)
			{
				CJ3_SUM += CJ3_Handle.buff[i];
			}
			
			if(CJ3_SUM == ((uint16_t)(CJ3_Handle.buff[30] << 8) | (uint16_t)CJ3_Handle.buff[31]))
			{
				CJ3_Handle.PM1_0_Ori = ((uint16_t)(CJ3_Handle.buff[4] << 8) | (uint16_t)CJ3_Handle.buff[5]);
				CJ3_Handle.PM2_5_Ori = ((uint16_t)(CJ3_Handle.buff[6] << 8) | (uint16_t)CJ3_Handle.buff[7]);
				CJ3_Handle.PM10_Ori  = ((uint16_t)(CJ3_Handle.buff[8] << 8) | (uint16_t)CJ3_Handle.buff[9]);
			}
			CJ3_Handle.PM1_0_Avg_Queue[CJ3_Handle.PM1_0_Avg_Queue_P] = (float)(CJ3_Handle.PM1_0_Ori);
			CJ3_Handle.PM2_5_Avg_Queue[CJ3_Handle.PM2_5_Avg_Queue_P] = (float)(CJ3_Handle.PM2_5_Ori);
			CJ3_Handle.PM10_Avg_Queue[CJ3_Handle.PM10_Avg_Queue_P] = (float)(CJ3_Handle.PM10_Ori);
			if(	(CJ3_Handle.PM1_0_Avg_Queue_P < (CJ3_Avg_Len - 1)) &&
				(CJ3_Handle.PM2_5_Avg_Queue_P < (CJ3_Avg_Len - 1)) &&
				(CJ3_Handle.PM10_Avg_Queue_P < (CJ3_Avg_Len - 1)))
			{
				CJ3_Handle.PM1_0_Avg_Queue_P++;
				CJ3_Handle.PM2_5_Avg_Queue_P++;
				CJ3_Handle.PM10_Avg_Queue_P++;
			}
			else
			{
				float PM1_0_Avg = Avg_Filter_float(CJ3_Handle.PM1_0_Avg_Queue, CJ3_Avg_Len);
				float PM2_5_Avg = Avg_Filter_float(CJ3_Handle.PM2_5_Avg_Queue, CJ3_Avg_Len);
				float PM10_Avg = Avg_Filter_float(CJ3_Handle.PM10_Avg_Queue, CJ3_Avg_Len);
				
				if(CJ3_Handle.CJ3_State_Register.bits.First_Get == 0)
				{
					CJ3_Handle.PM1_0_Fil = PM1_0_Avg;
					CJ3_Handle.PM1_0_prev = PM1_0_Avg;
					CJ3_Handle.PM1_0_lp_prev = PM1_0_Avg;
					CJ3_Handle.PM2_5_Fil = PM2_5_Avg;
					CJ3_Handle.PM2_5_prev = PM2_5_Avg;
					CJ3_Handle.PM2_5_lp_prev = PM2_5_Avg;
					CJ3_Handle.PM10_Fil = PM10_Avg;
					CJ3_Handle.PM10_prev = PM10_Avg;
					CJ3_Handle.PM10_lp_prev = PM10_Avg;
					CJ3_Handle.CJ3_State_Register.bits.First_Get = 1;
				}
				else
				{
					CJ3_Handle.PM1_0_Fil = (uint16_t)(Kalman_Filter_Step(	&PM1_0_Avg,
																			&(CJ3_Handle.PM1_0_prev),
																			&(CJ3_Handle.PM1_0_P), 
																			CJ3_Handle.PM1_0_limit,
																			CJ3_Handle.PM1_0_power,
																			CJ3_Handle.PM1_0_QL,
																			CJ3_Handle.PM1_0_QH,
																			CJ3_Handle.PM1_0_R,
																			&(CJ3_Handle.PM1_0_integral),
																			&(CJ3_Handle.PM1_0_lp_prev),
																			CJ3_Handle.PM1_0_Gain,
																			CJ3_Handle.PM1_0_decay,
																			CJ3_Handle.PM1_0_alpha
																			) +0.5f);
					
					CJ3_Handle.PM2_5_Fil = (uint16_t)(Kalman_Filter_Step(	&PM2_5_Avg,
																			&(CJ3_Handle.PM2_5_prev),
																			&(CJ3_Handle.PM2_5_P), 
																			CJ3_Handle.PM2_5_limit,
																			CJ3_Handle.PM2_5_power,
																			CJ3_Handle.PM2_5_QL,
																			CJ3_Handle.PM2_5_QH,
																			CJ3_Handle.PM2_5_R,
																			&(CJ3_Handle.PM2_5_integral),
																			&(CJ3_Handle.PM2_5_lp_prev),
																			CJ3_Handle.PM2_5_Gain,
																			CJ3_Handle.PM2_5_decay,
																			CJ3_Handle.PM2_5_alpha
																			) +0.5f);
					
					CJ3_Handle.PM10_Fil = (uint16_t)(Kalman_Filter_Step(	&PM10_Avg,
																			&(CJ3_Handle.PM10_prev),
																			&(CJ3_Handle.PM10_P), 
																			CJ3_Handle.PM10_limit,
																			CJ3_Handle.PM10_power,
																			CJ3_Handle.PM10_QL,
																			CJ3_Handle.PM10_QH,
																			CJ3_Handle.PM10_R,
																			&(CJ3_Handle.PM10_integral),
																			&(CJ3_Handle.PM10_lp_prev),
																			CJ3_Handle.PM10_Gain,
																			CJ3_Handle.PM10_decay,
																			CJ3_Handle.PM10_alpha
																			) +0.5f);
				}
				
				CJ3_Handle.PM1_0_Avg_Queue_P = 0;
				CJ3_Handle.PM2_5_Avg_Queue_P = 0;
				CJ3_Handle.PM10_Avg_Queue_P = 0;
			}
			
			CJ3_Handle.CJ3_State_Register.bits.State = CJ3_Free;
			CJ3_Start_Read_Data();
			break;
		}
		default: break;
	}
}

void CJ3_Pin_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOC_CLK_ENABLE();

	GPIO_InitStruct.Pin = CJ3_Handle.CJ3_IO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = CJ3_Handle.CJ3_IO_AF;
	HAL_GPIO_Init(CJ3_Handle.CJ3_IO_Port, &GPIO_InitStruct);
}

void CJ3_UART_Init(void)
{
	HAL_NVIC_SetPriority(USART6_IRQn, 3, 0);
	HAL_NVIC_EnableIRQ(USART6_IRQn);
	
	__HAL_RCC_USART6_CLK_ENABLE();
	(CJ3_Handle.CJ3_huart)->Instance = CJ3_Handle.CJ3_UART;
	(CJ3_Handle.CJ3_huart)->Init.BaudRate = CJ3_Handle.CJ3_Speed;
	(CJ3_Handle.CJ3_huart)->Init.WordLength = UART_WORDLENGTH_8B;
	(CJ3_Handle.CJ3_huart)->Init.StopBits = UART_STOPBITS_1;
	(CJ3_Handle.CJ3_huart)->Init.Parity = UART_PARITY_NONE;
	(CJ3_Handle.CJ3_huart)->Init.Mode = UART_MODE_RX;
	(CJ3_Handle.CJ3_huart)->Init.HwFlowCtl = UART_HWCONTROL_NONE;
	(CJ3_Handle.CJ3_huart)->Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(CJ3_Handle.CJ3_huart) != HAL_OK) Error_Handler();
}

void CJ3_Init(void)
{
	CJ3_Pin_Init();
	CJ3_UART_Init();
	CJ3_Handle.CJ3_State_Register.bits.First_Get = 0;
	CJ3_Handle.CJ3_State_Register.bits.State = CJ3_Free;
	CJ3_Start_Read_Data();
}

void CJ3_Start_Read_Data(void)
{
	if(CJ3_Handle.CJ3_State_Register.bits.State != CJ3_Free) return;
	HAL_UART_Receive_IT(CJ3_Handle.CJ3_huart, CJ3_Handle.buff, 32);
	CJ3_Handle.CJ3_State_Register.bits.State = CJ3_Start;
}

// 中断服务函数
void USART6_IRQHandler(void)
{ HAL_UART_IRQHandler(CJ3_Handle.CJ3_huart); }

