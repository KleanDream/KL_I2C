#ifndef __CJ3_H
#define __CJ3_H

#include "main.h"

// CJ3传感器状态码
#define CJ3_Free		0
#define CJ3_Start		1
#define CJ3_Get_Data	2

#define CJ3_Avg_Len		(10)
#define CJ3_Data_Len	(32)

typedef union{
	struct {
		uint8_t	State				: 2;	// 传输状态
		uint8_t First_Get			: 1;	// 初始化完成标志位
		uint8_t	reserved			: 5;	// 保留
	} bits;
	uint8_t byte;         // 整体访问，主要是清空时使用
}CJ3_State;

typedef struct {
	UART_HandleTypeDef*		CJ3_huart;
	USART_TypeDef*			CJ3_UART;
	GPIO_TypeDef*			CJ3_IO_Port;
	uint32_t				CJ3_Speed;
	uint16_t				CJ3_IO_Pin;
	uint8_t					CJ3_IO_AF;
	CJ3_State				CJ3_State_Register; // 状态
	uint8_t					buff[CJ3_Data_Len];	// 数据缓冲区
	uint16_t				PM1_0_Ori;			// 测得PM1.0数据(原始)
	uint16_t				PM1_0_Fil;			// 测得PM1.0数据(滤波) - 当前输出
	uint16_t				PM2_5_Ori;			// 测得PM2.5数据(原始)
	uint16_t				PM2_5_Fil;			// 测得PM2.5数据(滤波) - 当前输出
	uint16_t				PM10_Ori;			// 测得PM10数据(原始)
	uint16_t				PM10_Fil;			// 测得PM10数据(滤波) - 当前输出
	
	// ---------- 滤波参数 ----------
	// PM1.0
	float					PM1_0_limit;		// 差值限幅
	float					PM1_0_power;		// 幂参数
	float					PM1_0_P;			// 卡尔曼滤波协方差
	float					PM1_0_QH;			// 滤波Q值上限
	float					PM1_0_QL;			// 滤波Q值下限
	float					PM1_0_R;			// 滤波R值
	float					PM1_0_integral;		// 积分补偿基值
	float					PM1_0_Gain;			// 积分补偿增益
	float					PM1_0_decay;		// 积分补偿基值衰减参数
	float					PM1_0_alpha;		// 低通滤波参数
	float					PM1_0_prev;			// 上一次卡尔曼滤波值（x_hat）
	float					PM1_0_lp_prev;		// 上一次低通输出（lp_prev）
	
	// PM2.5
	float					PM2_5_limit;		// 差值限幅
	float					PM2_5_power;		// 幂参数
	float					PM2_5_P;			// 卡尔曼滤波协方差
	float					PM2_5_QH;			// 滤波Q值上限
	float					PM2_5_QL;			// 滤波Q值下限
	float					PM2_5_R;			// 滤波R值
	float					PM2_5_integral;		// 积分补偿基值
	float					PM2_5_Gain;			// 积分补偿增益
	float					PM2_5_decay;		// 积分补偿基值衰减参数
	float					PM2_5_alpha;		// 低通滤波参数
	float					PM2_5_prev;			// 上一次卡尔曼滤波值（x_hat）
	float					PM2_5_lp_prev;		// 上一次低通输出（lp_prev）
	
	// PM10
	float					PM10_limit;			// 差值限幅
	float					PM10_power;			// 幂参数
	float					PM10_P;				// 卡尔曼滤波协方差
	float					PM10_QH;			// 滤波Q值上限
	float					PM10_QL;			// 滤波Q值下限
	float					PM10_R;				// 滤波R值
	float					PM10_integral;		// 积分补偿基值
	float					PM10_Gain;			// 积分补偿增益
	float					PM10_decay;			// 积分补偿基值衰减参数
	float					PM10_alpha;			// 低通滤波参数
	float					PM10_prev;			// 上一次卡尔曼滤波值（x_hat）
	float					PM10_lp_prev;		// 上一次低通输出（lp_prev）
	
	// ---------- 均值计算 ----------
	float					PM1_0_Avg_Queue[CJ3_Avg_Len];	// PM1.0均值计算队列
	float					PM2_5_Avg_Queue[CJ3_Avg_Len];	// PM2.5均值计算队列
	float					PM10_Avg_Queue[CJ3_Avg_Len];	// PM10均值计算队列
	uint8_t					PM1_0_Avg_Queue_P;	// PM1.0均值计算队列指针
	uint8_t					PM2_5_Avg_Queue_P;	// PM2.5均值计算队列指针
	uint8_t					PM10_Avg_Queue_P;	// PM10均值计算队列指针
} CJ3_HandleTypeDef;

extern CJ3_HandleTypeDef CJ3_Handle;

void CJ3_Receive_IT(void);
void CJ3_Init(void);
#endif
