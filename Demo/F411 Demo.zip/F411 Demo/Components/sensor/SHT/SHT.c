#include "SHT.h"
#include "CRC.h"
#include "math.h"
#include "Filter_algorithm.h"
#include "System_Core.h"

#define SHT_CRC 0x31 // X^8 + X^5 + X^4 + 1

SHT_HandleTypeDef SHT45_Handle1 = {
	// 底层架构部分
	.Buff = { 0x00 },
	.MSG.bits.First_Read = 0,
	.Measure_Rate_Control_Parameters = 0,
	// 实时值初始化
	.Temp_RTim = 0,
	.Temp_RTim_u16 = 0,
	.Humi_RTim = 0,
	.Humi_RTim_u16 = 0,
	// 均值滤波部分
	.Avg_Queue_P = 0,
	.Avg_Queue_T = { 0x00 },
	.Avg_Queue_H = { 0x00 },
	// 卡尔曼滤波部分
	.Temp_limit = 0.1,
	.Temp_power = 10.968,
	.Temp_P = 1.0,
	.Temp_QH = 0.1,
	.Temp_QL = 0.0005,
	.Temp_R = 0.4,
	.Temp_Fil = 0,
	.Temp_lp_prev = 0,
	.Temp_prev = 0,
	
	.Humi_limit = 1.75,
	.Humi_power = 4.996,
	.Humi_P = 1.0,
	.Humi_QH = 0.3,
	.Humi_QL = 0.001,
	.Humi_R = 2.5,
	.Humi_Fil = 0,
	.Humi_lp_prev = 0,
	.Humi_prev = 0,
	// 输出部分（积分补偿）
	.Temp_integral = 0,
	.Temp_Gain = 0.05,
	.Temp_decay = 1.01,
	.Temp_alpha = 0.2,
	
	.Humi_integral = 0,
	.Humi_Gain = 0.05,
	.Humi_decay = 1.05,
	.Humi_alpha = 0.2,
};


uint8_t HT_Measure_Rate_Control_Parameters = 0;

void SHT_Init(SHT_HandleTypeDef* SHT_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr, uint8_t Type)
{
	SHT_Handle->KL_I2C_Handle = I2C_Bus;
	SHT_Handle->ADDR = Addr;
	SHT_Handle->MSG.bits.Type = Type;
	return;
}

void SHT_Data_T_To_Float(SHT_HandleTypeDef* SHT_Handle)
{
	SHT_Handle->Temp_RTim = -45.0f + (175.0f * (float)SHT_Handle->Temp_RTim_u16 / 65535.00f);
	if(SHT_Handle->Temp_RTim > 125.0f) SHT_Handle->Temp_RTim = 125.0f;
	if(SHT_Handle->Temp_RTim < -40.0f) SHT_Handle->Temp_RTim = -40.0f;
}
	
void SHT_Data_H_To_Float(SHT_HandleTypeDef* SHT_Handle)
{
	SHT_Handle->Humi_RTim = -6.0f + 125.0f * (float)SHT_Handle->Humi_RTim_u16 / 65535.00f;
	if(SHT_Handle->Humi_RTim > 100.0f) SHT_Handle->Humi_RTim = 100.0f;
	if(SHT_Handle->Humi_RTim < 0.0f)   SHT_Handle->Humi_RTim = 0.0f;
}

void SHT_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess)
{
	SHT_HandleTypeDef* SHT_Handle = (SHT_HandleTypeDef*)Handle;
	switch(MSG.bits.Callback_Num)
	{
		case 0x01:{
			//无需操作
			break;
		}
		case 0x02:{
			if(CRC_Verify_8(&SHT_Handle->Buff[0],2,SHT_CRC) != SHT_Handle->Buff[2]) break;
				SHT_Handle->Temp_RTim_u16 = (SHT_Handle->Buff[0] << 8) + SHT_Handle->Buff[1];
			SHT_Data_T_To_Float(SHT_Handle);
			SHT_Handle->Temp_prev = SHT_Handle->Temp_RTim;
			SHT_Handle->Temp_lp_prev = SHT_Handle->Temp_RTim;
			SHT_Handle->Temp_Fil = SHT_Handle->Temp_RTim;
			SHT_Handle->Avg_Queue_T[SHT_Handle->Avg_Queue_P] = SHT_Handle->Temp_RTim;
			
			if(CRC_Verify_8(&SHT_Handle->Buff[3],2,SHT_CRC) != SHT_Handle->Buff[5]) break;
				SHT_Handle->Humi_RTim_u16  = (SHT_Handle->Buff[3] << 8) + SHT_Handle->Buff[4];
			SHT_Data_H_To_Float(SHT_Handle);
			SHT_Handle->Humi_prev = SHT_Handle->Humi_RTim;
			SHT_Handle->Humi_lp_prev = SHT_Handle->Humi_RTim;
			SHT_Handle->Humi_Fil = SHT_Handle->Humi_RTim;
			SHT_Handle->Avg_Queue_H[SHT_Handle->Avg_Queue_P] = SHT_Handle->Humi_RTim;
			
			SHT_Handle->MSG.bits.First_Read = 1;
			break;
		}
		case 0x03:{
			if(CRC_Verify_8(&SHT_Handle->Buff[0],2,SHT_CRC) != SHT_Handle->Buff[2]) break;
				SHT_Handle->Temp_RTim_u16 = (SHT_Handle->Buff[0] << 8) + SHT_Handle->Buff[1];
			SHT_Data_T_To_Float(SHT_Handle);
			if(CRC_Verify_8(&SHT_Handle->Buff[3],2,SHT_CRC) != SHT_Handle->Buff[5]) break;
				SHT_Handle->Humi_RTim_u16  = (SHT_Handle->Buff[3] << 8) + SHT_Handle->Buff[4];
			SHT_Data_H_To_Float(SHT_Handle);
			if(SHT_Handle->Avg_Queue_P < (SHT45_Avg_Len - 1))
				SHT_Handle->Avg_Queue_P++;
			else
			{
				float Temp_Avg,Humi_Avg;
				Temp_Avg = Avg_Filter_float(SHT_Handle->Avg_Queue_T, SHT45_Avg_Len);
				Humi_Avg = Avg_Filter_float(SHT_Handle->Avg_Queue_H, SHT45_Avg_Len);
				SHT_Handle->Temp_Fil = Kalman_Filter_Step(&Temp_Avg,
															&(SHT_Handle->Temp_prev),
															&(SHT_Handle->Temp_P), 
															SHT_Handle->Temp_limit,
															SHT_Handle->Temp_power,
															SHT_Handle->Temp_QL,
															SHT_Handle->Temp_QH,
															SHT_Handle->Temp_R,
															&(SHT_Handle->Temp_integral),
															&(SHT_Handle->Temp_lp_prev),
															SHT_Handle->Temp_Gain,
															SHT_Handle->Temp_decay,
															SHT_Handle->Temp_alpha
															);
				SHT_Handle->Humi_Fil = Kalman_Filter_Step(&Humi_Avg,
															&(SHT_Handle->Humi_prev),
															&(SHT_Handle->Humi_P), 
															SHT_Handle->Humi_limit,
															SHT_Handle->Humi_power,
															SHT_Handle->Humi_QL,
															SHT_Handle->Humi_QH,
															SHT_Handle->Humi_R,
															&(SHT_Handle->Humi_integral),
															&(SHT_Handle->Humi_lp_prev),
															SHT_Handle->Humi_Gain,
															SHT_Handle->Humi_decay,
															SHT_Handle->Humi_alpha
															);
				SHT_Handle->Avg_Queue_P = 0;
			}
			SHT_Handle->Avg_Queue_T[SHT_Handle->Avg_Queue_P] = SHT_Handle->Temp_RTim;
			SHT_Handle->Avg_Queue_H[SHT_Handle->Avg_Queue_P] = SHT_Handle->Humi_RTim;
			break;
		}
		default: break;
	}
}

/* 发送测量指令 */
uint8_t SHT_StartMeasure(SHT_HandleTypeDef* SHT_Handle)
{
	static uint8_t cmd_sht45 = 0xFD;
	static uint8_t cmd_sht30[2] = { 0x2C, 0x06 };
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x01;
	if(SHT_Handle->MSG.bits.Type == SHT_Type_SHT30)
		return KL_I2C_RegisterTask(SHT_Handle->KL_I2C_Handle, MSG, SHT_Handle->ADDR, cmd_sht30, sizeof(cmd_sht30), SHT_I2C_Callback, SHT_Handle);
	else if(SHT_Handle->MSG.bits.Type == SHT_Type_SHT45)
		return KL_I2C_RegisterTask(SHT_Handle->KL_I2C_Handle, MSG, SHT_Handle->ADDR, &cmd_sht45, sizeof(cmd_sht45), SHT_I2C_Callback, SHT_Handle);
	return 0x7F;
}

/* 读温湿度数据 */
uint8_t SHT_Read_TempHumi(SHT_HandleTypeDef* SHT_Handle)
{
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x02 + SHT_Handle->MSG.bits.First_Read;
	return KL_I2C_RegisterTask(SHT_Handle->KL_I2C_Handle, MSG, SHT_Handle->ADDR, SHT_Handle->Buff, SHT_DATA_LEN, SHT_I2C_Callback, SHT_Handle);
}

float SHT_Get_Dv(SHT_HandleTypeDef* SHT_Handle)
{
	float Dv = 0;
	Dv = 216.7f * SHT_Handle->Humi_Fil * 6.112f * expf(17.62f * SHT_Handle->Temp_Fil / (243.12f + SHT_Handle->Temp_Fil)) / (273.15f + SHT_Handle->Temp_Fil);
	return Dv;
}

///* 计算体感温度 */
//void SHT45_Get_S_Temp_RTim(float *S_Temp_RTim)
//{
//	float Temp_RTim = 
//	*S_Temp_RTim = -8.784695f +1.61139411f * Temp_RTim + 2.338549f * Humi - 0.14611605f * Temp_RTim * Humi
//		- 0.012308094f * Temp_RTim * Temp_RTim - 0.016424828f * Humi * Humi + 0.002211732f * Temp_RTim * Temp_RTim * Humi
//		+ 0.00072546f * Temp_RTim * Humi * Humi - 0.000003582f * Temp_RTim * Temp_RTim * Humi * Humi;
//}
