#ifndef _SHT_H_
#define _SHT_H_

#include "main.h"
#include "KL_I2C.h"

#define SHT_Type_SHT30		0x30
#define SHT30_ADDR			(uint8_t)(0x44<<1)

#define SHT_Type_SHT45		0x45
#define SHT45_ADDR			(uint8_t)(0x44<<1)

#define SHT_DATA_LEN		(6)
#define SHT45_Avg_Len		(20)

typedef union{
	struct {
		uint8_t	Type				: 7;	// 传感器型号
		uint8_t	First_Read			: 1;	// 首次读取标志位
	} bits;
	uint8_t byte;         // 整体访问，主要是清空时使用
}SHT_MSG;

typedef struct {
	KL_I2C_HandleTypeDef*	KL_I2C_Handle;		// 总线绑定
	uint8_t					Buff[SHT_DATA_LEN];	// 数据缓冲区
	float					Temp_RTim;			// 测得温度数据(实时)
	float					Humi_RTim;			// 测得湿度数据(实时)
	uint16_t 				Temp_RTim_u16;		// 测得原始数据(实时)
	uint16_t 				Humi_RTim_u16;		// 测得原始数据(实时)
	
	// ---------- 温度滤波参数 ----------
	float					Temp_limit;			// 温度差值限幅
	float					Temp_power;			// 幂参数(温度)
	float					Temp_P;				// 卡尔曼滤波协方差(温度)
	float					Temp_QH;			// 滤波Q值上限(温度)
	float					Temp_QL;			// 滤波Q值下限(温度)
	float					Temp_R;				// 滤波R值(温度)
	float					Temp_Fil;			// 测得温度数据(滤波) - 当前输出
	float					Temp_integral;		// 积分补偿基值(温度)
	float					Temp_Gain;			// 积分补偿增益(温度)
	float					Temp_decay;			// 积分补偿基值衰减参数(温度)
	float					Temp_alpha;			// 低通滤波参数(温度)
	float					Temp_prev;			// 新增：上一次卡尔曼滤波值（x_hat）
	float					Temp_lp_prev;		// 新增：上一次低通输出（lp_prev）

	// ---------- 湿度滤波参数 ----------
	float					Humi_limit;			// 湿度差值限幅
	float					Humi_power;			// 幂参数(湿度)
	float					Humi_P;				// 卡尔曼滤波协方差(湿度)
	float					Humi_QH;			// 滤波Q值上限(湿度)
	float					Humi_QL;			// 滤波Q值下限(湿度)
	float					Humi_R;				// 滤波R值(湿度)
	float					Humi_Fil;			// 测得湿度数据(滤波) - 当前输出
	float					Humi_integral;		// 积分补偿基值(湿度)
	float					Humi_Gain;			// 积分补偿增益(湿度)
	float					Humi_decay;			// 积分补偿基值衰减参数(湿度)
	float					Humi_alpha;			// 低通滤波参数(湿度)
	float					Humi_prev;			// 新增：上一次卡尔曼滤波值（x_hat）
	float					Humi_lp_prev;		// 新增：上一次低通输出（lp_prev）

	// ---------- 其他 ----------
	float					Avg_Queue_T[SHT45_Avg_Len];		// 均值计算队列(温度)
	float					Avg_Queue_H[SHT45_Avg_Len];		// 均值计算队列(湿度)
	uint8_t					Avg_Queue_P;		// 均值计算队列指针
	uint8_t					ADDR;				// 地址
	SHT_MSG					MSG;				// 传感器信息
	uint8_t					Measure_Rate_Control_Parameters;	// 采样速率控制参数
} SHT_HandleTypeDef;

/* =======SHT句柄配置======== */
#define SHT45_I2C_Handle1 	KL_I2C2_Handle
extern SHT_HandleTypeDef SHT45_Handle1;
/* ============================ */

void SHT_Init(SHT_HandleTypeDef* SHT_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr, uint8_t Type);
uint8_t SHT_StartMeasure(SHT_HandleTypeDef* SHT_Handle);
uint8_t SHT_Read_TempHumi(SHT_HandleTypeDef* SHT_Handle);
//void SHT_Get_S_Temp_RTim(float *S_Temp_RTim);
//void SHT_Data_f_u8zip(float *Temp_RTim, float *Humi, uint8_t *Data);
//void SHT_Data_Unzip(float *Temp_RTim, float *Humi, uint8_t *Data);
#endif
