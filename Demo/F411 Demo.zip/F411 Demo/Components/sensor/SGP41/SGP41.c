#include "SGP41.h"
#include "filter_algorithm.h"
#include "System_Core.h"
#include "CRC.h"

// CRC 相关定义
#define SGP41_CRC8_POLYNOMIAL	0x31

SGP41_HandleTypeDef SGP41_Handle1 = {
	.Buff = { 0x00 },
	.CMD = { 0x26, 0x12, 0x80, 0x00, 0xA2, 0x66, 0x66, 0x93 },
	.voc_index = 0,Q2
	.nox_index = 0,
	.VOC_Fil = 0,
	.Avg_Queue = { 0x00 },
	.Avg_Queue_P = 0,
	.First_Read = 0,
	
	.VOC_limit = 5,
	.VOC_power = 4.269,
	.VOC_P = 1.0,
	.VOC_QH = 0.001,
	.VOC_QL = 0.0008,
	.VOC_R = 0.1,
	.VOC_integral = 0,
	.VOC_Gain = 0.002,
	.VOC_decay = 1.002,
	.VOC_alpha = 0.2,
	.VOC_prev = 0,
	.VOC_lp_prev = 0,
	
	.Init_ed = 0,
	.Measure_Rate_Control_Parameters = 0,
};

void SGP41_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess);

/* SGP41上电自检 */
uint8_t SGP41_Init_Self_Test(SGP41_HandleTypeDef* SGP41_Handle)
{	// 发送自检命令 (0x280E)
	SGP41_Handle->Buff[0] = (SGP41_CMD_SELF_TEST >> 8) & 0xFF;
	SGP41_Handle->Buff[1] = SGP41_CMD_SELF_TEST & 0xFF;
	
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x00;
	return KL_I2C_RegisterTask(SGP41_Handle->KL_I2C_Handle , MSG, SGP41_Handle->ADDR_W, SGP41_Handle->Buff, 2, SGP41_I2C_Callback, SGP41_Handle);
}

/* SGP41读取自检结果 */
uint8_t SGP41_Init_Self_Test_Read_Results(SGP41_HandleTypeDef* SGP41_Handle)
{
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x01;
	return KL_I2C_RegisterTask(SGP41_Handle->KL_I2C_Handle , MSG, SGP41_Handle->ADDR_R, SGP41_Handle->Buff, 3, SGP41_I2C_Callback, SGP41_Handle);
}

void SGP41_I2C_Callback(KL_I2C_Task_MSG MSG, void* Handle, uint8_t isSuccess)
{
	SGP41_HandleTypeDef* SGP41_Handle = (SGP41_HandleTypeDef*)Handle;
	switch(MSG.bits.Callback_Num)
	{
		case 0x00:{
			
			break;
		}
		case 0x01:{
			if (CRC_Verify_8(&SGP41_Handle->Buff[0], 2, SGP41_CRC8_POLYNOMIAL) == SGP41_Handle->Buff[2])
			{
				uint16_t test_result = (SGP41_Handle->Buff[0] << 8) | SGP41_Handle->Buff[1];
				if (test_result == 0xD400)
				{
					KL_I2C_Task_MSG MSG;
					MSG.bits.Type = KL_I2C_COM_Tra;
					MSG.bits.Callback_Num = 0x03;
					KL_I2C_RegisterTask(SGP41_Handle->KL_I2C_Handle , MSG, SGP41_Handle->ADDR_W, SGP41_Handle->CMD, SGP41_CMD_LEN, SGP41_I2C_Callback, SGP41_Handle);
				}
			}
			break;
		}
		case 0x03:{
			SGP41_Handle->CMD[0] = (SGP41_CMD_MEASURE_RAW >> 8) & 0xFF;
			SGP41_Handle->CMD[1] = SGP41_CMD_MEASURE_RAW & 0xFF;
			SGP41_Handle->Init_ed = 1;
			break;
		}
		case 0x04:{
			
			break;
		}
		case 0x05:{
			if( (CRC_Verify_8(&SGP41_Handle->Buff[0], 2, SGP41_CRC8_POLYNOMIAL) == SGP41_Handle->Buff[2]) && 
				(CRC_Verify_8(&SGP41_Handle->Buff[3], 2, SGP41_CRC8_POLYNOMIAL) == SGP41_Handle->Buff[5]) )
			{
				// 拼接原始值
				int32_t sraw_voc = (SGP41_Handle->Buff[0] << 8) | SGP41_Handle->Buff[1];
				int32_t sraw_nox = (SGP41_Handle->Buff[3] << 8) | SGP41_Handle->Buff[4];

				// 调用官方算法库计算指数
				GasIndexAlgorithm_process(&SGP41_Handle->voc_params, sraw_voc, &SGP41_Handle->voc_index);
				GasIndexAlgorithm_process(&SGP41_Handle->nox_params, sraw_nox, &SGP41_Handle->nox_index);
			}
			SGP41_Handle->VOC_prev = (float)SGP41_Handle->voc_index;
			SGP41_Handle->VOC_lp_prev = (float)SGP41_Handle->voc_index;
			SGP41_Handle->VOC_Fil = SGP41_Handle->voc_index;
			SGP41_Handle->Avg_Queue[SGP41_Handle->Avg_Queue_P] = (float)SGP41_Handle->voc_index;
			if(SGP41_Handle->voc_params.mUptime >= 50 && SGP41_Handle->nox_params.mUptime >= 50)
				SGP41_Handle->First_Read = 1;
		}
		case 0x06:{
			if( (CRC_Verify_8(&SGP41_Handle->Buff[0], 2, SGP41_CRC8_POLYNOMIAL) == SGP41_Handle->Buff[2]) && 
				(CRC_Verify_8(&SGP41_Handle->Buff[3], 2, SGP41_CRC8_POLYNOMIAL) == SGP41_Handle->Buff[5]) )
			{
				// 拼接原始值
				int32_t sraw_voc = (SGP41_Handle->Buff[0] << 8) | SGP41_Handle->Buff[1];
				int32_t sraw_nox = (SGP41_Handle->Buff[3] << 8) | SGP41_Handle->Buff[4];

				// 调用官方算法库计算指数
				GasIndexAlgorithm_process(&SGP41_Handle->voc_params, sraw_voc, &SGP41_Handle->voc_index);
				GasIndexAlgorithm_process(&SGP41_Handle->nox_params, sraw_nox, &SGP41_Handle->nox_index);
			}
			if(SGP41_Handle->Avg_Queue_P < (SGP41_Avg_Len - 1))
				SGP41_Handle->Avg_Queue_P++;
			else
			{
				float VOC_Avg;
				VOC_Avg = Avg_Filter_float(SGP41_Handle->Avg_Queue, SGP41_Avg_Len);
				SGP41_Handle->VOC_Fil = (uint16_t)(Kalman_Filter_Step(&VOC_Avg,
																		&(SGP41_Handle->VOC_prev),
																		&(SGP41_Handle->VOC_P), 
																		SGP41_Handle->VOC_limit,
																		SGP41_Handle->VOC_power,
																		SGP41_Handle->VOC_QL,
																		SGP41_Handle->VOC_QH,
																		SGP41_Handle->VOC_R,
																		&(SGP41_Handle->VOC_integral),
																		&(SGP41_Handle->VOC_lp_prev),
																		SGP41_Handle->VOC_Gain,
																		SGP41_Handle->VOC_decay,
																		SGP41_Handle->VOC_alpha
																		) +0.5f);
				if(SGP41_Handle->VOC_Fil > 500) SGP41_Handle->VOC_Fil = 500;
				SGP41_Handle->Avg_Queue_P = 0;
			}
			SGP41_Handle->Avg_Queue[SGP41_Handle->Avg_Queue_P] = SGP41_Handle->voc_index;
		}
		default: break;
	}
}

/* SGP41初始化 */
void SGP41_Init(SGP41_HandleTypeDef* SGP41_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r)
{
	SGP41_Handle->KL_I2C_Handle = I2C_Bus;
	SGP41_Handle->ADDR_W = Addr_w;
	SGP41_Handle->ADDR_R = Addr_r;
	
	// 1. 初始化算法库
	GasIndexAlgorithm_init(&SGP41_Handle->voc_params, GasIndexAlgorithm_ALGORITHM_TYPE_VOC);
	GasIndexAlgorithm_init(&SGP41_Handle->nox_params, GasIndexAlgorithm_ALGORITHM_TYPE_NOX);
	
	// 发送自检命令 (0x280E)
	SGP41_Init_Self_Test(SGP41_Handle);
	
	HAL_Delay(500);
	
	SGP41_Init_Self_Test_Read_Results(SGP41_Handle);
}

uint8_t SGP41_StartMeasure(SGP41_HandleTypeDef* SGP41_Handle)
{
	if (SGP41_Handle->Init_ed != 1) return 0xFF; // 未初始化
	
	// 填充湿度参数 (2字节数据 + 1字节CRC)
	SGP41_Handle->CMD[2] = (SHT45_Handle1.Humi_RTim_u16 >> 8) & 0xFF;
	SGP41_Handle->CMD[3] = SHT45_Handle1.Humi_RTim_u16 & 0xFF;
	SGP41_Handle->CMD[4] = CRC_Verify_8(&SGP41_Handle->CMD[2], 2, SGP41_CRC8_POLYNOMIAL);

	// 填充温度参数 (2字节数据 + 1字节CRC)
	SGP41_Handle->CMD[5] = (SHT45_Handle1.Temp_RTim_u16 >> 8) & 0xFF;
	SGP41_Handle->CMD[6] = SHT45_Handle1.Temp_RTim_u16 & 0xFF;
	SGP41_Handle->CMD[7] = CRC_Verify_8(&SGP41_Handle->CMD[5], 2, SGP41_CRC8_POLYNOMIAL);

	// 4. 通过 I2C 发送
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Tra;
	MSG.bits.Callback_Num = 0x04;
	return KL_I2C_RegisterTask(SGP41_Handle->KL_I2C_Handle , MSG, SGP41_Handle->ADDR_W, SGP41_Handle->CMD, SGP41_CMD_LEN, SGP41_I2C_Callback, SGP41_Handle);
}

uint8_t SGP41_ReadData(SGP41_HandleTypeDef* SGP41_Handle)
{
	if (SGP41_Handle->Init_ed != 1) return 0xFF;
	// 读取 6 字节数据
	KL_I2C_Task_MSG MSG;
	MSG.bits.Type = KL_I2C_COM_Rec;
	MSG.bits.Callback_Num = 0x05 + SGP41_Handle->First_Read;
	return KL_I2C_RegisterTask(SGP41_Handle->KL_I2C_Handle , MSG, SGP41_Handle->ADDR_R, SGP41_Handle->Buff, SGP41_DATA_LEN, SGP41_I2C_Callback, SGP41_Handle);
}
