#ifndef SGP41_H
#define SGP41_H

#include "main.h"
#include "sensirion_gas_index_algorithm.h"
#include "KL_I2C.h"

#define SGP41_ADDR_WRITE    (uint8_t)(0x59<<1)
#define SGP41_ADDR_READ     (uint8_t)((0x59<<1) | 1)
#define SGP41_DATA_LEN			(6)
#define SGP41_CMD_LEN			(8)
#define SGP41_Avg_Len			(10)

// 命令宏定义
#define SGP41_CMD_MEASURE_RAW        0x2619
#define SGP41_CMD_EXECUTE_CONDITION  0x2612
#define SGP41_CMD_SELF_TEST          0x280E
#define SGP41_CMD_HEATER_OFF         0x3615

typedef struct {
	KL_I2C_HandleTypeDef*	KL_I2C_Handle;		// 总线绑定
	uint8_t					Buff[SGP41_DATA_LEN];		// 数据缓冲区
	uint8_t					CMD[SGP41_CMD_LEN];			// 命令缓冲区
	GasIndexAlgorithmParams	voc_params;			// 厂家算法参数结构体
	GasIndexAlgorithmParams nox_params;			// 厂家算法参数结构体
	int32_t 				voc_index;			// 测得数据
	int32_t 				nox_index;			// 测得数据
	
	// ---------- 滤波参数 ----------
	float					VOC_limit;			// 差值限幅
	float					VOC_power;			// 幂参数
	float					VOC_P;				// 卡尔曼滤波协方差
	float					VOC_QH;				// 滤波Q值上限
	float					VOC_QL;				// 滤波Q值下限
	float					VOC_R;				// 滤波R值
	float					VOC_integral;		// 积分补偿基值
	float					VOC_Gain;			// 积分补偿增益
	float					VOC_decay;			// 积分补偿基值衰减参数
	float					VOC_alpha;			// 低通滤波参数
	float					VOC_prev;			// 上一次卡尔曼滤波值（x_hat）
	float					VOC_lp_prev;		// 上一次低通输出（lp_prev）
	
	// ---------- 其他 ----------
	float					Avg_Queue[SGP41_Avg_Len];	// 均值计算队列
	uint8_t					Avg_Queue_P;		// 均值计算队列指针
	uint8_t					First_Read;			// 首次读取标志位
	
	uint16_t				VOC_Fil;			// 测得数据(滤波) - 当前输出
	uint8_t					ADDR_W;				// 写地址
	uint8_t					ADDR_R;				// 读地址
	uint8_t					Init_ed;			// 初始化完成标志位
	uint8_t					Measure_Rate_Control_Parameters;	// 采样速率控制参数
} SGP41_HandleTypeDef;

/* =======SGP41句柄配置======== */
#define SGP41_I2C_Handle1 	KL_I2C2_Handle
extern SGP41_HandleTypeDef	SGP41_Handle1;
/* ============================ */

// 函数声明
void SGP41_Init(SGP41_HandleTypeDef* SGP41_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr_w, uint8_t Addr_r);		// 初始化
uint8_t SGP41_StartMeasure(SGP41_HandleTypeDef* SGP41_Handle);		// 启动测量
uint8_t SGP41_ReadData(SGP41_HandleTypeDef* SGP41_Handle);			// 读取并计算指数
#endif
