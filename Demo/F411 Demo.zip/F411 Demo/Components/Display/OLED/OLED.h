#ifndef _OLED_H_
#define _OLED_H_

#include "main.h"
#include "KL_I2C.h"

/* 屏幕参数 */
#define OLED_WIDTH   	128
#define OLED_HEIGHT  	64
#define OLED_PAGES   	(OLED_HEIGHT/8)
#define OLED1_I2C_ADDR 	0x78
#define OLED2_I2C_ADDR 	0x7A
#define OLED3_I2C_ADDR 	0x78
#define OLED4_I2C_ADDR 	0x7A

/** 
  * 无缓冲帧架构，此设计避免了从缓冲中移入输出序列时阻塞或额外使用DMA的窘境
  * 对显存内容修改时注意不要高频修改(如对ADC数据的显示等)，以免出现画面错误
  */
  /* 通过在系统时钟设置帧率控制参数自增,主函数调用帧刷新可控制帧率 */
typedef struct {
	KL_I2C_HandleTypeDef*	KL_I2C_Handle;									// 总线绑定
	uint8_t					ADDR;											// 地址
	uint8_t					Orientation_Instruction[3];						// 显示方向设置序列
	uint8_t					Refresh_Counter;								// 刷新计数器
	uint8_t					Frame_Rate_Control_Parameters;					// 帧率控制参数
	uint8_t					Mode_Instruction[2];							// 显示模式设置序列
	uint8_t					Page_CMD[4];									// 页面取址指令
	uint8_t*				Video_Memory[OLED_PAGES];						// 显存指针
	uint8_t					Video_Memory_Out[OLED_PAGES][OLED_WIDTH + 1];	// 输出缓存
} OLED_HandleTypeDef;

/* ========屏幕句柄配置======== */
#define OLED1_I2C_Handle 	KL_I2C2_Handle
extern OLED_HandleTypeDef OLED1_Handle;
#define OLED2_I2C_Handle 	KL_I2C2_Handle
extern OLED_HandleTypeDef OLED2_Handle;
#define OLED3_I2C_Handle 	KL_I2C3_Handle
extern OLED_HandleTypeDef OLED3_Handle;
#define OLED4_I2C_Handle 	KL_I2C3_Handle
extern OLED_HandleTypeDef OLED4_Handle;
/* ============================ */

/* OLED显示方向参数 */
#define OLED_ORIENTATION_UP			0
#define OLED_ORIENTATION_DOWN		1

/* OLED显示模式参数 */
#define OLED_DISPLAY_MODE_NORMAL	0
#define OLED_DISPLAY_MODE_INVERSE	1

uint8_t OLED_Set_Display_Mode(OLED_HandleTypeDef* OLED_Handle, uint8_t Mode);
uint8_t OLED_Set_Display_Orientation(OLED_HandleTypeDef* OLED_Handle, uint8_t Orientation);
void OLED_Set_Brightness(OLED_HandleTypeDef* OLED_Handle, uint8_t Brightness);
void OLED_Frame_Refresh(OLED_HandleTypeDef* OLED_Handle);
void OLED_Page_Refresh(OLED_HandleTypeDef* OLED_Handle, uint8_t Continuous);
void OLED_Init(OLED_HandleTypeDef* OLED_Handle, KL_I2C_HandleTypeDef* I2C_Bus, uint8_t Addr, uint8_t Display_Mode, uint8_t Orientation, uint8_t Brightness);
void OLED_DeInit(OLED_HandleTypeDef* OLED_Handle);
#endif
