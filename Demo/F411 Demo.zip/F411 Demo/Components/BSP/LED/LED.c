#include "LED.h"

void LED_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
	
	LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOC);
	
	GPIO_InitStruct.Pin = LED_Pin;
	GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
	GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
	GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
	LL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);
	LL_GPIO_SetOutputPin(LED_GPIO_Port, LED_Pin);
}

void LED_On(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO_Port, LED_Pin);
}

void LED_Off(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO_Port, LED_Pin);
}

void LED_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
}

void LED_DeInit(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
    
    GPIO_InitStruct.Pin = LED_Pin;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_ANALOG;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    
    LL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);
}
