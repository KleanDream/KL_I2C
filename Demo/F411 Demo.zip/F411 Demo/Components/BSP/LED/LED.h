#ifndef __LED_H
#define __LED_H

#include "main.h"

#define LED_Pin LL_GPIO_PIN_13
#define LED_GPIO_Port GPIOC

void LED_Init(void);
void LED_On(void);
void LED_Off(void);
void LED_Toggle(void);
void LED_DeInit(void);

#endif
