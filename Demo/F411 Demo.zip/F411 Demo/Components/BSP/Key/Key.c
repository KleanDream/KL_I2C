#include "Key.h"
#include "UI.h"
#include "OLED.h"

uint32_t Key_Delay_Num = 0;

OLED_HandleTypeDef *Ctrl_Handle;

void Key_Init(void)
{
	Ctrl_Handle = &OLED4_Handle;
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	__HAL_RCC_GPIOA_CLK_ENABLE();

	GPIO_InitStruct.Pin = Key_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(Key_GPIO_Port, &GPIO_InitStruct);
	
	HAL_NVIC_SetPriority(EXTI0_IRQn, 13, 0);
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}

uint8_t Key_Get_Level(void)
{
	return LL_GPIO_IsInputPinSet(Key_GPIO_Port, Key_Pin_LL);
}

void Key_IT(void)
{
	if(Key_Delay_Num == 0)
	{
		Key_Delay_Num = 20;
		switch(UI_State_register[Ctrl_Display].bits.Page)
		{
			case Weicome_Page:{
				UI_State_register[Ctrl_Display].bits.Page = TempHumi_Page;
				break;
			}
			case TempHumi_Page:{
				UI_State_register[Ctrl_Display].bits.Page = VOT_NOx_Page;
				break;
			}
			case VOT_NOx_Page:{
				UI_State_register[Ctrl_Display].bits.Page = CO2_Page;
				break;
			}
			case CO2_Page:{
				UI_State_register[Ctrl_Display].bits.Page = PM_Page;
				break;
			}
			case PM_Page:{
				UI_State_register[Ctrl_Display].bits.Page = Light_Page;
				break;
			}
			case Light_Page:{
				UI_State_register[Ctrl_Display].bits.Page = TempHumi_Page;
				break;
			}
			default: break;
		}
	}
}

void EXTI0_IRQHandler(void)
{ HAL_GPIO_EXTI_IRQHandler(Key_Pin); }


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	switch(GPIO_Pin)
	{
		case Key_Pin:{
			Key_IT();
			break;
		}
		default: break;
	}
}
