#ifndef __KEY_H
#define __KEY_H

#include "main.h"

#define Key_Pin GPIO_PIN_0
#define Key_Pin_LL LL_GPIO_PIN_0
#define Key_GPIO_Port GPIOA

extern uint32_t Key_Delay_Num;

void Key_Init(void);
uint8_t Key0_Get_Level(void);

#endif
