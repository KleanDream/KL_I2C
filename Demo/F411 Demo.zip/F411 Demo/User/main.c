#include "main.h"
#include "FreeRTOS_Service.h"
#include "System_Core.h"

int main(void)
{
	HAL_Init();
	SystemClock_Config();
	
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	
	LED_Init();
//	Key_Init();
	
	HAL_Delay(200);
	
	KL_I2C_Init();
	OLED_Init(&OLED1_Handle, &OLED1_I2C_Handle, OLED1_I2C_ADDR, OLED_DISPLAY_MODE_NORMAL, OLED_ORIENTATION_DOWN, 100);
	OLED_Init(&OLED2_Handle, &OLED2_I2C_Handle, OLED2_I2C_ADDR, OLED_DISPLAY_MODE_NORMAL, OLED_ORIENTATION_DOWN, 100);
	OLED_Init(&OLED3_Handle, &OLED3_I2C_Handle, OLED3_I2C_ADDR, OLED_DISPLAY_MODE_NORMAL, OLED_ORIENTATION_UP, 100);
	OLED_Init(&OLED4_Handle, &OLED4_I2C_Handle, OLED4_I2C_ADDR, OLED_DISPLAY_MODE_NORMAL, OLED_ORIENTATION_UP, 100);
	
	HAL_Delay(500);
	
	SHT_Init(&SHT45_Handle1, &SHT45_I2C_Handle1, SHT45_ADDR, SHT_Type_SHT45);
	GY302_Init(&GY302_Handle0, &GY302_I2C_Handle0, GY302_W_ADDR_0, GY302_R_ADDR_0, GY302_High_Precision_Mode);
	GY302_Init(&GY302_Handle1, &GY302_I2C_Handle1, GY302_W_ADDR_1, GY302_R_ADDR_1, GY302_High_Precision_Mode);
	SGP41_Init(&SGP41_Handle1, &SGP41_I2C_Handle1, SGP41_ADDR_WRITE, SGP41_ADDR_READ);
	SCD41_Init(&SCD41_Handle1, &SCD41_I2C_Handle1, SCD41_ADDR_WRITE, SCD41_ADDR_READ);
	HAL_Delay(500);
	CJ3_Init();
	UI_State_register[0].bits.Page = CO2_Page;
	UI_State_register[1].bits.Page = VOT_NOx_Page;
	UI_State_register[2].bits.Page = PM_Page;
	UI_State_register[3].bits.Page = TempHumi_Page;
	Sys_IT_TIM_Init();
	UART_COM1_Init();
	Bluetooth_Init();
	
	System_IWDG_Init(10);

	FreeRTOS_Login();
	
	while(1);
}
	
void Error_Handler(void)
{
	__disable_irq();
	while(1);
}

void KL_IRQ_Enable(void)
{
	__enable_irq();
}

void KL_IRQ_Disable(void)
{
	__disable_irq();
}

