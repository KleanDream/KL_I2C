/**
  ******************************************************************************
  * @file    Templates/Inc/main.h 
  * @author  MCD Application Team
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2017 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"

/* LL库引用 */
#include "stm32f4xx_ll_bus.h"
#include "stm32f4xx_ll_cortex.h"
#include "stm32f4xx_ll_system.h"
//#include "stm32f4xx_ll_adc.h"
//#include "stm32f4xx_ll_crc.h"
//#include "stm32f4xx_ll_dac.h"
#include "stm32f4xx_ll_dma.h"
//#include "stm32f4xx_ll_dma2d.h"
#include "stm32f4xx_ll_exti.h"
//#include "stm32f4xx_ll_fmc.h"
//#include "stm32f4xx_ll_fmpi2c.h"
//#include "stm32f4xx_ll_fsmc.h"
#include "stm32f4xx_ll_gpio.h"
//#include "stm32f4xx_ll_i2c.h"
//#include "stm32f4xx_ll_lptim.h"
#include "stm32f4xx_ll_pwr.h"
#include "stm32f4xx_ll_rcc.h"
//#include "stm32f4xx_ll_rng.h"
//#include "stm32f4xx_ll_rtc.h"
//#include "stm32f4xx_ll_sdmmc.h"
//#include "stm32f4xx_ll_spi.h"
//#include "stm32f4xx_ll_tim.h"
//#include "stm32f4xx_ll_usart.h"
//#include "stm32f4xx_ll_usb.h"
#include "stm32f4xx_ll_utils.h"

#include "FreeRTOS.h"
#include "task.h"
#include "LED.h"
#include "UART_COM1.h"
#include "Bluetooth.h"
/* Exported types ------------------------------------------------------------*/
extern uint8_t displayflag[4];

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions ------------------------------------------------------- */

void Error_Handler(void);
#endif /* __MAIN_H */
