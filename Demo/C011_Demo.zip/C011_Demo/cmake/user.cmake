# ============================================================================
# user.cmake - 你的自定义 CMake 内容都写在这个文件里
# ============================================================================
# 为什么写这里：
#   - 本文件由根 CMakeLists.txt 末尾 include，CubeMX 重新生成代码时完全不碰它
#   - cmake/stm32cubemx/CMakeLists.txt 每次生成都会被整体覆盖，禁止写入
#   - 根 CMakeLists.txt 只生成一次不会被覆盖，但单独放一个文件更整洁
#
# 重要！路径基准变量：
#   CMAKE_CURRENT_LIST_DIR   = 本文件所在目录（.../cmake）  ← 用它算相对路径
#   CMAKE_CURRENT_SOURCE_DIR = 根 CMakeLists.txt 所在目录（工程根），
#                              include() 不会改变它，不能用它做相对定位！
#
# 本文件基于当前工程结构预填了以下用户目录（2026-08-16）：
#   KL_Lib/    - KL_I2C 库（Inc + Src）
#   System/    - System_service/UI 模块
#   Components/- 预留组件目录（当前为空，放文件后自动编译）
#
# 使用 GLOB 递归收集 .c，之后在这些目录里新增源文件无需再改本文件
# ============================================================================

message(STATUS "[user.cmake] loaded from ${CMAKE_CURRENT_LIST_DIR}")

# 工程根目录（cmake/ 的上一级）
set(USER_PROJECT_ROOT ${CMAKE_CURRENT_LIST_DIR}/..)

# ---------------------------------------------------------------------------
# 1. 收集用户源码
# ---------------------------------------------------------------------------
file(GLOB_RECURSE USER_SOURCES
    ${USER_PROJECT_ROOT}/KL_Lib/*.c
    ${USER_PROJECT_ROOT}/System/*.c
    ${USER_PROJECT_ROOT}/Components/*.c
)

# 把用户源码追加到可执行目标
target_sources(${CMAKE_PROJECT_NAME} PRIVATE ${USER_SOURCES})

# ---------------------------------------------------------------------------
# 2. 用户头文件搜索路径
# ---------------------------------------------------------------------------
target_include_directories(${CMAKE_PROJECT_NAME} PRIVATE
    ${USER_PROJECT_ROOT}/KL_Lib/KL_I2C/Inc
    ${USER_PROJECT_ROOT}/System/System_service/UI
    ${USER_PROJECT_ROOT}/Components/BSP/LED
    ${USER_PROJECT_ROOT}/Components/Display/OLED
)

# ---------------------------------------------------------------------------
# 3. 其他自定义内容写在这里（按需取消注释）
# ---------------------------------------------------------------------------
# 追加编译宏定义：
# target_compile_definitions(${CMAKE_PROJECT_NAME} PRIVATE
#     MY_CUSTOM_MACRO=1
# )

# 追加外部静态库 / 链接目录：
# target_link_directories(${CMAKE_PROJECT_NAME} PRIVATE
#     ${USER_PROJECT_ROOT}/Libs
# )
# target_link_libraries(${CMAKE_PROJECT_NAME} my_lib_name)

# 自定义链接选项（如内存占用报告）：
# target_link_options(${CMAKE_PROJECT_NAME} PRIVATE
#     -Wl,--print-memory-usage
# )
