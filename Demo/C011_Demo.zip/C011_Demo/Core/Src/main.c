/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "i2c.h"
#include "rtc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "LED.h"
#include "KL_I2C.h"
#include "OLED.h"
#include "UI.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile uint8_t flag = 0;
volatile uint32_t num = 0;      /* RTC 中断每秒自增、主循环读取显示：必须 volatile（Release -Os 否则被优化缓存，同 flag 教训） */
RTC_AlarmTypeDef sAlarm = {0};  /* 闹钟 A 配置（每秒触发一次中断） */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void TIM3_IT(void)
{
  LED_Toggle();
  OLED_Frame_Refresh(&OLED1_Handle);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */
  LED_Init();
  /* 等待OLED模块上电稳定（SSD1306上电后需数十ms才能接受命令，参考F411工程做法） */
  HAL_Delay(200);
  KL_I2C_Init();
	OLED_Init(&OLED1_Handle, &OLED1_I2C_Handle, OLED1_I2C_ADDR, OLED_DISPLAY_MODE_NORMAL, OLED_ORIENTATION_UP, 100);
  uint8_t* Chinese_String;
  Chinese_String = (uint8_t*)sdsj;
  OLED_ShowChineseString(&OLED1_Handle, 0x30, 0x00, Chinese_String, 4, 1);

  /* ---- RTC 闹钟 A：每秒中断，驱动 num 自增 ---- */
  /* 1. 配置 EXTI 上升沿检测：线 19 + 线 23 都配（保险，覆盖 RTC 事件线） */
  SET_BIT(EXTI->RTSR1, RTC_EXTI_LINE_ALARM_EVENT);
  SET_BIT(EXTI->RTSR1, EXTI_IMR1_IM23);

  /* 2. 配置闹钟 A：全掩码 → 每个秒边界匹配一次
        【关键】Alarm 字段必须显式设为 RTC_ALARM_A！
        RTC_ALARM_A = RTC_CR_ALRAE = 0x100（不是 0），结构体清零后 Alarm=0
        会使 SetAlarm_IT 内部 if (sAlarm->Alarm == RTC_ALARM_A) 不成立，
        整个闹钟配置被静默跳过（返回 HAL_OK 但什么都不做） */
  sAlarm.Alarm = RTC_ALARM_A;
  sAlarm.AlarmTime.Hours = 0;
  sAlarm.AlarmTime.Minutes = 0;
  sAlarm.AlarmTime.Seconds = 0;
  sAlarm.AlarmDateWeekDay = 0;
  sAlarm.AlarmMask = RTC_ALARMMASK_ALL;                /* 全掩码 → 每秒匹配 */
  sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_ALL;  /* 子秒不参与比较 */
  HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN);

  /* 3. 清除 EXTI 挂起位（防止闹钟写入后立即匹配导致挂起提前锁存） */
  EXTI->RPR1 |= (RTC_EXTI_LINE_ALARM_EVENT | EXTI_IMR1_IM23);

  /* 4. 使能 RTC 全局中断（闹钟 A 经 EXTI 路由到 RTC_IRQn） */
  HAL_NVIC_SetPriority(RTC_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(RTC_IRQn);

  /* 启动 TIM3 定时中断（每 1ms 溢出一次），LED 翻转在中断回调中完成 */
  HAL_TIM_Base_Start_IT(&htim3);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if(flag == 1)
    {
      flag = 0;   /* num 自增已由 RTC 中断完成，主循环只负责刷新显示 */
      OLED_ShowNum(&OLED1_Handle, 0x30, 0x48, num, 7, 1);
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_FLASH_SET_LATENCY(FLASH_LATENCY_1);

  /** Configure LSE Drive Capability
  */
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
  * @brief  RTC 闹钟 A 事件回调（由 HAL_RTC_AlarmIRQHandler 调用）
  *         每 1 秒触发一次：num 自增 + 置 flag，并重新使能闹钟（匹配后硬件会自动关闭闹钟）
  */
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
  num++;
  flag = 1;

  /* 重新置位 ALRAE（匹配后硬件会自动清零该位）。
     注意：不要在这里调用 HAL_RTC_SetAlarm_IT —— 它内部等待 ALRAWF 标志时
     依赖 HAL_GetTick()，而本中断优先级(0)高于 SysTick(3)，tick 不增长会死等 */
  __HAL_RTC_WRITEPROTECTION_DISABLE(hrtc);
  __HAL_RTC_ALARMA_ENABLE(hrtc);
  __HAL_RTC_WRITEPROTECTION_ENABLE(hrtc);
}

void KL_IRQ_Enable(void)
{
	__enable_irq();
}

void KL_IRQ_Disable(void)
{
	__disable_irq();
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
