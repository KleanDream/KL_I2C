#include "main.h"
#include "UI.h"
#include "Font.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

//中文语句
uint8_t sdsj[4] = {1,2,3,4};	//上电时间



/* ================OLED相关函数================ */
/**
  * @brief  OLED清屏
  * @param  无
  * @retval 无
  */
void OLED_Clear(OLED_HandleTypeDef* OLED_Handle)
{  
    for (uint8_t i = 0; i < OLED_PAGES; i++)
		memset(OLED_Handle->Video_Memory[i], 0x00, OLED_WIDTH);
}

/**
 *  @brief OLED显示汉字
 *  @param Line起始位置，范围1~4
 *  @param Column 起始列位置，1~8
 *  @param CHN 汉字序列
 */
void OLED_ShowChinese(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t CHN, uint8_t Cover_Enable)
{
	int8_t Start_page;
	int8_t shift;
	if(y >= 0)
	{
		Start_page = y / 8;
		shift = y % 8;
	}
	else 
	{
		Start_page = -((-y - 1) / 8 + 1);
		shift = -((-y) % 8);
	}
	uint8_t i;
	
		// 上半部分
	for (i = 0; i < 16; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if(Start_page >= 0 && Start_page <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page][x + i + 1] &= 0xFF >> (8 - shift);
					OLED_Handle->Video_Memory[Start_page][x + i + 1] |= Chinese_Font[CHN * 2][i] << shift;
				}
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= Chinese_Font[CHN * 2][i] >> (8 - shift);
				}
			}
			else 
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= (Chinese_Font[CHN * 2][i] >> (-shift)) | (Chinese_Font[CHN * 2 + 1][i] << (8 - (-shift)));
				}
			}
		}
	}
	// 下半部分
	for (i = 0; i < 16; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= Chinese_Font[CHN * 2 + 1][i] << shift;
				}
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << shift;
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= Chinese_Font[CHN * 2 + 1][i] >> (8 - shift);
				}
			}
			else
			{
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << (8 + shift);
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= Chinese_Font[CHN * 2 + 1][i] >> (-shift);
				}
			}
		}
	}
}

void OLED_ShowChineseString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t *CHN, uint8_t num, uint8_t Cover_Enable)
{
	uint8_t i;
    for (i = 0; i < num; i++)
    {
		OLED_ShowChinese(OLED_Handle,y, x + 16 * i, CHN[i], Cover_Enable);
    }
}

/**
  * @brief  OLED显示一个字符
  * @param  Line 行位置，范围：1~4
  * @param  Column 列位置，范围：1~16
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowChar(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char Char, uint8_t Cover_Enable)
{
	int8_t Start_page;
	int8_t shift;
	if(y >= 0)
	{
		Start_page = y / 8;
		shift = y % 8;
	}
	else 
	{
		Start_page = -((-y - 1) / 8 + 1);
		shift = -((-y) % 8);
	}
	uint8_t i;
	
		// 上半部分
	for (i = 0; i < 8; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if(Start_page >= 0 && Start_page <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page][x + i + 1] &= 0xFF >> (8 - shift);
					OLED_Handle->Video_Memory[Start_page][x + i + 1] |= OLED_F8x16[Char - ' '][i] << shift;
				}
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= OLED_F8x16[Char - ' '][i] >> (8 - shift);
				}
			}
			else 
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] = 0x00;
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= (OLED_F8x16[Char - ' '][i] >> (-shift)) | (OLED_F8x16[Char - ' '][i + 8] << (8 - (-shift)));
				}
			}
		}
	}
	// 下半部分
	for (i = 0; i < 8; i++)
	{
		if(x >= 0 && ((x + i) < (OLED_WIDTH - 1)))
		{
			if(shift >= 0)
			{
				if((Start_page + 1) >= 0 && (Start_page + 1) <= (OLED_PAGES - 1))
				{
					OLED_Handle->Video_Memory[Start_page + 1][x + i + 1] |= OLED_F8x16[Char - ' '][i + 8] << shift;
				}
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << shift;
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= OLED_F8x16[Char - ' '][i + 8] >> (8 - shift);
				}
			}
			else
			{
				if((Start_page + 2) >= 0 && (Start_page + 2) <= (OLED_PAGES - 1))
				{
					if(Cover_Enable) OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] &= 0xFF << (8 + shift);
					OLED_Handle->Video_Memory[Start_page + 2][x + i + 1] |= OLED_F8x16[Char - ' '][i + 8] >> (-shift);
				}
			}
		}
	}
}

/**
  * @brief  OLED显示字符串
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @retval 无
  */
void OLED_ShowString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char *String, uint8_t Cover_Enable)
{
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++)
    {
        OLED_ShowChar(OLED_Handle, y, x + 8 * i, String[i], Cover_Enable);
    }
}

/**
  * @brief  OLED次方函数
  * @retval 返回值等于X的Y次方
  */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
    uint32_t Result = 1;
    while (Y--)
    {
        Result *= X;
    }
    return Result;
}

/**
  * @brief  OLED显示数字（十进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~4294967295
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i;
    for (i = 0; i < Length; i++)                            
    {
        OLED_ShowChar(OLED_Handle, y, x + i * 8, Number / OLED_Pow(10, Length - i - 1) % 10 + '0', Cover_Enable);
    }
}

/**
  * @brief  OLED显示数字（十进制，带符号数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：-2147483648~2147483647
  * @param  Length 要显示数字的长度，范围：1~10
  * @retval 无
  */
void OLED_ShowSignedNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, int32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i;
    uint32_t Number1;
    if (Number >= 0)
    {
        OLED_ShowChar(OLED_Handle, y, x, '+', Cover_Enable);
        Number1 = Number;
    }
    else
    {
        OLED_ShowChar(OLED_Handle, y, x, '-', Cover_Enable);
        Number1 = -Number;
    }
    for (i = 0; i < Length; i++)                            
    {
        OLED_ShowChar(OLED_Handle, y, x + i * 8 + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0', Cover_Enable);
    }
}

/**
  * @brief  OLED显示数字（十六进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~0xFFFFFFFF
  * @param  Length 要显示数字的长度，范围：1~8
  * @retval 无
  */
void OLED_ShowHexNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i, SingleNumber;
    for (i = 0; i < Length; i++)                            
    {
        SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
        if (SingleNumber < 10)
        {
            OLED_ShowChar(OLED_Handle, y, x + i * 8, SingleNumber + '0', Cover_Enable);
        }
        else
        {
            OLED_ShowChar(OLED_Handle, y, x + i * 8, SingleNumber - 10 + 'A', Cover_Enable);
        }
    }
}

/**
  * @brief  OLED显示数字（二进制，正数）
  * @param  Line 起始行位置，范围：1~4
  * @param  Column 起始列位置，范围：1~16
  * @param  Number 要显示的数字，范围：0~1111 1111 1111 1111
  * @param  Length 要显示数字的长度，范围：1~16
  * @retval 无
  */
void OLED_ShowBinNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable)
{
    uint8_t i;
    for (i = 0; i < Length; i++)                            
    {
        OLED_ShowChar(OLED_Handle, y, x + i * 8, Number / OLED_Pow(2, Length - i - 1) % 2 + '0', Cover_Enable);
    }
}

