#ifndef _UI_H_
#define _UI_H_

#include "main.h"
#include "OLED.h"

extern uint8_t sycx[4];	//实验程序
extern uint8_t sdsj[4];	//上电时间
extern uint8_t sd[4];   //闪灯

void OLED_Clear(OLED_HandleTypeDef* OLED_Handle);
void OLED_ShowChinese(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t CHN, uint8_t Cover_Enable);
void OLED_ShowChineseString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint8_t* CHN, uint8_t num, uint8_t Cover_Enable);
void OLED_ShowChar(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char Char, uint8_t Cover_Enable);
void OLED_ShowString(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, char *String, uint8_t Cover_Enable);
void OLED_ShowNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable);
void OLED_ShowSignedNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, int32_t Number, uint8_t Length, uint8_t Cover_Enable);
void OLED_ShowHexNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable);
void OLED_ShowBinNum(OLED_HandleTypeDef* OLED_Handle, int8_t y, int8_t x, uint32_t Number, uint8_t Length, uint8_t Cover_Enable);

#endif
